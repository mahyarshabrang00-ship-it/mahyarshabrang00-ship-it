/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Contact, ItemService, Invoice, BankAccount, Transaction, Task, CompanyInfo, Project, Receipt, Payment, Shareholder, Seller } from './types';

export const INITIAL_COMPANY: CompanyInfo = {
  name: 'حسابداری مانی',
  financialYear: '۱۴۰۵ (جاری)',
  phone: '۰۲۱-۸۸۸۸۸۸۸۸',
  address: 'تهران، میدان ونک، سعادت آباد'
};

export const INITIAL_CONTACTS: Contact[] = [
  {
    id: 'sh_c1',
    code: '۰۰۰۰۷',
    name: 'آقای جمالی',
    phone: '۰۹۱۲۳۴۵۶۷۸۹',
    email: 'jamali@example.com',
    type: 'shareholder',
    balance: -50000000, // بستانکار
    address: 'تهران، میدان ونک',
    nationalId: '۰۰۱۲۳۴۵۶۷۸',
    category: 'سهامداران',
    isActive: true
  },
  {
    id: 'sh_c2',
    code: '۰۰۰۰۸',
    name: 'مهندس قنبرزاده',
    phone: '۰۹۱۲۲۲۲۲۲۲۲',
    email: 'ghanbarzadeh@example.com',
    type: 'shareholder',
    balance: -50000000, // بستانکار
    address: 'تهران، نیاوران',
    nationalId: '۰۰۹۸۷۶۵۴۳۲',
    category: 'سهامداران',
    isActive: true
  },
  {
    id: 'sel_c1',
    code: '۰۰۰۰۱',
    name: 'علی محسن پور',
    phone: '۰۹۱۲۳۳۳۳۳۳۳',
    email: 'mohsenpour@example.com',
    type: 'employee',
    balance: 0,
    address: 'تهران، سعادت آباد',
    nationalId: '۰۰۳۴۵۶۷۸۹۰',
    category: 'کارمندان',
    isActive: true
  },
  {
    id: 'sel_c3',
    code: '۰۰۰۰۳',
    name: 'علی اکبرپور',
    phone: '۰۹۱۲۴۴۴۴۴۴۴',
    email: 'akbarpour@example.com',
    type: 'employee',
    balance: 0,
    address: 'تهران، گیشا',
    nationalId: '۰۰۴۵۶۷۸۹۰۱',
    category: 'کارمندان',
    isActive: true
  },
  {
    id: 'sel_c4',
    code: '۰۰۰۰۴',
    name: 'مهدی عیاری',
    phone: '۰۹۱۲۵۵۵۵۵۵۵',
    email: 'ayari@example.com',
    type: 'employee',
    balance: 0,
    address: 'تهران، یوسف آباد',
    nationalId: '۰۰۵۶۷۸۹۰۱۲',
    category: 'کارمندان',
    isActive: true
  },
  {
    id: 'sel_c5',
    code: '۰۰۰۰۵',
    name: 'علی محمدی',
    phone: '۰۹۱۲۶۶۶۶۶۶۶',
    email: 'mohammadi@example.com',
    type: 'employee',
    balance: 0,
    address: 'تهران، تهرانپارس',
    nationalId: '۰۰۶۷۸۹۰۱۲۳',
    category: 'کارمندان',
    isActive: true
  }
];


export const INITIAL_ITEMS: ItemService[] = [
  {
    id: 'item_1',
    code: '۰۰۰۰۰۱',
    name: 'یخچال ال جی',
    category: 'کالاها : لوازم برقی آشپزخانه',
    productCode: 'J - 713',
    salePrice: 750000000,
    purchasePrice: 650000000,
    unit: 'دستگاه',
    stock: 12,
    description: '',
    isService: false,
    isActive: true
  },
  {
    id: 'item_2',
    code: '۰۰۰۰۰۲',
    name: 'لباسشویی سامسونگ',
    category: 'کالاها : لوازم برقی آشپزخانه : سامسونگ',
    productCode: 'M - 312',
    salePrice: 260000000,
    purchasePrice: 200000000,
    unit: 'دستگاه',
    stock: 8,
    description: '',
    isService: false,
    isActive: true
  },
  {
    id: 'item_3',
    code: '۰۰۰۰۰۳',
    name: 'جاروبرقی بوش',
    category: 'کالاها : برقی منزل : بوش',
    productCode: 'L - 134',
    salePrice: 80000000,
    purchasePrice: 49000000,
    unit: 'دستگاه',
    stock: 15,
    description: '',
    isService: false,
    isActive: true
  },
  {
    id: 'item_4',
    code: '۰۰۰۰۰۴',
    name: 'اجاق گاز شعله',
    category: 'کالاها : لوازم برقی آشپزخانه',
    productCode: 'w - 34',
    salePrice: 90000000,
    purchasePrice: 70000000,
    unit: 'دستگاه',
    stock: 5,
    description: '',
    isService: false,
    isActive: true
  },
  {
    id: 'item_5',
    code: '۰۰۰۰۰۵',
    name: 'تلویزیون سونی',
    category: 'کالاها : برقی منزل : سونی',
    productCode: 'd - 234',
    salePrice: 350000000,
    purchasePrice: 290000000,
    unit: 'دستگاه',
    stock: 4,
    description: '',
    isService: false,
    isActive: true
  },
  {
    id: 'item_6',
    code: '۰۰۰۰۰۶',
    name: 'نصب و راه اندازی',
    category: 'خدمات',
    productCode: '---',
    salePrice: 10000000,
    purchasePrice: 0,
    unit: 'ساعت',
    stock: 0,
    description: '',
    isService: true,
    isActive: true
  },
  {
    id: 'item_7',
    code: '۰۰۰۰۰۷',
    name: 'مایکروفر سامسونگ',
    category: 'کالاها : لوازم برقی آشپزخانه',
    productCode: 'r - 325',
    salePrice: 120000000,
    purchasePrice: 80000000,
    unit: 'دستگاه',
    stock: 10,
    description: '',
    isService: false,
    isActive: true
  },
  {
    id: 'item_8',
    code: '۰۰۰۰۰۸',
    name: 'ماشین ظرفشویی بوش',
    category: 'کالاها : لوازم برقی آشپزخانه',
    productCode: 'a - 369',
    salePrice: 680000000,
    purchasePrice: 580000000,
    unit: 'دستگاه',
    stock: 7,
    description: '',
    isService: false,
    isActive: true
  },
  {
    id: 'item_9',
    code: '۰۰۰۰۰۹',
    name: 'غذاساز تفال',
    category: 'کالاها : لوازم برقی آشپزخانه',
    productCode: 'g - 344',
    salePrice: 188000000,
    purchasePrice: 142000000,
    unit: 'دستگاه',
    stock: 20,
    description: '',
    isService: false,
    isActive: true
  },
  {
    id: 'item_10',
    code: '۰۰۰۰۱۰',
    name: 'اتوبخار سامسونگ',
    category: 'کالاها : برقی منزل : سامسونگ',
    productCode: 'f - 435',
    salePrice: 68000000,
    purchasePrice: 48000000,
    unit: 'دستگاه',
    stock: 14,
    description: '',
    isService: false,
    isActive: true
  }
];

export const INITIAL_BANKS: BankAccount[] = [
  {
    id: 'b1',
    name: 'بانک ملی - حساب جاری مانی',
    accountNumber: '۰۱۰۲۳۴۵۶۷۸۰۰۴',
    type: 'bank',
    balance: 0
  },
  {
    id: 'b2',
    name: 'صندوق مرکزی مانی',
    accountNumber: 'صندوق اصلی',
    type: 'cash',
    balance: 0
  }
];

export const INITIAL_INVOICES: Invoice[] = [];

export const INITIAL_TRANSACTIONS: Transaction[] = [];

export const INITIAL_TASKS: Task[] = [];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'p1',
    name: 'توزیع فروشگاهی',
    isActive: true,
    isDefault: false
  }
];

export const INITIAL_RECEIPTS: Receipt[] = [];

export const INITIAL_PAYMENTS: Payment[] = [];

export const INITIAL_SHAREHOLDERS: Shareholder[] = [
  { id: 'sh1', contactId: 'sh_c1', contactName: 'آقای جمالی', percentage: 50 },
  { id: 'sh2', contactId: 'sh_c2', contactName: 'مهندس قنبرزاده', percentage: 50 }
];

export const INITIAL_SELLERS: Seller[] = [
  {
    id: 'sel1',
    code: '۰۰۰۰۱',
    name: 'محسن پور',
    isActive: true,
    salesPercent: 15,
    returnPercent: 15,
    salesAmount: 0,
    returnAmount: 0,
    excludeProductDiscount: false,
    excludeInvoiceAdjustments: false,
    commissionInInvoice: true,
    expenseAccount: 'هزینه بازاریابی و پورسانت',
    relatedContactId: 'sel_c1',
    relatedContactName: 'علی محسن پور',
    description: ''
  },
  {
    id: 'sel2',
    code: '۰۰۰۰۲',
    name: 'خانم حسینیان',
    isActive: true,
    salesPercent: 10,
    returnPercent: 5,
    salesAmount: 0,
    returnAmount: 0,
    excludeProductDiscount: false,
    excludeInvoiceAdjustments: false,
    commissionInInvoice: false,
    expenseAccount: 'هزینه بازاریابی و پورسانت',
    relatedContactId: '',
    relatedContactName: '',
    description: ''
  },
  {
    id: 'sel3',
    code: '۰۰۰۰۳',
    name: 'آقای اکبرپور',
    isActive: true,
    salesPercent: 20,
    returnPercent: 15,
    salesAmount: 0,
    returnAmount: 0,
    excludeProductDiscount: false,
    excludeInvoiceAdjustments: false,
    commissionInInvoice: true,
    expenseAccount: 'هزینه بازاریابی و پورسانت',
    relatedContactId: 'sel_c3',
    relatedContactName: 'علی اکبرپور',
    description: ''
  },
  {
    id: 'sel4',
    code: '۰۰۰۰۴',
    name: 'مهدی عیاری',
    isActive: true,
    salesPercent: 0,
    returnPercent: 0,
    salesAmount: 0,
    returnAmount: 0,
    excludeProductDiscount: false,
    excludeInvoiceAdjustments: false,
    commissionInInvoice: true,
    expenseAccount: 'هزینه بازاریابی و پورسانت',
    relatedContactId: 'sel_c4',
    relatedContactName: 'مهدی عیاری',
    description: ''
  },
  {
    id: 'sel5',
    code: '۰۰۰۰۵',
    name: 'محمدی',
    isActive: true,
    salesPercent: 0.5555,
    returnPercent: 0.5555,
    salesAmount: 0,
    returnAmount: 0,
    excludeProductDiscount: false,
    excludeInvoiceAdjustments: false,
    commissionInInvoice: true,
    expenseAccount: 'هزینه بازاریابی و پورسانت',
    relatedContactId: 'sel_c5',
    relatedContactName: 'علی محمدی',
    description: ''
  }
];

export const INITIAL_FREQUENT_DESCRIPTIONS: string[] = [
  'حواله انتقال',
  'بابت اجاره انبار',
  'بابت قبض آب برق تلفن',
  'دریافت وجه فاکتور'
];

