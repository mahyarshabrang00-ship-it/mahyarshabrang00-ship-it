/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Contact, 
  ItemService, 
  BankAccount, 
  Invoice, 
  Transaction, 
  Task, 
  CompanyInfo,
  UserSession,
  Receipt,
  Project,
  Payment,
  Shareholder,
  Seller
} from './types';
import { 
  INITIAL_CONTACTS, 
  INITIAL_ITEMS, 
  INITIAL_BANKS, 
  INITIAL_INVOICES, 
  INITIAL_TRANSACTIONS, 
  INITIAL_TASKS, 
  INITIAL_COMPANY,
  INITIAL_PROJECTS,
  INITIAL_RECEIPTS,
  INITIAL_FREQUENT_DESCRIPTIONS,
  INITIAL_PAYMENTS,
  INITIAL_SHAREHOLDERS,
  INITIAL_SELLERS
} from './initialData';

// Subcomponents
import Dashboard from './components/Dashboard';
import Contacts from './components/Contacts';
import Items from './components/Items';
import Invoices from './components/Invoices';
import Treasury from './components/Treasury';
import Reports from './components/Reports';
import Settings from './components/Settings';
import Auth from './components/Auth';
import Production from './components/Production';
import Warehousing from './components/Warehousing';
import Accounting from './components/Accounting';
import OtherFeatures from './components/OtherFeatures';
import Receipts from './components/Receipts';
import Payments from './components/Payments';
import Shareholders from './components/Shareholders';
import Sellers from './components/Sellers';

// Icons
import { 
  LayoutDashboard, 
  Users, 
  Package, 
  FileSpreadsheet, 
  Coins, 
  FilePieChart, 
  Settings as SettingsIcon, 
  Bell, 
  ChevronDown, 
  ChevronRight,
  Menu, 
  X, 
  Plus, 
  LogOut, 
  Building,
  Sun,
  Moon,
  Cpu,
  Boxes,
  Calculator,
  Grid,
  ArrowUpRight,
  ArrowDownLeft,
  BookOpen
} from 'lucide-react';

export default function App() {
  // Authentication & Theme States
  const [session, setSession] = useState<UserSession | null>(() => {
    const data = localStorage.getItem('mani_session');
    return data ? JSON.parse(data) : null;
  });

  const [isDark, setIsDark] = useState<boolean>(() => {
    return localStorage.getItem('mani_theme') === 'dark';
  });

  // Navigation
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [isQuickAddOpen, setIsQuickAddOpen] = useState<boolean>(false);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null);
  const [subTabAction, setSubTabAction] = useState<{ tab: string; action: string; payload?: any } | null>(null);
  const [expandedMenu, setExpandedMenu] = useState<string | null>(null);

  // Core accounting states (loaded from localStorage if possible)
  const [contacts, setContacts] = useState<Contact[]>(() => {
    const data = localStorage.getItem('hesabfa_contacts');
    return data ? JSON.parse(data) : INITIAL_CONTACTS;
  });

  const [items, setItems] = useState<ItemService[]>(() => {
    const data = localStorage.getItem('hesabfa_items');
    return data ? JSON.parse(data) : INITIAL_ITEMS;
  });

  const [banks, setBanks] = useState<BankAccount[]>(() => {
    const data = localStorage.getItem('hesabfa_banks');
    return data ? JSON.parse(data) : INITIAL_BANKS;
  });

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    const data = localStorage.getItem('hesabfa_invoices');
    return data ? JSON.parse(data) : INITIAL_INVOICES;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const data = localStorage.getItem('hesabfa_transactions');
    return data ? JSON.parse(data) : INITIAL_TRANSACTIONS;
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    const data = localStorage.getItem('hesabfa_tasks');
    return data ? JSON.parse(data) : INITIAL_TASKS;
  });

  const [companyInfo, setCompanyInfo] = useState<CompanyInfo>(() => {
    const data = localStorage.getItem('hesabfa_company');
    return data ? JSON.parse(data) : INITIAL_COMPANY;
  });

  const [receipts, setReceipts] = useState<Receipt[]>(() => {
    const data = localStorage.getItem('hesabfa_receipts');
    return data ? JSON.parse(data) : INITIAL_RECEIPTS;
  });

  const [payments, setPayments] = useState<Payment[]>(() => {
    const data = localStorage.getItem('hesabfa_payments');
    return data ? JSON.parse(data) : INITIAL_PAYMENTS;
  });

  const [shareholders, setShareholders] = useState<Shareholder[]>(() => {
    const data = localStorage.getItem('hesabfa_shareholders');
    return data ? JSON.parse(data) : INITIAL_SHAREHOLDERS;
  });

  const [sellers, setSellers] = useState<Seller[]>(() => {
    const data = localStorage.getItem('hesabfa_sellers');
    return data ? JSON.parse(data) : INITIAL_SELLERS;
  });

  const [projects, setProjects] = useState<Project[]>(() => {
    const data = localStorage.getItem('hesabfa_projects');
    return data ? JSON.parse(data) : INITIAL_PROJECTS;
  });

  const [frequentDescriptions, setFrequentDescriptions] = useState<string[]>(() => {
    const data = localStorage.getItem('hesabfa_frequent_desc');
    return data ? JSON.parse(data) : INITIAL_FREQUENT_DESCRIPTIONS;
  });

  // LocalStorage Synchronization
  useEffect(() => {
    localStorage.setItem('hesabfa_contacts', JSON.stringify(contacts));
  }, [contacts]);

  useEffect(() => {
    localStorage.setItem('hesabfa_items', JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    localStorage.setItem('hesabfa_banks', JSON.stringify(banks));
  }, [banks]);

  useEffect(() => {
    localStorage.setItem('hesabfa_invoices', JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem('hesabfa_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('hesabfa_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('hesabfa_company', JSON.stringify(companyInfo));
  }, [companyInfo]);

  useEffect(() => {
    localStorage.setItem('hesabfa_receipts', JSON.stringify(receipts));
  }, [receipts]);

  useEffect(() => {
    localStorage.setItem('hesabfa_payments', JSON.stringify(payments));
  }, [payments]);

  useEffect(() => {
    localStorage.setItem('hesabfa_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('hesabfa_frequent_desc', JSON.stringify(frequentDescriptions));
  }, [frequentDescriptions]);

  useEffect(() => {
    localStorage.setItem('hesabfa_shareholders', JSON.stringify(shareholders));
  }, [shareholders]);

  useEffect(() => {
    localStorage.setItem('hesabfa_sellers', JSON.stringify(sellers));
  }, [sellers]);

  useEffect(() => {
    localStorage.setItem('mani_theme', isDark ? 'dark' : 'light');
  }, [isDark]);

  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'warning' } | null>(null);

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  const renderSubItem = (
    label: string, 
    onClick: () => void, 
    isActive: boolean = false, 
    hasBadge: string | null = null
  ) => {
    return (
      <div 
        onClick={(e) => {
          e.stopPropagation();
          onClick();
        }}
        className={`flex items-center justify-between px-3 py-1.5 hover:bg-slate-200/50 rounded-lg cursor-pointer transition-all duration-150 ${
          isActive ? 'bg-slate-300/60 text-slate-900 font-bold' : 'text-slate-600'
        }`}
      >
        <span className="text-[11px] font-medium leading-none">{label}</span>
        <div className="flex items-center gap-1.5">
          {hasBadge && (
            <span className="bg-amber-500 text-white text-[8px] px-1.5 py-0.5 rounded-md font-bold animate-pulse leading-none">
              {hasBadge}
            </span>
          )}
          {/* Shiny Glass Sphere */}
          <div className="w-3 h-3 rounded-full bg-slate-300 border border-slate-400/40 shadow-[inset_-1px_-1px_2.5px_rgba(0,0,0,0.18),_1px_1px_2.5px_rgba(255,255,255,0.95)] flex items-center justify-center flex-shrink-0">
            <div className="w-1.5 h-1.5 rounded-full bg-slate-100 shadow-[0_0_1px_rgba(255,255,255,0.8)]"></div>
          </div>
        </div>
      </div>
    );
  };

  const SubDivider = () => <div className="h-[1px] bg-slate-200/60 my-1"></div>;

  const toggleExpand = (menuId: string, tabId: string) => {
    if (expandedMenu === menuId) {
      setExpandedMenu(null);
    } else {
      setExpandedMenu(menuId);
    }
    setCurrentTab(tabId);
    setSelectedInvoiceId(null);
  };

  const handleLogout = () => {
    localStorage.removeItem('mani_session');
    setSession(null);
    setCurrentTab('dashboard');
  };

  // Reset database routine
  const handleResetDatabase = () => {
    if (confirm('هشدار جدی! آیا واقعاً تمایل دارید کل دیتابیس دمو را پاک کرده و به اطلاعات آزمایشی اولیه بازگردانید؟')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  // Helper for tab styling
  const getTabClass = (isActive: boolean) => {
    const base = "flex items-center gap-3.5 px-4 py-3 rounded-xl text-xs font-bold transition-all duration-200 cursor-pointer ";
    if (isActive) {
      return base + "bg-blue-600 text-white shadow-md shadow-blue-100";
    }
    return base + "text-slate-500 hover:text-slate-800 hover:bg-slate-50";
  };

  if (!session) {
    return (
      <Auth 
        onLoginSuccess={(sess) => {
          setSession(sess);
          localStorage.setItem('mani_session', JSON.stringify(sess));
          // Quick reload or update state to reflect company info immediately
          const storedCompany = localStorage.getItem('hesabfa_company');
          if (storedCompany) {
            setCompanyInfo(JSON.parse(storedCompany));
          }
        }} 
        isDark={isDark} 
        setIsDark={setIsDark} 
      />
    );
  }

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-all duration-300 relative ${isDark ? 'dark' : 'light'}`} dir="rtl" id="app-root">
      
      {/* Background Glassmorphic Glow Blobs */}
      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className={`absolute top-[10%] left-[5%] w-72 h-72 rounded-full blur-3xl animate-pulse duration-[10000ms] ${isDark ? 'bg-indigo-600/10' : 'bg-indigo-400/5'}`}></div>
        <div className={`absolute bottom-[20%] right-[10%] w-96 h-96 rounded-full blur-3xl animate-pulse duration-[8000ms] ${isDark ? 'bg-blue-600/10' : 'bg-blue-400/5'}`}></div>
      </div>

      {/* HEADER BAR */}
      <header className="sticky top-0 border-b shadow-xs z-30 px-4 py-3 flex items-center justify-between print:hidden">
        
        {/* Left header: Burger menu + Title */}
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-50 rounded-xl lg:hidden"
          >
            <Menu size={20} />
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-blue-600 text-white rounded-xl flex items-center justify-center font-black text-base shadow-sm">
              م
            </div>
            <div>
              <h1 className="text-sm font-black text-slate-900 leading-none">{companyInfo.name}</h1>
              <p className="text-[10px] text-slate-400 mt-1 font-medium">{companyInfo.financialYear}</p>
            </div>
          </div>
        </div>

        {/* Right header: Search, notifications, user, quick actions */}
        <div className="flex items-center gap-3">
          
          {/* Quick Action Button */}
          <div className="relative">
            <button 
              onClick={() => setIsQuickAddOpen(!isQuickAddOpen)}
              className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-3 py-2 rounded-xl flex items-center gap-1.5 transition-colors"
            >
              <Plus size={15} className="text-blue-600" />
              <span>ثبت سریع</span>
              <ChevronDown size={13} className="text-slate-400" />
            </button>
            
            {/* Quick Action Dropdown */}
            {isQuickAddOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white border border-slate-100 rounded-xl shadow-xl py-1.5 z-40 text-xs">
                <button 
                  onClick={() => {
                    setCurrentTab('invoices');
                    setSelectedInvoiceId(null);
                    setIsQuickAddOpen(false);
                  }}
                  className="w-full text-right px-4 py-2 hover:bg-slate-50 font-semibold text-slate-700 flex items-center gap-2"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  صدور فاکتور جدید
                </button>
                <button 
                  onClick={() => {
                    setCurrentTab('contacts');
                    setIsQuickAddOpen(false);
                  }}
                  className="w-full text-right px-4 py-2 hover:bg-slate-50 font-semibold text-slate-700 flex items-center gap-2"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                  ثبت شخص جدید
                </button>
                <button 
                  onClick={() => {
                    setCurrentTab('treasury');
                    setIsQuickAddOpen(false);
                  }}
                  className="w-full text-right px-4 py-2 hover:bg-slate-50 font-semibold text-slate-700 flex items-center gap-2"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-violet-500"></span>
                  ثبت تراکنش نقدی
                </button>
              </div>
            )}
          </div>

          {/* Theme Switcher Toggle */}
          <button
            onClick={() => setIsDark(!isDark)}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100/40 rounded-xl cursor-pointer"
            title="تغییر تم رنگی"
          >
            {isDark ? <Sun size={18} className="text-amber-400" /> : <Moon size={18} className="text-slate-500" />}
          </button>

          {/* Notifications bell */}
          <div className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100/40 rounded-xl cursor-pointer relative">
            <Bell size={18} />
            <span className="absolute top-1 right-1 w-2 h-2 bg-rose-500 rounded-full"></span>
          </div>

          <div className="h-7 w-[1px] bg-slate-100/30 hidden sm:block"></div>

          {/* User badge with integrated Logout */}
          <div className="hidden sm:flex items-center gap-2 bg-slate-100/30 hover:bg-slate-100/60 px-2.5 py-1.5 rounded-xl transition-colors">
            <div className="w-6 h-6 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xs">
              {session.fullName.charAt(0)}
            </div>
            <div className="text-right">
              <div className="text-[10px] font-bold text-slate-800 leading-tight">{session.fullName}</div>
              <div className="text-[8px] text-slate-400 font-semibold">{session.companyName}</div>
            </div>
            <button
              onClick={handleLogout}
              className="mr-2 p-1 text-slate-400 hover:text-rose-500 rounded-lg transition-colors cursor-pointer"
              title="خروج از حساب کاربری"
            >
              <LogOut size={13} />
            </button>
          </div>

        </div>

      </header>

      {/* CORE BODY CONTAINER */}
      <div className="flex-1 flex" id="main-content-layout">
        
        {/* SIDEBAR NAVIGATION (RTL right-aligned) */}
        <aside className={`fixed inset-y-0 right-0 w-64 border-l p-4 flex flex-col justify-between overflow-y-auto max-h-screen lg:max-h-[calc(100vh-65px)] lg:sticky lg:top-[65px] z-40 transition-all duration-300 lg:static lg:block print:hidden ${
          isSidebarOpen ? 'translate-x-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md shadow-2xl' : 'translate-x-full lg:translate-x-0'
        }`} id="app-sidebar-panel">
          
          <div className="space-y-6">
            {/* Mobile close button */}
            <div className="flex items-center justify-between lg:hidden pb-3 border-b border-slate-50">
              <span className="text-xs font-bold text-slate-400">منوی مانی</span>
              <button 
                onClick={() => setIsSidebarOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg"
              >
                <X size={18} />
              </button>
            </div>

            {/* Navigation links */}
            <nav className="space-y-1.5" id="sidebar-navigation">
              
              {/* 1. داشبورد */}
              <div 
                onClick={() => { 
                  setCurrentTab('dashboard'); 
                  setSelectedInvoiceId(null); 
                  setSubTabAction(null); 
                  setExpandedMenu(null);
                  setIsSidebarOpen(false); 
                }}
                className={getTabClass(currentTab === 'dashboard')}
              >
                <LayoutDashboard size={16} />
                <span>داشبورد</span>
              </div>

              {/* 2. اشخاص */}
              <div className="space-y-1">
                <div 
                  onClick={() => { toggleExpand('contacts', 'contacts'); }}
                  className={`${getTabClass(currentTab === 'contacts')} flex items-center justify-between w-full`}
                >
                  <div className="flex items-center gap-3.5">
                    <Users size={16} />
                    <span>اشخاص</span>
                  </div>
                  {expandedMenu === 'contacts' ? <ChevronDown size={14} className="opacity-60" /> : <ChevronRight size={14} className="opacity-60" />}
                </div>
                {expandedMenu === 'contacts' && (
                  <div className="bg-slate-100/60 p-1.5 rounded-xl border border-slate-200/40 space-y-0.5 mt-1 mr-4">
                    {renderSubItem('شخص جدید', () => { setCurrentTab('contacts'); setSubTabAction({ tab: 'contacts', action: 'add-contact' }); setIsSidebarOpen(false); }, subTabAction?.action === 'add-contact')}
                    {renderSubItem('اشخاص', () => { setCurrentTab('contacts'); setSubTabAction({ tab: 'contacts', action: 'list-all' }); setIsSidebarOpen(false); }, subTabAction?.action === 'list-all')}
                    <SubDivider />
                    {renderSubItem('دریافت', () => { setCurrentTab('receipts'); setSubTabAction({ tab: 'receipts', action: 'add-receipt' }); setIsSidebarOpen(false); }, currentTab === 'receipts' && subTabAction?.action === 'add-receipt')}
                    {renderSubItem('لیست دریافت ها', () => { setCurrentTab('receipts'); setSubTabAction({ tab: 'receipts', action: 'list-receipts' }); setIsSidebarOpen(false); }, currentTab === 'receipts' && subTabAction?.action === 'list-receipts')}
                    <SubDivider />
                    {renderSubItem('پرداخت', () => { setCurrentTab('payments'); setSubTabAction({ tab: 'payments', action: 'add-payment' }); setIsSidebarOpen(false); }, currentTab === 'payments' && subTabAction?.action === 'add-payment')}
                    {renderSubItem('لیست پرداخت ها', () => { setCurrentTab('payments'); setSubTabAction({ tab: 'payments', action: 'list-payments' }); setIsSidebarOpen(false); }, currentTab === 'payments' && subTabAction?.action === 'list-payments')}
                    <SubDivider />
                    {renderSubItem('سهامداران', () => { setCurrentTab('shareholders'); setSubTabAction(null); setIsSidebarOpen(false); }, currentTab === 'shareholders')}
                    <SubDivider />
                    {renderSubItem('فروشندگان', () => { setCurrentTab('sellers'); setSubTabAction(null); setIsSidebarOpen(false); }, currentTab === 'sellers')}
                  </div>
                )}
              </div>

              {/* 3. کالاها و خدمات */}
              <div className="space-y-1">
                <div 
                  onClick={() => { toggleExpand('items', 'items'); }}
                  className={`${getTabClass(currentTab === 'items')} flex items-center justify-between w-full`}
                >
                  <div className="flex items-center gap-3.5">
                    <Package size={16} />
                    <span>کالاها و خدمات</span>
                  </div>
                  {expandedMenu === 'items' ? <ChevronDown size={14} className="opacity-60" /> : <ChevronRight size={14} className="opacity-60" />}
                </div>
                {expandedMenu === 'items' && (
                  <div className="bg-slate-100/60 p-1.5 rounded-xl border border-slate-200/40 space-y-0.5 mt-1 mr-4">
                    {renderSubItem('کالای جدید', () => { setCurrentTab('items'); setSubTabAction({ tab: 'items', action: 'add-item' }); setIsSidebarOpen(false); }, subTabAction?.action === 'add-item')}
                    {renderSubItem('خدمات جدید', () => { setCurrentTab('items'); setSubTabAction({ tab: 'items', action: 'add-service' }); setIsSidebarOpen(false); }, subTabAction?.action === 'add-service')}
                    {renderSubItem('کالاها و خدمات', () => { setCurrentTab('items'); setSubTabAction({ tab: 'items', action: 'list' }); setIsSidebarOpen(false); }, subTabAction?.action === 'list')}
                    <SubDivider />
                    {renderSubItem('به روز رسانی لیست قیمت', () => { setToast({ message: 'به‌روزرسانی خودکار نرخ کالا در نسخه آزمایشی فعال است', type: 'info' }); }, false)}
                    <SubDivider />
                    {renderSubItem('ساخت بارکد', () => { setToast({ message: 'تولید بارکد استاندارد فعال شد', type: 'info' }); }, false)}
                    {renderSubItem('چاپ بارکد', () => { setToast({ message: 'پیش‌نمایش برچسب بارکد آماده چاپ است', type: 'info' }); }, false)}
                    {renderSubItem('چاپ بارکد تعدادی', () => { setToast({ message: 'چاپ دسته‌ای بارکد اقلام', type: 'info' }); }, false)}
                    <SubDivider />
                    {renderSubItem('صفحه لیست قیمت کالا', () => { setToast({ message: 'خروجی لیست قیمت رسمی آماده شد', type: 'info' }); }, false)}
                  </div>
                )}
              </div>

              {/* 4. بانکداری */}
              <div className="space-y-1">
                <div 
                  onClick={() => { toggleExpand('treasury', 'treasury'); }}
                  className={`${getTabClass(currentTab === 'treasury')} flex items-center justify-between w-full`}
                >
                  <div className="flex items-center gap-3.5">
                    <Building size={16} />
                    <span>بانکداری</span>
                  </div>
                  {expandedMenu === 'treasury' ? <ChevronDown size={14} className="opacity-60" /> : <ChevronRight size={14} className="opacity-60" />}
                </div>
                {expandedMenu === 'treasury' && (
                  <div className="bg-slate-100/60 p-1.5 rounded-xl border border-slate-200/40 space-y-0.5 mt-1 mr-4">
                    {renderSubItem('بانک ها', () => { setCurrentTab('treasury'); setSubTabAction({ tab: 'treasury', action: 'banks-list' }); setIsSidebarOpen(false); }, subTabAction?.action === 'banks-list')}
                    {renderSubItem('صندوق ها', () => { setCurrentTab('treasury'); setSubTabAction({ tab: 'treasury', action: 'banks-list' }); setIsSidebarOpen(false); }, false)}
                    {renderSubItem('تنخواه گردان ها', () => { setCurrentTab('treasury'); setToast({ message: 'لیست تنخواه‌گردان‌های فعال صندوق', type: 'info' }); }, false)}
                    <SubDivider />
                    {renderSubItem('انتقال', () => { setCurrentTab('treasury'); setSubTabAction({ tab: 'treasury', action: 'add-transfer' }); setIsSidebarOpen(false); }, subTabAction?.action === 'add-transfer')}
                    {renderSubItem('لیست انتقال ها', () => { setCurrentTab('treasury'); setSubTabAction({ tab: 'treasury', action: 'list-transfers' }); setIsSidebarOpen(false); }, subTabAction?.action === 'list-transfers')}
                    <SubDivider />
                    {renderSubItem('لیست چک های دریافتی', () => { setToast({ message: 'نمایش پوشه چک‌های واگذار شده و سررسید', type: 'info' }); }, false)}
                    {renderSubItem('لیست چک های پرداختی', () => { setToast({ message: 'نمایش پوشه چک‌های صادر شده مانی', type: 'info' }); }, false)}
                  </div>
                )}
              </div>

              {/* 5. فروش و درآمد */}
              <div className="space-y-1">
                <div 
                  onClick={() => { toggleExpand('sales', 'invoices'); setSelectedInvoiceId(null); setSubTabAction({ tab: 'invoices', action: 'list-sales' }); }}
                  className={`${getTabClass(currentTab === 'invoices' && (subTabAction?.action === 'list-sales' || subTabAction?.action === 'add-sales'))} flex items-center justify-between w-full`}
                >
                  <div className="flex items-center gap-3.5">
                    <ArrowUpRight size={16} />
                    <span>فروش و درآمد</span>
                  </div>
                  {expandedMenu === 'sales' ? <ChevronDown size={14} className="opacity-60" /> : <ChevronRight size={14} className="opacity-60" />}
                </div>
                {expandedMenu === 'sales' && (
                  <div className="bg-slate-100/60 p-1.5 rounded-xl border border-slate-200/40 space-y-0.5 mt-1 mr-4">
                    {renderSubItem('فروش جدید', () => { setCurrentTab('invoices'); setSelectedInvoiceId(null); setSubTabAction({ tab: 'invoices', action: 'add-sales' }); setIsSidebarOpen(false); }, subTabAction?.action === 'add-sales')}
                    {renderSubItem('فاکتور سریع', () => { setCurrentTab('invoices'); setSelectedInvoiceId(null); setSubTabAction({ tab: 'invoices', action: 'add-sales' }); setIsSidebarOpen(false); }, false)}
                    {renderSubItem('برگشت از فروش', () => { setToast({ message: 'ثبت فاکتور برگشت از فروش مشتریان', type: 'info' }); }, false)}
                    {renderSubItem('فاکتورهای فروش', () => { setCurrentTab('invoices'); setSelectedInvoiceId(null); setSubTabAction({ tab: 'invoices', action: 'list-sales' }); setIsSidebarOpen(false); }, subTabAction?.action === 'list-sales')}
                    {renderSubItem('فاکتورهای برگشت از فروش', () => { setToast({ message: 'آرشیو کل صورتحساب‌های اصلاحی برگشتی', type: 'info' }); }, false)}
                    <SubDivider />
                    {renderSubItem('درآمد', () => { setToast({ message: 'ثبت درآمد متفرقه غیرعملیاتی', type: 'info' }); }, false)}
                    {renderSubItem('لیست درآمدها', () => { setToast({ message: 'لیست درآمدهای ثبت شده متفرقه', type: 'info' }); }, false)}
                    <SubDivider />
                    {renderSubItem('قرارداد فروش اقساطی', () => { setToast({ message: 'تنظیم تفاهم‌نامه و دفترچه اقساط خریدار', type: 'info' }); }, false)}
                    {renderSubItem('لیست فروش اقساطی', () => { setToast({ message: 'لیست قراردادهای اقساطی فعال مشتریان', type: 'info' }); }, false)}
                    <SubDivider />
                    {renderSubItem('اقلام تخفیف دار', () => { setToast({ message: 'نمایش کالاهای دارای تخفیف دوره‌ای', type: 'info' }); }, false)}
                  </div>
                )}
              </div>

              {/* 6. خرید و هزینه */}
              <div className="space-y-1">
                <div 
                  onClick={() => { toggleExpand('purchase', 'invoices'); setSelectedInvoiceId(null); setSubTabAction({ tab: 'invoices', action: 'list-purchase' }); }}
                  className={`${getTabClass(currentTab === 'invoices' && (subTabAction?.action === 'list-purchase' || subTabAction?.action === 'add-purchase'))} flex items-center justify-between w-full`}
                >
                  <div className="flex items-center gap-3.5">
                    <ArrowDownLeft size={16} />
                    <span>خرید و هزینه</span>
                  </div>
                  {expandedMenu === 'purchase' ? <ChevronDown size={14} className="opacity-60" /> : <ChevronRight size={14} className="opacity-60" />}
                </div>
                {expandedMenu === 'purchase' && (
                  <div className="bg-slate-100/60 p-1.5 rounded-xl border border-slate-200/40 space-y-0.5 mt-1 mr-4">
                    {renderSubItem('خرید جدید', () => { setCurrentTab('invoices'); setSelectedInvoiceId(null); setSubTabAction({ tab: 'invoices', action: 'add-purchase' }); setIsSidebarOpen(false); }, subTabAction?.action === 'add-purchase')}
                    {renderSubItem('برگشت از خرید', () => { setToast({ message: 'ثبت فاکتور مرجوعی کالا به تامین‌کننده', type: 'info' }); }, false)}
                    {renderSubItem('فاکتورهای خرید', () => { setCurrentTab('invoices'); setSelectedInvoiceId(null); setSubTabAction({ tab: 'invoices', action: 'list-purchase' }); setIsSidebarOpen(false); }, subTabAction?.action === 'list-purchase')}
                    {renderSubItem('فاکتورهای برگشت از خرید', () => { setToast({ message: 'دفتر کل برگشت از خریدهای ثبت شده', type: 'info' }); }, false)}
                    <SubDivider />
                    {renderSubItem('هزینه', () => { setToast({ message: 'ثبت سند هزینه اداری، توزیع یا عمومی', type: 'info' }); }, false)}
                    {renderSubItem('لیست هزینه ها', () => { setToast({ message: 'مرور کل فاکتورهای هزینه‌ای ثبت شده', type: 'info' }); }, false)}
                    <SubDivider />
                    {renderSubItem('ضایعات', () => { setToast({ message: 'اعلام خروج ضایعات و کسری از انبار', type: 'info' }); }, false)}
                    {renderSubItem('لیست ضایعات', () => { setToast({ message: 'بایگانی برگه‌های ضایعات ثبت شده', type: 'info' }); }, false)}
                  </div>
                )}
              </div>

              {/* 7. تولید */}
              <div className="space-y-1">
                <div 
                  onClick={() => { toggleExpand('production', 'production'); }}
                  className={`${getTabClass(currentTab === 'production')} flex items-center justify-between w-full`}
                >
                  <div className="flex items-center gap-3.5">
                    <Cpu size={16} />
                    <span>تولید</span>
                  </div>
                  {expandedMenu === 'production' ? <ChevronDown size={14} className="opacity-60" /> : <ChevronRight size={14} className="opacity-60" />}
                </div>
                {expandedMenu === 'production' && (
                  <div className="bg-slate-100/60 p-1.5 rounded-xl border border-slate-200/40 space-y-0.5 mt-1 mr-4">
                    {renderSubItem('فرمول تولید', () => { setCurrentTab('production'); setSubTabAction({ tab: 'production', action: 'new-formula' }); setIsSidebarOpen(false); }, subTabAction?.action === 'new-formula')}
                    {renderSubItem('لیست فرمول تولید', () => { setCurrentTab('production'); setSubTabAction({ tab: 'production', action: 'new-formula' }); setIsSidebarOpen(false); }, false)}
                    {renderSubItem('نیازسنجی مواد', () => { setCurrentTab('production'); setSubTabAction({ tab: 'production', action: 'requirements' }); setIsSidebarOpen(false); }, subTabAction?.action === 'requirements')}
                    {renderSubItem('به روز رسانی مبالغ فرمول تولید', () => { setToast({ message: 'تعدیل مجدد قیمت تمام‌شده فرمول‌ها انجام شد', type: 'info' }); }, false, 'جدید')}
                    <SubDivider />
                    {renderSubItem('لیست سفارش های تولید', () => { setCurrentTab('production'); setSubTabAction({ tab: 'production', action: 'new-order' }); setIsSidebarOpen(false); }, true)}
                    {renderSubItem('دستور تولید', () => { setCurrentTab('production'); setSubTabAction({ tab: 'production', action: 'new-order' }); setIsSidebarOpen(false); }, subTabAction?.action === 'new-order')}
                    {renderSubItem('لیست دستور تولید', () => { setCurrentTab('production'); setSubTabAction({ tab: 'production', action: 'new-order' }); setIsSidebarOpen(false); }, false)}
                  </div>
                )}
              </div>

              {/* 8. انبارداری */}
              <div className="space-y-1">
                <div 
                  onClick={() => { toggleExpand('warehousing', 'warehousing'); }}
                  className={`${getTabClass(currentTab === 'warehousing')} flex items-center justify-between w-full`}
                >
                  <div className="flex items-center gap-3.5">
                    <Boxes size={16} />
                    <span>انبارداری</span>
                  </div>
                  {expandedMenu === 'warehousing' ? <ChevronDown size={14} className="opacity-60" /> : <ChevronRight size={14} className="opacity-60" />}
                </div>
                {expandedMenu === 'warehousing' && (
                  <div className="bg-slate-100/60 p-1.5 rounded-xl border border-slate-200/40 space-y-0.5 mt-1 mr-4">
                    {renderSubItem('انبارها', () => { setCurrentTab('warehousing'); setSubTabAction({ tab: 'warehousing', action: 'warehouses-list' }); setIsSidebarOpen(false); }, subTabAction?.action === 'warehouses-list')}
                    <SubDivider />
                    {renderSubItem('حواله جدید', () => { setCurrentTab('warehousing'); setSubTabAction({ tab: 'warehousing', action: 'new-transfer' }); setIsSidebarOpen(false); }, subTabAction?.action === 'new-transfer')}
                    <SubDivider />
                    {renderSubItem('رسید و حواله های انبار', () => { setCurrentTab('warehousing'); setSubTabAction({ tab: 'warehousing', action: 'inventory-list' }); setIsSidebarOpen(false); }, true)}
                    <SubDivider />
                    {renderSubItem('موجودی کالا', () => { setCurrentTab('warehousing'); setSubTabAction({ tab: 'warehousing', action: 'inventory-list' }); setIsSidebarOpen(false); }, subTabAction?.action === 'inventory-list')}
                    {renderSubItem('موجودی تمامی انبارها', () => { setCurrentTab('warehousing'); setSubTabAction({ tab: 'warehousing', action: 'inventory-list' }); setIsSidebarOpen(false); }, false)}
                    <SubDivider />
                    {renderSubItem('انبارگردانی', () => { setCurrentTab('warehousing'); setSubTabAction({ tab: 'warehousing', action: 'audit-start' }); setIsSidebarOpen(false); }, subTabAction?.action === 'audit-start')}
                  </div>
                )}
              </div>

              {/* 9. حسابداری */}
              <div className="space-y-1">
                <div 
                  onClick={() => { toggleExpand('accounting', 'accounting'); }}
                  className={`${getTabClass(currentTab === 'accounting')} flex items-center justify-between w-full`}
                >
                  <div className="flex items-center gap-3.5">
                    <Calculator size={16} />
                    <span>حسابداری</span>
                  </div>
                  {expandedMenu === 'accounting' ? <ChevronDown size={14} className="opacity-60" /> : <ChevronRight size={14} className="opacity-60" />}
                </div>
                {expandedMenu === 'accounting' && (
                  <div className="bg-slate-100/60 p-1.5 rounded-xl border border-slate-200/40 space-y-0.5 mt-1 mr-4">
                    {renderSubItem('سند جدید', () => { setCurrentTab('accounting'); setSubTabAction({ tab: 'accounting', action: 'new-entry' }); setIsSidebarOpen(false); }, subTabAction?.action === 'new-entry')}
                    {renderSubItem('لیست اسناد', () => { setCurrentTab('accounting'); setSubTabAction({ tab: 'accounting', action: 'new-entry' }); setIsSidebarOpen(false); }, false)}
                    <SubDivider />
                    {renderSubItem('تراز افتتاحیه', () => { setCurrentTab('accounting'); setSubTabAction({ tab: 'accounting', action: 'opening-balance' }); setIsSidebarOpen(false); }, true)}
                    <SubDivider />
                    {renderSubItem('بستن سال مالی', () => { setCurrentTab('accounting'); setSubTabAction({ tab: 'accounting', action: 'closing-year' }); setIsSidebarOpen(false); }, subTabAction?.action === 'closing-year')}
                    <SubDivider />
                    {renderSubItem('جدول حساب ها', () => { setCurrentTab('accounting'); setSubTabAction({ tab: 'accounting', action: 'accounts-chart' }); setIsSidebarOpen(false); }, subTabAction?.action === 'accounts-chart')}
                    <SubDivider />
                    {renderSubItem('تجمیع اسناد', () => { setToast({ message: 'تجمیع خودکار اسناد حسابداری انجام شد', type: 'success' }); }, false)}
                  </div>
                )}
              </div>

              {/* 10. سایر */}
              <div className="space-y-1">
                <div 
                  onClick={() => { toggleExpand('other', 'other'); }}
                  className={`${getTabClass(currentTab === 'other')} flex items-center justify-between w-full`}
                >
                  <div className="flex items-center gap-3.5">
                    <Grid size={16} />
                    <span>سایر</span>
                  </div>
                  {expandedMenu === 'other' ? <ChevronDown size={14} className="opacity-60" /> : <ChevronRight size={14} className="opacity-60" />}
                </div>
                {expandedMenu === 'other' && (
                  <div className="bg-slate-100/60 p-1.5 rounded-xl border border-slate-200/40 space-y-0.5 mt-1 mr-4">
                    {renderSubItem('آرشیو', () => { setCurrentTab('other'); setSubTabAction({ tab: 'other', action: 'document-archive' }); setIsSidebarOpen(false); }, subTabAction?.action === 'document-archive')}
                    {renderSubItem('پنل پیامک', () => { setCurrentTab('other'); setSubTabAction({ tab: 'other', action: 'sms-panel' }); setIsSidebarOpen(false); }, subTabAction?.action === 'sms-panel')}
                    {renderSubItem('سامانه مودیان', () => { setCurrentTab('other'); setSubTabAction({ tab: 'other', action: 'tax-authority' }); setIsSidebarOpen(false); }, subTabAction?.action === 'tax-authority')}
                    {renderSubItem('استعلام', () => { setToast({ message: 'استعلام آنی کد اقتصادی و مشخصات مودی', type: 'info' }); }, false)}
                    <SubDivider />
                    {renderSubItem('دریافت سایر', () => { setToast({ message: 'ثبت سایر دریافتی‌های صندوق و بانک', type: 'info' }); }, false)}
                    {renderSubItem('لیست دریافت ها', () => { setToast({ message: 'مشاهده لیست آرشیو سایر دریافت‌ها', type: 'info' }); }, false)}
                    <SubDivider />
                    {renderSubItem('پرداخت سایر', () => { setToast({ message: 'ثبت سایر پرداخت‌های متفرقه مانی', type: 'info' }); }, false)}
                    {renderSubItem('لیست پرداخت ها', () => { setToast({ message: 'مشاهده لیست آرشیو سایر پرداخت‌ها', type: 'info' }); }, false)}
                    <SubDivider />
                    {renderSubItem('سند تسعیر ارز', () => { setToast({ message: 'محاسبه سود و زیان تسعیر ارزهای خارجی', type: 'info' }); }, false)}
                    {renderSubItem('سند توازن اشخاص', () => { setToast({ message: 'توازن مانده معین حساب اشخاص به صورت خودکار', type: 'info' }); }, false)}
                    {renderSubItem('سند توازن کالاها', () => { setToast({ message: 'رفع مغایرت کارهای انبارگردانی به صورت خودکار', type: 'info' }); }, false)}
                    {renderSubItem('سند حقوق', () => { setToast({ message: 'صدور لیست و فیش حقوق پرسنلی', type: 'info' }); }, false)}
                  </div>
                )}
              </div>

              {/* 11. گزارش ها */}
              <div className="space-y-1">
                <div 
                  onClick={() => { toggleExpand('reports', 'reports'); }}
                  className={`${getTabClass(currentTab === 'reports')} flex items-center justify-between w-full`}
                >
                  <div className="flex items-center gap-3.5">
                    <FilePieChart size={16} />
                    <span>گزارش ها</span>
                  </div>
                  {expandedMenu === 'reports' ? <ChevronDown size={14} className="opacity-60" /> : <ChevronRight size={14} className="opacity-60" />}
                </div>
                {expandedMenu === 'reports' && (
                  <div className="bg-slate-100/60 p-1.5 rounded-xl border border-slate-200/40 space-y-0.5 mt-1 mr-4 max-h-72 overflow-y-auto">
                    {renderSubItem('تمام گزارش ها', () => { setCurrentTab('reports'); setIsSidebarOpen(false); }, false)}
                    {renderSubItem('ترازنامه', () => { setCurrentTab('reports'); setIsSidebarOpen(false); }, false)}
                    {renderSubItem('صورت سود و زیان', () => { setCurrentTab('reports'); setIsSidebarOpen(false); }, false)}
                    {renderSubItem('صورتحساب سرمایه', () => { setToast({ message: 'نمایش گزارش رسمی حقوق مالکانه و سرمایه', type: 'info' }); }, false)}
                    {renderSubItem('دفتر روزنامه', () => { setToast({ message: 'نمایش دفتر روزنامه اسناد حسابداری مانی', type: 'info' }); }, false)}
                    {renderSubItem('دفتر حساب ها', () => { setToast({ message: 'نمایش معین حساب کل و تفصیلی', type: 'info' }); }, false)}
                    {renderSubItem('دفتر کل', () => { setToast({ message: 'خروجی رسمی دفتر کل جهت تسلیم به دارایی', type: 'info' }); }, false)}
                    {renderSubItem('تراز آزمایشی', () => { setToast({ message: 'تراز آزمایشی ۲، ۴ و ۶ ستونی معین', type: 'info' }); }, false)}
                    {renderSubItem('مرور حساب های تفصیل', () => { setToast({ message: 'گزارش درختی کل به تفصیلی', type: 'info' }); }, false)}
                    {renderSubItem('دفتر روزنامه (تجمیعی)', () => { setToast({ message: 'دفتر روزنامه خلاصه شده ماهانه', type: 'info' }); }, false)}
                    {renderSubItem('دفتر کل (تجمیعی)', () => { setToast({ message: 'دفتر کل تجمیع شده ماهانه', type: 'info' }); }, false)}
                    {renderSubItem('بدهکاران و بستانکاران', () => { setToast({ message: 'نمایش گزارش سنی و مانده بدهکاران و بستانکاران', type: 'info' }); }, false)}
                    {renderSubItem('کارت حساب اشخاص', () => { setToast({ message: 'کاردکس ریز تراکنش‌های مالی یک مخاطب', type: 'info' }); }, false)}
                    {renderSubItem('موجودی کالا', () => { setToast({ message: 'نمایش موجودی واقعی و تعهد شده فیزیکی', type: 'info' }); }, false)}
                    {renderSubItem('کارت حساب کالا', () => { setToast({ message: 'کاردکس ورود و خروج مقداری و ریالی کالا', type: 'info' }); }, false)}
                    {renderSubItem('گزارش شماره سریال', () => { setToast({ message: 'پایش گارانتی و رهگیری سریال نامبرها', type: 'info' }); }, false)}
                    {renderSubItem('فروش به تفکیک کالا', () => { setToast({ message: 'نمایش حجم ریالی فروش هر کالا در بازه زمانی', type: 'info' }); }, false)}
                    {renderSubItem('خرید به تفکیک کالا', () => { setToast({ message: 'نمایش حجم ریالی خرید هر کالا در بازه زمانی', type: 'info' }); }, false)}
                    {renderSubItem('فروش به تفکیک فاکتور', () => { setToast({ message: 'تحلیل آماری و درصد حاشیه سود هر فاکتور', type: 'info' }); }, false)}
                    {renderSubItem('خرید به تفکیک فاکتور', () => { setToast({ message: 'تحلیل بهای تمام شده فاکتورهای ورودی', type: 'info' }); }, false)}
                    {renderSubItem('گزارش مالیات', () => { setToast({ message: 'محاسبه اظهارنامه بر ارزش افزوده و فصلی', type: 'info' }); }, false)}
                    {renderSubItem('سود فاکتور', () => { setToast({ message: 'گزارش سود و زیان ناویژه فاکتورهای صادر شده', type: 'info' }); }, false)}
                    {renderSubItem('خلاصه فاکتور به تفکیک شخص', () => { setToast({ message: 'میزان تراکنش‌های کلی هر مشتری', type: 'info' }); }, false)}
                    {renderSubItem('فروش به تفکیک فروشنده', () => { setToast({ message: 'محاسبه پورسانت و بازدهی بازاریاب‌ها', type: 'info' }); }, false)}
                    {renderSubItem('گزارش وضعیت اقساط', () => { setToast({ message: 'پایش اقساط معوق و پرداختی خریداران', type: 'info' }); }, false)}
                    {renderSubItem('گردش حساب بانک', () => { setToast({ message: 'کاردکس ریز بانک‌های منتخب', type: 'info' }); }, false)}
                    {renderSubItem('گردش حساب صندوق', () => { setToast({ message: 'کاردکس ریز تراکنش‌های صندوق نقدی', type: 'info' }); }, false)}
                    {renderSubItem('گردش حساب تنخواه گردان', () => { setToast({ message: 'گزارش بیلان شارژ و هزینه‌های تنخواه', type: 'info' }); }, false)}
                    {renderSubItem('کارت پروژه', () => { setToast({ message: 'گزارش سود و زیان و عملکرد مالی پروژه منتخب', type: 'info' }); }, false)}
                    {renderSubItem('لاگ کاربران', () => { setToast({ message: 'نمایش لاگ مانیتورینگ امنیتی فعالیت کاربران', type: 'info' }); }, false)}
                  </div>
                )}
              </div>

              {/* 12. تنظیمات */}
              <div className="space-y-1">
                <div 
                  onClick={() => { toggleExpand('settings', 'settings'); }}
                  className={`${getTabClass(currentTab === 'settings')} flex items-center justify-between w-full`}
                >
                  <div className="flex items-center gap-3.5">
                    <SettingsIcon size={16} />
                    <span>تنظیمات</span>
                  </div>
                  {expandedMenu === 'settings' ? <ChevronDown size={14} className="opacity-60" /> : <ChevronRight size={14} className="opacity-60" />}
                </div>
                {expandedMenu === 'settings' && (
                  <div className="bg-slate-100/60 p-1.5 rounded-xl border border-slate-200/40 space-y-0.5 mt-1 mr-4">
                    {renderSubItem('پروژه ها', () => { setToast({ message: 'تعریف پروژه‌ها و مراکز هزینه شرکت مانی', type: 'info' }); }, false)}
                    {renderSubItem('اطلاعات کسب و کار', () => { setCurrentTab('settings'); setIsSidebarOpen(false); }, false)}
                    {renderSubItem('تنظیمات مالی', () => { setCurrentTab('settings'); setIsSidebarOpen(false); }, false)}
                    {renderSubItem('جدول تبدیل نرخ ارز', () => { setToast({ message: 'تعیین ارز پایه و نرخ تسعیر روزانه صرافی', type: 'info' }); }, false)}
                    {renderSubItem('مدیریت کاربران', () => { setToast({ message: 'تعریف پرسنل و دسترسی‌های کاربران سیستم', type: 'info' }); }, false)}
                    {renderSubItem('تنظیمات چاپ', () => { setCurrentTab('settings'); setIsSidebarOpen(false); }, false)}
                    {renderSubItem('فرم ساز', () => { setToast({ message: 'طراحی قالب دلخواه فاکتور و اسناد رسمی', type: 'info' }); }, false)}
                    {renderSubItem('اعلانات', () => { setToast({ message: 'تنظیم هشدارهای سررسید چک و بدهی‌ها', type: 'info' }); }, false)}
                  </div>
                )}
              </div>

            </nav>
          </div>

          {/* Sidebar Footer credit */}
          <div className="pt-4 mt-6 border-t border-slate-200/20 text-[10px] text-slate-400 leading-relaxed text-center">
            <Building size={14} className="mx-auto mb-1 text-slate-300" />
            <div>سامانه مالی و حسابداری مانی</div>
            <div className="font-mono mt-0.5">v4.0.0 - Cloud Integrated ERP</div>
          </div>

        </aside>

        {/* Sidebar overlay backdrop on mobile */}
        {isSidebarOpen && (
          <div 
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/20 backdrop-blur-xs z-30 lg:hidden"
          ></div>
        )}

        {/* MAIN BODY AREA */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          
          {/* Breadcrumb / Section Header (except print view) */}
          {!selectedInvoiceId && (
            <div className="mb-6 pb-4 border-b border-slate-200/60 flex items-center justify-between print:hidden">
              <div>
                <h2 className="text-base font-black text-slate-800">
                  {currentTab === 'dashboard' && 'پیشخوان هوشمند مانی'}
                  {currentTab === 'contacts' && 'اشخاص و همکاران تجاری'}
                  {currentTab === 'items' && 'انبار کالاها و تعرفه خدمات'}
                  {currentTab === 'invoices' && 'ثبت فاکتورهای فروش و خرید'}
                  {currentTab === 'treasury' && 'سیستم خزانه‌داری، دریافت و پرداخت'}
                  {currentTab === 'receipts' && 'ثبت دریافت‌ها و اسناد خزانه‌داری'}
                  {currentTab === 'payments' && 'ثبت پرداخت‌ها و اسناد خزانه‌داری'}
                  {currentTab === 'reports' && 'اسناد حسابداری و بیلان مالی'}
                  {currentTab === 'settings' && 'تنظیمات رسمی و پیکربندی'}
                  {currentTab === 'production' && 'سیستم مدیریت و فرآیند تولید مانی'}
                  {currentTab === 'warehousing' && 'انبارداری نوین و کاردکس کالا'}
                  {currentTab === 'accounting' && 'دفترداری، اسناد حسابداری و معین'}
                  {currentTab === 'other' && 'سایر بخش‌ها و درگاه‌های مانی'}
                </h2>
                <p className="text-[10px] text-slate-400 mt-1">
                  {currentTab === 'dashboard' && 'نمایش کلان وضعیت مالی، سود و زیان، بانک‌ها و یادداشت‌های امروز'}
                  {currentTab === 'contacts' && 'مدیریت و پایش مانده حساب مشتریان، خریداران و تامین‌کنندگان'}
                  {currentTab === 'items' && 'کنترل موجودی انبار، تعرفه فروش کالاها و مدیریت خدمات ارائه‌شده'}
                  {currentTab === 'invoices' && 'مدیریت کل فاکتورها، صدور صورتحساب رسمی فروش و ثبت خریدهای انبار'}
                  {currentTab === 'treasury' && 'گردش نقد صندوق‌ها، شارژ تنخواه، انتقال بین‌بانکی و ثبت اسناد نقدی'}
                  {currentTab === 'receipts' && 'صدور رسید دریافت وجه، حواله نقد، فیش عابربانک، بابت تسویه فاکتورها یا بستانکاری طرف حساب‌ها'}
                  {currentTab === 'payments' && 'صدور رسید پرداخت وجه، حواله نقد، فیش عابربانک، بابت تسویه فاکتورها یا بدهکاری طرف حساب‌ها'}
                  {currentTab === 'reports' && 'دفتر روزنامه معین، محاسبه تراز ترازنامه و مانیتور سرفصل‌های درآمد/هزینه'}
                  {currentTab === 'settings' && 'ویرایش اطلاعات سربرگ فاکتور، شناسه‌های اقتصادی و ریست دیتابیس دمو'}
                  {currentTab === 'production' && 'تعریف فرمول ساخت (BOM)، برنامه‌ریزی سفارشات و پایش لحظه‌ای خط تولید صنعتی'}
                  {currentTab === 'warehousing' && 'کاردکس کالا، حواله انتقال انبار به انبار، بستانکاری فیزیکی و انبارگردانی'}
                  {currentTab === 'accounting' && 'ثبت سند دوبل روزنامه، پایش ساختار معین و کل، تراز آزمایشی و بستن سال مالی'}
                  {currentTab === 'other' && 'ارسال صورتحساب‌ها به سامانه مودیان کشور، پایش پنل پیامک اتوماتیک و آرشیو اسناد'}
                </p>
              </div>

              {/* Quick dynamic status badge */}
              <div className="hidden md:flex items-center gap-2 bg-blue-50/50 border border-blue-100 text-[10px] px-3 py-1.5 rounded-xl font-bold text-blue-700">
                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse"></span>
                <span>سندرسی خودکار: فعال</span>
              </div>
            </div>
          )}

          {/* ACTIVE TAB ROUTING */}
          {currentTab === 'dashboard' && (
            <Dashboard 
              contacts={contacts}
              invoices={invoices}
              banks={banks}
              transactions={transactions}
              tasks={tasks}
              setTasks={setTasks}
              setCurrentTab={setCurrentTab}
              setSelectedInvoiceId={setSelectedInvoiceId}
            />
          )}

          {currentTab === 'contacts' && (
            <Contacts 
              contacts={contacts}
              setContacts={setContacts}
              subTabAction={subTabAction}
              setSubTabAction={setSubTabAction}
            />
          )}

          {currentTab === 'items' && (
            <Items 
              items={items}
              setItems={setItems}
              subTabAction={subTabAction}
              setSubTabAction={setSubTabAction}
            />
          )}

          {currentTab === 'invoices' && (
            <Invoices 
              invoices={invoices}
              setInvoices={setInvoices}
              contacts={contacts}
              setContacts={setContacts}
              items={items}
              setItems={setItems}
              selectedInvoiceId={selectedInvoiceId}
              setSelectedInvoiceId={setSelectedInvoiceId}
              companyInfo={companyInfo}
              subTabAction={subTabAction}
              setSubTabAction={setSubTabAction}
            />
          )}

          {currentTab === 'treasury' && (
            <Treasury 
              banks={banks}
              setBanks={setBanks}
              transactions={transactions}
              setTransactions={setTransactions}
              contacts={contacts}
              setContacts={setContacts}
              subTabAction={subTabAction}
              setSubTabAction={setSubTabAction}
            />
          )}

          {currentTab === 'receipts' && (
            <Receipts 
              contacts={contacts}
              setContacts={setContacts}
              banks={banks}
              setBanks={setBanks}
              receipts={receipts}
              setReceipts={setReceipts}
              projects={projects}
              setProjects={setProjects}
              frequentDescriptions={frequentDescriptions}
              setFrequentDescriptions={setFrequentDescriptions}
              subTabAction={subTabAction}
              setSubTabAction={setSubTabAction}
              invoices={invoices}
              setInvoices={setInvoices}
              transactions={transactions}
              setTransactions={setTransactions}
            />
          )}

          {currentTab === 'payments' && (
            <Payments 
              contacts={contacts}
              setContacts={setContacts}
              banks={banks}
              setBanks={setBanks}
              payments={payments}
              setPayments={setPayments}
              projects={projects}
              setProjects={setProjects}
              frequentDescriptions={frequentDescriptions}
              setFrequentDescriptions={setFrequentDescriptions}
              subTabAction={subTabAction}
              setSubTabAction={setSubTabAction}
              invoices={invoices}
              setInvoices={setInvoices}
              transactions={transactions}
              setTransactions={setTransactions}
            />
          )}

          {currentTab === 'shareholders' && (
            <Shareholders 
              contacts={contacts}
              setContacts={setContacts}
              shareholders={shareholders}
              setShareholders={setShareholders}
              onBack={() => setCurrentTab('dashboard')}
            />
          )}

          {currentTab === 'sellers' && (
            <Sellers 
              contacts={contacts}
              setContacts={setContacts}
              sellers={sellers}
              setSellers={setSellers}
              items={items}
              setItems={setItems}
              onBack={() => setCurrentTab('dashboard')}
            />
          )}

          {currentTab === 'production' && (
            <Production 
              items={items}
              setItems={setItems}
              subTabAction={subTabAction}
              setSubTabAction={setSubTabAction}
            />
          )}

          {currentTab === 'warehousing' && (
            <Warehousing 
              items={items}
              setItems={setItems}
              subTabAction={subTabAction}
              setSubTabAction={setSubTabAction}
            />
          )}

          {currentTab === 'accounting' && (
            <Accounting 
              subTabAction={subTabAction}
              setSubTabAction={setSubTabAction}
            />
          )}

          {currentTab === 'other' && (
            <OtherFeatures 
              invoices={invoices}
              subTabAction={subTabAction}
              setSubTabAction={setSubTabAction}
            />
          )}

          {currentTab === 'reports' && (
            <Reports 
              contacts={contacts}
              invoices={invoices}
              banks={banks}
              transactions={transactions}
              items={items}
            />
          )}

          {currentTab === 'settings' && (
            <Settings 
              companyInfo={companyInfo}
              setCompanyInfo={setCompanyInfo}
              onResetDatabase={handleResetDatabase}
            />
          )}

        </main>

      </div>

      {/* Persistent Toast Notifications */}
      {toast && (
        <div 
          className="fixed bottom-6 left-6 z-50 flex items-center gap-3 bg-slate-900/95 text-white text-xs px-4 py-3.5 rounded-2xl shadow-xl backdrop-blur-md border border-slate-700/50 transition-all duration-300 animate-in fade-in slide-in-from-bottom-5 font-sans"
          id="global-toast"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse"></span>
          <span className="font-bold leading-none">{toast.message}</span>
        </div>
      )}

    </div>
  );
}
