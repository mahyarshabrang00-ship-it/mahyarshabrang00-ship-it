/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Contact, 
  BankAccount, 
  Receipt, 
  ReceiptItem, 
  Project, 
  Transaction,
  Invoice
} from '../types';
import { 
  Plus, 
  Trash2, 
  Edit3, 
  Eye, 
  Search, 
  Calendar, 
  Check, 
  X, 
  ArrowRight, 
  Settings, 
  Coins, 
  CheckCircle, 
  Info,
  ChevronLeft,
  ChevronRight,
  MoreHorizontal,
  User,
  List,
  FolderPlus
} from 'lucide-react';

interface ReceiptsProps {
  contacts: Contact[];
  setContacts: React.Dispatch<React.SetStateAction<Contact[]>>;
  banks: BankAccount[];
  setBanks: React.Dispatch<React.SetStateAction<BankAccount[]>>;
  receipts: Receipt[];
  setReceipts: React.Dispatch<React.SetStateAction<Receipt[]>>;
  projects: Project[];
  setProjects: React.Dispatch<React.SetStateAction<Project[]>>;
  frequentDescriptions: string[];
  setFrequentDescriptions: React.Dispatch<React.SetStateAction<string[]>>;
  subTabAction: { tab: string; action: string; payload?: any } | null;
  setSubTabAction: React.Dispatch<React.SetStateAction<{ tab: string; action: string; payload?: any } | null>>;
  invoices: Invoice[];
  setInvoices: React.Dispatch<React.SetStateAction<Invoice[]>>;
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
}

export default function Receipts({
  contacts,
  setContacts,
  banks,
  setBanks,
  receipts,
  setReceipts,
  projects,
  setProjects,
  frequentDescriptions,
  setFrequentDescriptions,
  subTabAction,
  setSubTabAction,
  invoices,
  setInvoices,
  transactions,
  setTransactions
}: ReceiptsProps) {
  
  // Tab/View control: 'list' or 'form'
  const [viewMode, setViewMode] = useState<'list' | 'form'>('list');
  const [listTab, setListTab] = useState<'all' | 'items'>('all');

  // Multi-select for list
  const [selectedReceiptIds, setSelectedReceiptIds] = useState<string[]>([]);

  // Modals state
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [isFreqDescOpen, setIsFreqDescOpen] = useState(false);
  const [isQuickContactOpen, setIsQuickContactOpen] = useState(false);
  const [viewDetailReceipt, setViewDetailReceipt] = useState<Receipt | null>(null);

  // Quick Project Form State
  const [newProjName, setNewProjName] = useState('');
  const [newProjActive, setNewProjActive] = useState(true);
  const [newProjDefault, setNewProjDefault] = useState(false);

  // Quick Contact Form State
  const [quickContactName, setQuickContactName] = useState('');
  const [quickContactPhone, setQuickContactPhone] = useState('');
  const [quickContactType, setQuickContactType] = useState<'customer' | 'supplier' | 'employee' | 'shareholder'>('customer');

  // Frequent Description State
  const [newFreqDesc, setNewFreqDesc] = useState('');

  // FORM STATE for single/multi-item Receipts
  const [receiptId, setReceiptId] = useState<string | null>(null);
  const [isAutoNum, setIsAutoNum] = useState(true);
  const [receiptNum, setReceiptNum] = useState('');
  const [accountingDoc, setAccountingDoc] = useState('');
  const [receiptDate, setReceiptDate] = useState(() => {
    return '۱۴۰۵/۰۴/۱۷'; // Default as per screenshot
  });
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [selectedCurrency, setSelectedCurrency] = useState('IRR - ریال ایران');
  const [globalDesc, setGlobalDesc] = useState('حواله انتقال');
  const [selectedBankId, setSelectedBankId] = useState('b1'); // deposit account

  // Receipt items list
  const [formItems, setFormItems] = useState<ReceiptItem[]>([
    { id: 'item_1', contactId: '', contactName: '', amount: 0, description: 'حواله انتقال' }
  ]);

  // Filters state for column-wise searching
  const [filterNum, setFilterNum] = useState('');
  const [filterDoc, setFilterDoc] = useState('');
  const [filterDate, setFilterDate] = useState('');
  const [filterContact, setFilterContact] = useState('');
  const [filterDesc, setFilterDesc] = useState('');
  const [filterProj, setFilterProj] = useState('');
  const [filterAmount, setFilterAmount] = useState('');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Currencies list matching Screenshot 2
  const currencies = [
    'IRR - ریال ایران',
    'AED - درهم امارات متحدهٔ عربی',
    'CAD - دلار کانادا',
    'EUR - یورو',
    'OMR - ریال عمان',
    'USD - دلار امریکا'
  ];

  // Handle external sidebar sub-navigation
  useEffect(() => {
    if (subTabAction && subTabAction.tab === 'receipts') {
      if (subTabAction.action === 'add-receipt') {
        // Reset and open form
        setReceiptId(null);
        setIsAutoNum(true);
        setReceiptNum('');
        setAccountingDoc('');
        setGlobalDesc('حواله انتقال');
        setSelectedProjectId('');
        setSelectedCurrency('IRR - ریال ایران');
        setFormItems([{ id: 'item_1', contactId: '', contactName: '', amount: 0, description: 'حواله انتقال' }]);
        setViewMode('form');
      } else if (subTabAction.action === 'list-receipts') {
        setViewMode('list');
      }
      setSubTabAction(null);
    }
  }, [subTabAction]);

  // Format Helper
  const formatMoney = (val: number) => {
    return val.toLocaleString('fa-IR');
  };

  // Generate next automatic receipt number
  const getNextReceiptNum = () => {
    if (receipts.length === 0) return '۱۰۰۱';
    const numbers = receipts
      .map(r => parseInt(r.number.replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))))
      .filter(n => !isNaN(n));
    if (numbers.length === 0) return '۱۰۰۱';
    const nextVal = Math.max(...numbers) + 1;
    // convert back to persian numbers
    return nextVal.toString().replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d)]);
  };

  // Generate next automatic doc number
  const getNextDocNum = () => {
    if (receipts.length === 0) return '۳';
    const docs = receipts
      .map(r => parseInt(r.accountingDocNo.replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))))
      .filter(n => !isNaN(n));
    if (docs.length === 0) return '۳';
    const nextVal = Math.max(...docs) + 2; // e.g. odd increments or sequential
    return nextVal.toString().replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d)]);
  };

  // Create Project
  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjName.trim()) return;

    const newProj: Project = {
      id: 'p_' + Date.now(),
      name: newProjName,
      isActive: newProjActive,
      isDefault: newProjDefault
    };

    // If default, unset previous defaults
    if (newProjDefault) {
      setProjects(projects.map(p => ({ ...p, isDefault: false })).concat(newProj));
    } else {
      setProjects([...projects, newProj]);
    }

    setSelectedProjectId(newProj.id);
    setNewProjName('');
    setNewProjActive(true);
    setNewProjDefault(false);
    setIsProjectModalOpen(false);
  };

  // Quick Create Contact
  const handleQuickCreateContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickContactName.trim()) return;

    const newContact: Contact = {
      id: 'c_' + Date.now(),
      code: String(contacts.length + 1).padStart(5, '0'),
      name: quickContactName,
      category: quickContactType === 'shareholder' ? 'سهامداران' : quickContactType === 'employee' ? 'کارمندان' : 'مشتری',
      type: quickContactType === 'customer' ? 'customer' : quickContactType === 'supplier' ? 'supplier' : quickContactType === 'employee' ? 'employee' : 'shareholder',
      phone: quickContactPhone,
      balance: 0,
      email: '',
      address: '',
      nationalId: ''
    };

    setContacts([...contacts, newContact]);
    setQuickContactName('');
    setQuickContactPhone('');
    setIsQuickContactOpen(false);
  };

  // Create Frequent Description
  const handleAddFreqDesc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFreqDesc.trim()) return;
    if (!frequentDescriptions.includes(newFreqDesc.trim())) {
      setFrequentDescriptions([...frequentDescriptions, newFreqDesc.trim()]);
    }
    setNewFreqDesc('');
  };

  // Delete Frequent Description
  const handleDeleteFreqDesc = (desc: string) => {
    setFrequentDescriptions(frequentDescriptions.filter(d => d !== desc));
  };

  // Form item operations
  const addFormItem = () => {
    const nextId = 'item_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4);
    setFormItems([...formItems, { id: nextId, contactId: '', contactName: '', amount: 0, description: globalDesc }]);
  };

  const removeFormItem = (id: string) => {
    if (formItems.length === 1) {
      alert('حداقل یک آیتم برای سند دریافت الزامی است.');
      return;
    }
    setFormItems(formItems.filter(item => item.id !== id));
  };

  const updateFormItem = (id: string, field: keyof ReceiptItem, value: any) => {
    setFormItems(formItems.map(item => {
      if (item.id === id) {
        if (field === 'contactId') {
          const contact = contacts.find(c => c.id === value);
          return { ...item, contactId: value, contactName: contact ? contact.name : '' };
        }
        return { ...item, [field]: value };
      }
      return item;
    }));
  };

  // Submit main receipt form
  const handleSubmitReceipt = (e: React.FormEvent) => {
    e.preventDefault();

    // Validations
    if (formItems.some(item => !item.contactId)) {
      alert('لطفاً شخص مربوط به تمامی ردیف‌ها را انتخاب کنید.');
      return;
    }

    if (formItems.some(item => item.amount <= 0)) {
      alert('مبلغ تمامی ردیف‌ها باید بیشتر از صفر باشد.');
      return;
    }

    const finalNum = isAutoNum ? getNextReceiptNum() : (receiptNum || '۱۰' + Date.now().toString().substr(-2));
    const finalDoc = accountingDoc || getNextDocNum();
    const projectObj = projects.find(p => p.id === selectedProjectId);

    const total = formItems.reduce((acc, curr) => acc + curr.amount, 0);

    const newReceipt: Receipt = {
      id: receiptId || 'rec_' + Date.now(),
      number: finalNum,
      accountingDocNo: finalDoc,
      date: receiptDate,
      project: projectObj ? projectObj.name : '',
      currency: selectedCurrency,
      description: globalDesc,
      items: formItems,
      totalAmount: total,
      accountName: 'حساب های دریافتنی'
    };

    // If editing, reverse the previous transactions and balances
    if (receiptId) {
      const oldRec = receipts.find(r => r.id === receiptId);
      if (oldRec) {
        // Reverse contact balances
        setContacts(prev => prev.map(c => {
          const matchingOldItem = oldRec.items.find(item => item.contactId === c.id);
          if (matchingOldItem) {
            return { ...c, balance: c.balance + matchingOldItem.amount }; // Add back since receipt decreases what they owe
          }
          return c;
        }));

        // Reverse bank balance
        setBanks(prev => prev.map(b => {
          if (b.id === selectedBankId) {
            return { ...b, balance: b.balance - oldRec.totalAmount };
          }
          return b;
        }));

        // Delete from transactions list
        setTransactions(prev => prev.filter(tx => tx.category === `دریافت #${oldRec.number}`));
      }
    }

    // Apply adjustments for new/updated receipt
    // 1. Update Contact Balances: Receipts decrease the debit/receivable balance of customers (or increases credit of shareholders)
    setContacts(prev => prev.map(c => {
      const itemsForContact = formItems.filter(item => item.contactId === c.id);
      if (itemsForContact.length > 0) {
        const sumAllocated = itemsForContact.reduce((sum, item) => sum + item.amount, 0);
        return { ...c, balance: c.balance - sumAllocated }; // Receipt reduces outstanding debit
      }
      return c;
    }));

    // 2. Update deposit bank account balance
    setBanks(prev => prev.map(b => {
      if (b.id === selectedBankId) {
        return { ...b, balance: b.balance + total };
      }
      return b;
    }));

    // 3. Register a ledger/treasury Transaction for audit logs
    const bankObj = banks.find(b => b.id === selectedBankId);
    const newTx: Transaction = {
      id: 't_rec_' + Date.now(),
      date: receiptDate,
      type: 'receive',
      amount: total,
      fromId: formItems[0]?.contactId || 'external',
      fromName: formItems.map(item => item.contactName).join(' و '),
      toId: selectedBankId,
      toName: bankObj ? bankObj.name : '',
      description: globalDesc + ` (دریافت #${finalNum})`,
      refNumber: finalDoc,
      category: `دریافت #${finalNum}`
    };

    setTransactions([newTx, ...transactions]);

    // Save Receipt to Receipts Collection
    if (receiptId) {
      setReceipts(receipts.map(r => r.id === receiptId ? newReceipt : r));
    } else {
      setReceipts([newReceipt, ...receipts]);
    }

    // Reset and return
    setViewMode('list');
    setSelectedReceiptIds([]);
  };

  // Delete Receipts
  const handleDeleteSelected = () => {
    if (selectedReceiptIds.length === 0) return;
    if (confirm(`آیا مطمئن هستید که می‌خواهید تعداد ${selectedReceiptIds.length} سند دریافت انتخابی را حذف کنید؟ مانده‌ها و معین‌های مالی معکوس خواهند شد.`)) {
      
      let updatedContacts = [...contacts];
      let updatedBanks = [...banks];
      let updatedTxs = [...transactions];

      selectedReceiptIds.forEach(id => {
        const rec = receipts.find(r => r.id === id);
        if (rec) {
          // Reverse contacts
          rec.items.forEach(item => {
            updatedContacts = updatedContacts.map(c => {
              if (c.id === item.contactId) {
                return { ...c, balance: c.balance + item.amount };
              }
              return c;
            });
          });

          // Reverse banks
          updatedBanks = updatedBanks.map(b => {
            if (b.id === selectedBankId) {
              return { ...b, balance: b.balance - rec.totalAmount };
            }
            return b;
          });

          // Filter out transactions
          updatedTxs = updatedTxs.filter(tx => tx.category !== `دریافت #${rec.number}`);
        }
      });

      setContacts(updatedContacts);
      setBanks(updatedBanks);
      setTransactions(updatedTxs);
      setReceipts(receipts.filter(r => !selectedReceiptIds.includes(r.id)));
      setSelectedReceiptIds([]);
    }
  };

  // Edit Receipt
  const handleEditSelected = () => {
    if (selectedReceiptIds.length !== 1) return;
    const rec = receipts.find(r => r.id === selectedReceiptIds[0]);
    if (rec) {
      setReceiptId(rec.id);
      setIsAutoNum(false);
      setReceiptNum(rec.number);
      setAccountingDoc(rec.accountingDocNo);
      setReceiptDate(rec.date);
      setGlobalDesc(rec.description);
      setSelectedCurrency(rec.currency);
      const proj = projects.find(p => p.name === rec.project);
      setSelectedProjectId(proj ? proj.id : '');
      setFormItems(rec.items);
      setViewMode('form');
    }
  };

  // Get total sum for form mode
  const totalFormAmount = formItems.reduce((sum, item) => sum + item.amount, 0);

  // Filter receipts based on headers
  const getFilteredReceipts = () => {
    return receipts.filter(r => {
      const matchNum = r.number.toLowerCase().includes(filterNum.toLowerCase());
      const matchDoc = r.accountingDocNo.toLowerCase().includes(filterDoc.toLowerCase());
      const matchDate = r.date.toLowerCase().includes(filterDate.toLowerCase());
      
      const allContactNames = r.items.map(i => i.contactName).join(' ');
      const matchContact = allContactNames.toLowerCase().includes(filterContact.toLowerCase());

      const matchDesc = r.description.toLowerCase().includes(filterDesc.toLowerCase());
      const matchProj = (r.project || '').toLowerCase().includes(filterProj.toLowerCase());
      
      const matchAmount = filterAmount ? r.totalAmount.toString().includes(filterAmount) : true;

      return matchNum && matchDoc && matchDate && matchContact && matchDesc && matchProj && matchAmount;
    });
  };

  // Table rendering items (explodes multiple rows if "items" tab is active)
  const filteredReceipts = getFilteredReceipts();
  
  // Flatten items for "Items" list tab
  const flattenedItems = filteredReceipts.flatMap((r, rIdx) => {
    return r.items.map((item, itemIdx) => ({
      receiptId: r.id,
      number: r.number,
      accountingDocNo: r.accountingDocNo,
      date: r.date,
      project: r.project,
      currency: r.currency,
      accountName: r.accountName || 'حساب های دریافتنی',
      contactName: item.contactName,
      contactId: item.contactId,
      description: item.description,
      amount: item.amount,
      invoiceNo: r.invoiceNo || (1000 + rIdx).toString() // matching user's screen invoice links
    }));
  });

  // Pagination bounds
  const currentTotalItems = listTab === 'all' ? filteredReceipts.length : flattenedItems.length;
  const totalPages = Math.ceil(currentTotalItems / itemsPerPage) || 1;
  const paginatedReceipts = filteredReceipts.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
  const paginatedItems = flattenedItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  // Toggle selection
  const handleToggleSelectAll = () => {
    if (selectedReceiptIds.length === filteredReceipts.length) {
      setSelectedReceiptIds([]);
    } else {
      setSelectedReceiptIds(filteredReceipts.map(r => r.id));
    }
  };

  const handleToggleSelectOne = (id: string) => {
    if (selectedReceiptIds.includes(id)) {
      setSelectedReceiptIds(selectedReceiptIds.filter(x => x !== id));
    } else {
      setSelectedReceiptIds([...selectedReceiptIds, id]);
    }
  };

  return (
    <div className="space-y-6" id="receipts-module">
      
      {/* HEADER SECTION WITH NAVIGATION */}
      <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-100 shadow-xs print:hidden">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
            <Coins size={20} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="text-sm font-bold text-slate-800">
                {viewMode === 'form' ? 'ثبت سند دریافت جدید (صندوق و بانک)' : 'دفتر خزانه‌داری - لیست دریافت‌های مالی'}
              </h3>
              <span className="text-amber-500 text-xs font-black">★</span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">ثبت چندمرحله‌ای چک، حواله نقد، فیش عابربانک و اسناد دریافتنی</p>
          </div>
        </div>

        {/* Action Toggle */}
        <div className="flex items-center gap-2">
          {viewMode === 'form' ? (
            <button 
              onClick={() => setViewMode('list')}
              className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 px-3.5 py-2 rounded-xl transition-all font-bold"
            >
              <ArrowRight size={14} />
              <span>بازگشت به لیست دریافت ها</span>
            </button>
          ) : (
            <button 
              onClick={() => {
                setReceiptId(null);
                setIsAutoNum(true);
                setReceiptNum('');
                setAccountingDoc('');
                setGlobalDesc('حواله انتقال');
                setSelectedProjectId('');
                setSelectedCurrency('IRR - ریال ایران');
                setFormItems([{ id: 'item_1', contactId: '', contactName: '', amount: 0, description: 'حواله انتقال' }]);
                setViewMode('form');
              }}
              className="flex items-center gap-1.5 text-xs text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-xl shadow-sm transition-all font-bold"
            >
              <Plus size={15} />
              <span>ثبت دریافت جدید</span>
            </button>
          )}
        </div>
      </div>

      {/* ==================== FORM VIEW (ADD / EDIT) ==================== */}
      {viewMode === 'form' && (
        <form onSubmit={handleSubmitReceipt} className="space-y-6">
          
          {/* Main Controls Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 text-xs font-bold text-slate-600">
              
              {/* Number (شماره) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-[11px]">شماره سند دریافت</label>
                  <div className="flex items-center gap-1">
                    <input 
                      type="checkbox" 
                      id="auto-num-chk"
                      checked={isAutoNum} 
                      onChange={(e) => setIsAutoNum(e.target.checked)} 
                      className="rounded border-slate-300 text-blue-600 focus:ring-blue-500/20 w-3.5 h-3.5"
                    />
                    <label htmlFor="auto-num-chk" className="text-[10px] text-blue-600 cursor-pointer select-none">اتوماتیک</label>
                  </div>
                </div>
                <input 
                  type="text" 
                  disabled={isAutoNum}
                  value={isAutoNum ? getNextReceiptNum() : receiptNum}
                  onChange={(e) => setReceiptNum(e.target.value)}
                  className={`w-full px-3 py-2 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-center font-mono ${
                    isAutoNum ? 'bg-slate-50 border-slate-100 text-slate-400' : 'bg-white border-slate-200 text-slate-700'
                  }`}
                  placeholder="مثال: ۱۰۰۱"
                />
              </div>

              {/* Date (تاریخ) */}
              <div>
                <label className="block mb-1.5 text-[11px]">تاریخ دریافت</label>
                <div className="relative">
                  <input 
                    type="text" 
                    required
                    value={receiptDate}
                    onChange={(e) => setReceiptDate(e.target.value)}
                    className="w-full pl-3 pr-9 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-center font-mono text-slate-700"
                    placeholder="۱۴۰۵/۰۴/۱۷"
                  />
                  <Calendar size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                </div>
              </div>

              {/* Project (پروژه) */}
              <div>
                <label className="block mb-1.5 text-[11px]">پروژه مربوطه</label>
                <div className="flex gap-1.5">
                  <select 
                    value={selectedProjectId}
                    onChange={(e) => setSelectedProjectId(e.target.value)}
                    className="flex-1 px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-slate-700 font-medium"
                  >
                    <option value="">-- بدون انتخاب پروژه --</option>
                    {projects.map(p => (
                      <option key={p.id} value={p.id}>{p.name} {p.isDefault ? '(پیش‌فرض)' : ''}</option>
                    ))}
                  </select>
                  <button 
                    type="button"
                    onClick={() => setIsProjectModalOpen(true)}
                    className="p-2 text-emerald-600 hover:text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-xl transition-colors border border-emerald-100"
                    title="تعریف پروژه جدید"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>

              {/* Currency (واحد پول) */}
              <div>
                <label className="block mb-1.5 text-[11px]">واحد پول سند</label>
                <select 
                  value={selectedCurrency}
                  onChange={(e) => setSelectedCurrency(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-slate-700 font-medium"
                >
                  {currencies.map(curr => (
                    <option key={curr} value={curr}>{curr}</option>
                  ))}
                </select>
              </div>

              {/* Global Description (شرح کلی) */}
              <div>
                <label className="block mb-1.5 text-[11px]">شرح کلی تراکنش</label>
                <div className="flex gap-1.5">
                  <input 
                    type="text" 
                    value={globalDesc}
                    onChange={(e) => {
                      setGlobalDesc(e.target.value);
                      // Set all item descriptions to match global default if they haven't been edited
                      setFormItems(formItems.map(item => ({ ...item, description: e.target.value })));
                    }}
                    className="flex-1 px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-slate-700 font-medium"
                    placeholder="مثال: حواله انتقال"
                  />
                  <button 
                    type="button"
                    onClick={() => setIsFreqDescOpen(true)}
                    className="p-2 text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-xl transition-colors border border-blue-100"
                    title="شرح های پرتکرار"
                  >
                    <List size={16} />
                  </button>
                </div>
              </div>

            </div>

            {/* Deposit Bank Selection */}
            <div className="pt-2 border-t border-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-2 text-slate-500">
                <Info size={14} className="text-blue-500 shrink-0" />
                <span>حساب مقصد خزانه‌داری را مشخص کنید تا وجوه بلافاصله پس از تایید به موجودی آن اضافه گردد.</span>
              </div>
              <div className="flex items-center gap-2 font-bold text-slate-600 shrink-0">
                <span>واریز به حساب خزانه:</span>
                <select 
                  value={selectedBankId}
                  onChange={(e) => setSelectedBankId(e.target.value)}
                  className="px-3 py-1.5 border border-slate-200 bg-slate-50 rounded-lg focus:outline-none"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>{b.name} ({b.type === 'bank' ? 'بانک' : 'صندوق'})</option>
                  ))}
                </select>
              </div>
            </div>

          </div>

          {/* Receipt Items (شخص / مبلغ / شرح ردیف) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-700 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                <span>اقلام تفکیکی سند دریافت</span>
              </h4>
              <button 
                type="button" 
                onClick={addFormItem}
                className="text-xs font-bold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1"
              >
                <Plus size={14} />
                <span>افزودن آیتم جدید</span>
              </button>
            </div>

            {/* Loop Form Items */}
            <div className="space-y-4">
              {formItems.map((item, index) => {
                const selectedContact = contacts.find(c => c.id === item.contactId);
                return (
                  <div 
                    key={item.id} 
                    className="relative bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-slate-300 transition-all space-y-4"
                  >
                    {/* Badge Index and Remove */}
                    <div className="flex items-center justify-between pb-3 border-b border-slate-100/60 text-xs">
                      <span className="bg-slate-100 text-slate-500 font-black px-2 py-0.5 rounded-md">آیتم {index + 1}</span>
                      <button 
                        type="button"
                        onClick={() => removeFormItem(item.id)}
                        className="text-rose-500 hover:text-rose-700 hover:bg-rose-50 p-1 rounded-lg transition-all"
                        title="حذف آیتم"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end text-xs font-bold text-slate-600">
                      
                      {/* Left side: Avatar and Contact Selector (5 cols) */}
                      <div className="md:col-span-5 flex items-center gap-3">
                        {/* Portrait Avatar */}
                        <div className="w-12 h-12 rounded-full overflow-hidden bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0">
                          {selectedContact?.image ? (
                            <img src={selectedContact.image} alt={selectedContact.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            <User size={20} className="text-slate-400" />
                          )}
                        </div>

                        <div className="flex-1">
                          <label className="block mb-1.5 text-[11px]">انتخاب شخص / طرف حساب *</label>
                          <div className="flex gap-1.5">
                            <select 
                              required
                              value={item.contactId}
                              onChange={(e) => updateFormItem(item.id, 'contactId', e.target.value)}
                              className="flex-1 px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-slate-700 font-bold"
                            >
                              <option value="">-- انتخاب شخص --</option>
                              {contacts.map(c => (
                                <option key={c.id} value={c.id}>{c.name} ({c.category})</option>
                              ))}
                            </select>
                            <button 
                              type="button"
                              onClick={() => {
                                setQuickContactType('customer');
                                setIsQuickContactOpen(true);
                              }}
                              className="p-2 text-emerald-600 hover:text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-xl transition-colors border border-emerald-100"
                              title="شخص جدید"
                            >
                              <Plus size={16} />
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Middle: Amount (3 cols) */}
                      <div className="md:col-span-3">
                        <label className="block mb-1.5 text-[11px]">مبلغ دریافتنی ({selectedCurrency.split(' - ')[1] || 'ریال'}) *</label>
                        <div className="relative">
                          <input 
                            type="number" 
                            required
                            min="100"
                            value={item.amount || ''}
                            onChange={(e) => updateFormItem(item.id, 'amount', Number(e.target.value))}
                            className="w-full pl-10 pr-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all font-mono text-left text-slate-700"
                            placeholder="۰"
                            dir="ltr"
                          />
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[9px] text-slate-400 font-black">
                            {selectedCurrency.split(' - ')[0] || 'ریال'}
                          </span>
                        </div>
                        {item.amount > 0 && (
                          <div className="text-[10px] text-slate-400 mt-1 font-medium text-left">
                            {formatMoney(item.amount)} {selectedCurrency.split(' - ')[1] || 'ریال'}
                          </div>
                        )}
                      </div>

                      {/* Right: Item Description (4 cols) */}
                      <div className="md:col-span-4">
                        <label className="block mb-1.5 text-[11px]">بابت / شرح معین</label>
                        <div className="flex gap-1.5">
                          <input 
                            type="text" 
                            value={item.description}
                            onChange={(e) => updateFormItem(item.id, 'description', e.target.value)}
                            className="flex-1 px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-slate-700 font-medium"
                            placeholder="بابت تسویه فاکتور فروش"
                          />
                          <button 
                            type="button"
                            onClick={() => {
                              setIsFreqDescOpen(true);
                            }}
                            className="p-2 text-slate-400 hover:text-slate-600 bg-slate-50 hover:bg-slate-100 rounded-xl transition-colors border border-slate-100"
                            title="انتخاب شرح پرتکرار"
                          >
                            <List size={15} />
                          </button>
                        </div>
                      </div>

                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Totals & Submission Block (Matches green container structure) */}
          <div className="bg-emerald-50/20 border border-emerald-500/30 rounded-2xl p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            
            <div className="flex flex-wrap items-center gap-6 text-xs font-bold text-slate-700">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                <span>مجموع دریافتی:</span>
                <span className="text-base font-black text-emerald-700 font-mono">
                  {formatMoney(totalFormAmount)} {selectedCurrency.split(' - ')[1] || 'ریال'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                <span>باقیمانده تراز:</span>
                <span className="text-slate-500 font-mono">۰ ریال</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 justify-end">
              <button 
                type="button"
                onClick={() => setViewMode('list')}
                className="text-xs text-slate-500 hover:text-slate-800 bg-slate-100 px-4 py-2.5 rounded-xl font-bold transition-all"
              >
                انصراف
              </button>
              <button 
                type="submit"
                className="text-xs text-white bg-emerald-600 hover:bg-emerald-700 px-6 py-2.5 rounded-xl font-black shadow-md shadow-emerald-100 transition-all flex items-center gap-1.5"
              >
                <CheckCircle size={15} />
                <span>{receiptId ? 'ویرایش و بروزرسانی سند' : 'افزودن دریافت'}</span>
              </button>
            </div>

          </div>

        </form>
      )}

      {/* ==================== LIST VIEW (RECEIPT LIST) ==================== */}
      {viewMode === 'list' && (
        <div className="space-y-4">
          
          {/* Main Action Bar and Filters */}
          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4 print:hidden">
            
            {/* View Mode Tabs (همه / آیتم ها) */}
            <div className="flex rounded-xl bg-slate-100 p-1 border border-slate-200 shrink-0 max-w-xs">
              <button 
                onClick={() => { setListTab('all'); setCurrentPage(1); }}
                className={`text-xs px-4 py-2 rounded-lg transition-all duration-200 font-black ${listTab === 'all' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
              >
                همه رسیدها
              </button>
              <button 
                onClick={() => { setListTab('items'); setCurrentPage(1); }}
                className={`text-xs px-4 py-2 rounded-lg transition-all duration-200 font-black ${listTab === 'items' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
              >
                آیتم‌های دریافتی
              </button>
            </div>

            {/* Quick action buttons on Left of list header */}
            <div className="flex flex-wrap items-center gap-2">
              
              <button 
                disabled={selectedReceiptIds.length === 0}
                onClick={handleDeleteSelected}
                className={`p-2 rounded-xl transition-all border ${
                  selectedReceiptIds.length > 0 
                    ? 'text-rose-600 bg-rose-50 border-rose-100 hover:bg-rose-100' 
                    : 'text-slate-300 bg-slate-50 border-slate-100 cursor-not-allowed'
                }`}
                title="حذف اسناد انتخابی"
              >
                <Trash2 size={16} />
              </button>

              <button 
                disabled={selectedReceiptIds.length !== 1}
                onClick={handleEditSelected}
                className={`p-2 rounded-xl transition-all border ${
                  selectedReceiptIds.length === 1 
                    ? 'text-amber-600 bg-amber-50 border-amber-100 hover:bg-amber-100' 
                    : 'text-slate-300 bg-slate-50 border-slate-100 cursor-not-allowed'
                }`}
                title="ویرایش سند انتخابی"
              >
                <Edit3 size={16} />
              </button>

              <button 
                disabled={selectedReceiptIds.length !== 1}
                onClick={() => {
                  const rec = receipts.find(r => r.id === selectedReceiptIds[0]);
                  if (rec) setViewDetailReceipt(rec);
                }}
                className={`p-2 rounded-xl transition-all border ${
                  selectedReceiptIds.length === 1 
                    ? 'text-blue-600 bg-blue-50 border-blue-100 hover:bg-blue-100' 
                    : 'text-slate-300 bg-slate-50 border-slate-100 cursor-not-allowed'
                }`}
                title="مشاهده جزئیات سند"
              >
                <Eye size={16} />
              </button>

              <div className="h-6 w-[1px] bg-slate-200/80 mx-1"></div>

              <button 
                onClick={() => {
                  setFilterNum('');
                  setFilterDoc('');
                  setFilterDate('');
                  setFilterContact('');
                  setFilterDesc('');
                  setFilterProj('');
                  setFilterAmount('');
                }}
                className="text-xs font-bold text-slate-500 hover:text-slate-800 px-3 py-2 rounded-xl bg-slate-100"
                title="پاکسازی فیلترها"
              >
                حذف فیلترها
              </button>

            </div>

          </div>

          {/* Grid Table for Receipts */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse">
                <thead>
                  {/* Primary Headers */}
                  <tr className="bg-slate-50/80 border-b border-slate-100 text-slate-500 text-xs font-black">
                    <th className="p-4 w-10 text-center">
                      <input 
                        type="checkbox" 
                        checked={filteredReceipts.length > 0 && selectedReceiptIds.length === filteredReceipts.length}
                        onChange={handleToggleSelectAll}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500/20"
                      />
                    </th>
                    <th className="p-4 w-12 text-center">#</th>
                    <th className="p-4 w-20 text-center">شماره</th>
                    <th className="p-4 w-28 text-center">سند حسابداری</th>
                    <th className="p-4 w-28 text-center">تاریخ</th>
                    
                    {listTab === 'all' ? (
                      <>
                        <th className="p-4">حساب معین</th>
                        <th className="p-4">شخص طرف حساب</th>
                        <th className="p-4">شرح سند</th>
                        <th className="p-4 text-left w-36">مبلغ کل</th>
                        <th className="p-4 text-center">پروژه</th>
                      </>
                    ) : (
                      <>
                        <th className="p-4">حساب معین</th>
                        <th className="p-4">شخص</th>
                        <th className="p-4">بابت / شرح ردیف</th>
                        <th className="p-4 text-left w-36">مبلغ ردیف</th>
                        <th className="p-4 text-center">پروژه</th>
                        <th className="p-4 text-center">فاکتور</th>
                      </>
                    )}
                  </tr>

                  {/* Excel-like filter inputs row below headers */}
                  <tr className="bg-slate-50/30 border-b border-slate-100 text-xs print:hidden">
                    <td className="p-2"></td>
                    <td className="p-2"></td>
                    {/* Number filter */}
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterNum}
                          onChange={(e) => { setFilterNum(e.target.value); setCurrentPage(1); }}
                          placeholder="جستجو..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-blue-500 text-center font-mono"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>
                    {/* Doc No filter */}
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterDoc}
                          onChange={(e) => { setFilterDoc(e.target.value); setCurrentPage(1); }}
                          placeholder="جستجو..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-blue-500 text-center font-mono"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>
                    {/* Date filter */}
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterDate}
                          onChange={(e) => { setFilterDate(e.target.value); setCurrentPage(1); }}
                          placeholder="تاریخ..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-blue-500 text-center font-mono"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>
                    
                    {/* Account Name */}
                    <td className="p-2"></td>
                    
                    {/* Contact filter */}
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterContact}
                          onChange={(e) => { setFilterContact(e.target.value); setCurrentPage(1); }}
                          placeholder="شخص..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-blue-500 font-medium"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Description filter */}
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterDesc}
                          onChange={(e) => { setFilterDesc(e.target.value); setCurrentPage(1); }}
                          placeholder="شرح..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-blue-500 font-medium"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Amount filter */}
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterAmount}
                          onChange={(e) => { setFilterAmount(e.target.value); setCurrentPage(1); }}
                          placeholder="مبلغ..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-blue-500 text-left font-mono"
                          dir="ltr"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Project filter */}
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterProj}
                          onChange={(e) => { setFilterProj(e.target.value); setCurrentPage(1); }}
                          placeholder="پروژه..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-blue-500 text-center font-medium"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {listTab === 'items' && <td className="p-2"></td>}

                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                  {currentTotalItems === 0 ? (
                    <tr>
                      <td colSpan={12} className="p-16 text-center text-slate-400 font-bold">
                        هیچ سند دریافتی با مشخصات وارد شده پیدا نشد.
                      </td>
                    </tr>
                  ) : listTab === 'all' ? (
                    paginatedReceipts.map((r, index) => (
                      <tr 
                        key={r.id} 
                        onClick={() => handleToggleSelectOne(r.id)}
                        className={`hover:bg-slate-50/60 transition-colors cursor-pointer ${
                          selectedReceiptIds.includes(r.id) ? 'bg-blue-50/30' : ''
                        }`}
                      >
                        <td className="p-4 text-center" onClick={(e) => e.stopPropagation()}>
                          <input 
                            type="checkbox" 
                            checked={selectedReceiptIds.includes(r.id)}
                            onChange={() => handleToggleSelectOne(r.id)}
                            className="rounded border-slate-300 text-blue-600 focus:ring-blue-500/20"
                          />
                        </td>
                        <td className="p-4 text-center text-slate-400 font-mono">{(currentPage - 1) * itemsPerPage + index + 1}</td>
                        <td className="p-4 text-center text-blue-600 font-black font-mono hover:underline">{r.number}</td>
                        <td className="p-4 text-center text-slate-500 font-bold font-mono">{r.accountingDocNo}</td>
                        <td className="p-4 text-center text-slate-600 font-bold font-mono">{r.date}</td>
                        <td className="p-4 text-slate-600 font-medium">{r.accountName || 'حساب های دریافتنی'}</td>
                        <td className="p-4 font-black text-slate-800 leading-snug">
                          {r.items.map(item => item.contactName).join(' ، ')}
                        </td>
                        <td className="p-4 font-semibold text-slate-500">{r.description}</td>
                        <td className="p-4 text-left font-black text-emerald-700 font-mono">
                          {formatMoney(r.totalAmount)} {r.currency.split(' - ')[1] || 'ریال'}
                        </td>
                        <td className="p-4 text-center font-bold">
                          {r.project ? (
                            <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md text-[10px]">{r.project}</span>
                          ) : (
                            <span className="text-slate-300">---</span>
                          )}
                        </td>
                      </tr>
                    ))
                  ) : (
                    paginatedItems.map((item, index) => (
                      <tr 
                        key={item.receiptId + '_' + index} 
                        onClick={() => handleToggleSelectOne(item.receiptId)}
                        className={`hover:bg-slate-50/60 transition-colors cursor-pointer ${
                          selectedReceiptIds.includes(item.receiptId) ? 'bg-blue-50/30' : ''
                        }`}
                      >
                        <td className="p-4 text-center" onClick={(e) => e.stopPropagation()}>
                          <input 
                            type="checkbox" 
                            checked={selectedReceiptIds.includes(item.receiptId)}
                            onChange={() => handleToggleSelectOne(item.receiptId)}
                            className="rounded border-slate-300 text-blue-600 focus:ring-blue-500/20"
                          />
                        </td>
                        <td className="p-4 text-center text-slate-400 font-mono">{(currentPage - 1) * itemsPerPage + index + 1}</td>
                        <td className="p-4 text-center text-blue-600 font-black font-mono hover:underline">{item.number}</td>
                        <td className="p-4 text-center text-slate-500 font-bold font-mono">{item.accountingDocNo}</td>
                        <td className="p-4 text-center text-slate-600 font-bold font-mono">{item.date}</td>
                        <td className="p-4 text-slate-600 font-medium">{item.accountName}</td>
                        <td className="p-4 font-black text-slate-800">{item.contactName}</td>
                        <td className="p-4 font-semibold text-slate-500">{item.description}</td>
                        <td className="p-4 text-left font-black text-emerald-700 font-mono">
                          {formatMoney(item.amount)} {item.currency.split(' - ')[1] || 'ریال'}
                        </td>
                        <td className="p-4 text-center font-bold">
                          {item.project ? (
                            <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md text-[10px]">{item.project}</span>
                          ) : (
                            <span className="text-slate-300">---</span>
                          )}
                        </td>
                        <td className="p-4 text-center font-mono font-bold text-slate-500">
                          {item.invoiceNo ? (
                            <span className="text-blue-500 bg-blue-50 px-2 py-0.5 rounded-md hover:underline">{item.invoiceNo}</span>
                          ) : (
                            <span className="text-slate-300">---</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination Footer */}
            <div className="bg-slate-50 p-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-bold text-slate-500 print:hidden">
              <div>
                <span>صفحه {currentPage} از {totalPages}</span>
                <span className="mx-2">|</span>
                <span>تعداد کل آیتم‌ها: {currentTotalItems}</span>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5">
                  <span>تعداد در صفحه:</span>
                  <select 
                    value={itemsPerPage}
                    onChange={(e) => { setItemsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                    className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-600"
                  >
                    {[5, 10, 15, 20, 30, 50].map(n => (
                      <option key={n} value={n}>{n}</option>
                    ))}
                  </select>
                </div>

                <div className="flex rounded-xl bg-white border border-slate-200 p-0.5">
                  <button 
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    className="p-1.5 hover:text-blue-600 disabled:opacity-30 disabled:hover:text-slate-500"
                  >
                    <ChevronRight size={16} />
                  </button>
                  <button 
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                    className="p-1.5 hover:text-blue-600 disabled:opacity-30 disabled:hover:text-slate-500"
                  >
                    <ChevronLeft size={16} />
                  </button>
                </div>
              </div>
            </div>

          </div>

        </div>
      )}


      {/* ==================== PROJECT CREATION MODAL ==================== */}
      {isProjectModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-100 p-5 space-y-4 animate-in zoom-in-95 duration-150">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                <FolderPlus size={16} className="text-blue-600" />
                <span>مشخصات پروژه جدید</span>
              </h3>
              <button onClick={() => setIsProjectModalOpen(false)} className="text-slate-400 text-lg hover:text-slate-600">×</button>
            </div>

            <form onSubmit={handleCreateProject} className="space-y-4 text-xs font-bold text-slate-600">
              
              <div>
                <label className="block mb-1.5">نام پروژه *</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: توزیع فروشگاهی یا شعبه ۲"
                  value={newProjName}
                  onChange={(e) => setNewProjName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div className="flex items-center gap-2 py-1">
                <input 
                  type="checkbox" 
                  id="proj-active-chk"
                  checked={newProjActive}
                  onChange={(e) => setNewProjActive(e.target.checked)}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500/20"
                />
                <label htmlFor="proj-active-chk" className="cursor-pointer">پروژه فعال باشد</label>
              </div>

              <div>
                <label className="block mb-1.5">پیش فرض باشد؟</label>
                <div className="flex gap-1.5 p-1 bg-slate-100 rounded-xl max-w-[120px]">
                  <button 
                    type="button" 
                    onClick={() => setNewProjDefault(true)}
                    className={`flex-1 py-1 px-3 rounded-lg text-[10px] transition-all font-black ${newProjDefault ? 'bg-blue-600 text-white' : 'text-slate-500'}`}
                  >
                    بله
                  </button>
                  <button 
                    type="button" 
                    onClick={() => setNewProjDefault(false)}
                    className={`flex-1 py-1 px-3 rounded-lg text-[10px] transition-all font-black ${!newProjDefault ? 'bg-white text-slate-600 shadow-xs' : 'text-slate-500'}`}
                  >
                    خیر
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button type="button" onClick={() => setIsProjectModalOpen(false)} className="text-slate-500 px-3 py-1.5">انصراف</button>
                <button type="submit" className="bg-emerald-600 text-white px-4 py-1.5 rounded-lg font-black transition-all hover:bg-emerald-700">ایجاد پروژه</button>
              </div>

            </form>

          </div>
        </div>
      )}


      {/* ==================== FREQUENT DESCRIPTIONS MANAGER MODAL ==================== */}
      {isFreqDescOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-100 p-5 space-y-4 animate-in zoom-in-95 duration-150">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-xs font-black text-slate-800">شرح‌های پرتکرار</h3>
              <button onClick={() => setIsFreqDescOpen(false)} className="text-slate-400 text-lg hover:text-slate-600">×</button>
            </div>

            {/* Quick add input */}
            <form onSubmit={handleAddFreqDesc} className="flex gap-2 text-xs">
              <input 
                type="text" 
                placeholder="افزودن شرح پرتکرار جدید..."
                value={newFreqDesc}
                onChange={(e) => setNewFreqDesc(e.target.value)}
                className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
              />
              <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-xl transition-all">
                <Plus size={16} />
              </button>
            </form>

            {/* List with Delete button */}
            <div className="max-h-60 overflow-y-auto space-y-2 pr-1">
              {frequentDescriptions.map((desc) => (
                <div 
                  key={desc} 
                  onClick={() => {
                    setGlobalDesc(desc);
                    setFormItems(formItems.map(item => ({ ...item, description: desc })));
                    setIsFreqDescOpen(false);
                  }}
                  className="flex items-center justify-between p-3 bg-slate-50 hover:bg-blue-50/40 rounded-xl cursor-pointer group border border-slate-100/50 transition-all text-xs font-bold text-slate-700"
                >
                  <span>{desc}</span>
                  <button 
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteFreqDesc(desc);
                    }}
                    className="p-1 text-slate-300 hover:text-rose-500 rounded-md transition-colors"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100">
              <button onClick={() => setIsFreqDescOpen(false)} className="text-slate-500 font-bold text-xs">بستن</button>
            </div>

          </div>
        </div>
      )}


      {/* ==================== QUICK CONTACT CREATION MODAL ==================== */}
      {isQuickContactOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-100 p-5 space-y-4 animate-in zoom-in-95 duration-150">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-xs font-black text-slate-800">تعریف شخص جدید</h3>
              <button onClick={() => setIsQuickContactOpen(false)} className="text-slate-400 text-lg hover:text-slate-600">×</button>
            </div>

            <form onSubmit={handleQuickCreateContact} className="space-y-4 text-xs font-bold text-slate-600">
              
              <div>
                <label className="block mb-1.5">نام و نام خانوادگی / نام شرکت *</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: شرکت راه سازان"
                  value={quickContactName}
                  onChange={(e) => setQuickContactName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
              </div>

              <div>
                <label className="block mb-1.5">شماره همراه</label>
                <input 
                  type="text" 
                  placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                  value={quickContactPhone}
                  onChange={(e) => setQuickContactPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none text-left font-mono"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block mb-1.5">دسته‌بندی اولیه</label>
                <select 
                  value={quickContactType}
                  onChange={(e) => setQuickContactType(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none text-slate-700"
                >
                  <option value="customer">مشتری</option>
                  <option value="supplier">تامین کننده</option>
                  <option value="shareholder">سهامداران</option>
                  <option value="employee">کارمندان</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button type="button" onClick={() => setIsQuickContactOpen(false)} className="text-slate-500 px-3 py-1.5 font-bold">انصراف</button>
                <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1.5 rounded-lg font-bold">ایجاد طرف حساب</button>
              </div>

            </form>

          </div>
        </div>
      )}


      {/* ==================== DETAILED RECEIPT DIALOG ==================== */}
      {viewDetailReceipt && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl border border-slate-100 p-6 space-y-6 animate-in zoom-in-95 duration-150">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                <Coins size={16} className="text-blue-600" />
                <span>نمایش اطلاعات سند دریافت شماره {viewDetailReceipt.number}</span>
              </h3>
              <button onClick={() => setViewDetailReceipt(null)} className="text-slate-400 text-lg hover:text-slate-600">×</button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-bold text-slate-600">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="text-[10px] text-slate-400 mb-1">شماره سند</div>
                <div className="font-mono text-slate-800 text-sm">{viewDetailReceipt.number}</div>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="text-[10px] text-slate-400 mb-1">سند حسابداری</div>
                <div className="font-mono text-slate-800 text-sm">{viewDetailReceipt.accountingDocNo}</div>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="text-[10px] text-slate-400 mb-1">تاریخ ثبت</div>
                <div className="font-mono text-slate-800 text-sm">{viewDetailReceipt.date}</div>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="text-[10px] text-slate-400 mb-1">واحد پول</div>
                <div className="text-slate-800 text-sm">{viewDetailReceipt.currency}</div>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-800">اقلام تفکیکی سند دریافت</h4>
              <div className="border border-slate-100 rounded-xl overflow-hidden text-xs">
                <table className="w-full text-right border-collapse">
                  <thead>
                    <tr className="bg-slate-50 text-slate-500 font-bold text-[11px] border-b border-slate-100">
                      <th className="p-3">#</th>
                      <th className="p-3">شخص طرف حساب</th>
                      <th className="p-3">بابت / شرح</th>
                      <th className="p-3 text-left">مبلغ دریافتی</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 font-medium">
                    {viewDetailReceipt.items.map((item, idx) => (
                      <tr key={item.id}>
                        <td className="p-3 font-mono text-slate-400">{idx + 1}</td>
                        <td className="p-3 font-black text-slate-800">{item.contactName}</td>
                        <td className="p-3 text-slate-600">{item.description}</td>
                        <td className="p-3 text-left font-black text-emerald-700 font-mono">
                          {formatMoney(item.amount)} {viewDetailReceipt.currency.split(' - ')[1] || 'ریال'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold">
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400">پروژه:</span>
                <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md text-[10px]">
                  {viewDetailReceipt.project || 'بدون پروژه'}
                </span>
              </div>
              <div className="text-sm font-black text-slate-800">
                <span>جمع کل سند:</span>
                <span className="text-base text-emerald-700 font-mono mr-2">
                  {formatMoney(viewDetailReceipt.totalAmount)} {viewDetailReceipt.currency.split(' - ')[1] || 'ریال'}
                </span>
              </div>
            </div>

            <div className="flex justify-end">
              <button 
                onClick={() => setViewDetailReceipt(null)} 
                className="bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold px-4 py-2 rounded-xl transition-all"
              >
                بستن پنجره
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
