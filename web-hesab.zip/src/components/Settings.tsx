/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CompanyInfo } from '../types';
import { Settings as SettingsIcon, Landmark, Phone, MapPin, ShieldAlert, RefreshCw } from 'lucide-react';

interface SettingsProps {
  companyInfo: CompanyInfo;
  setCompanyInfo: React.Dispatch<React.SetStateAction<CompanyInfo>>;
  onResetDatabase: () => void;
}

export default function Settings({
  companyInfo,
  setCompanyInfo,
  onResetDatabase
}: SettingsProps) {

  const handleInputChange = (key: keyof CompanyInfo, value: string) => {
    setCompanyInfo({
      ...companyInfo,
      [key]: value
    });
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('تنظیمات و اطلاعات سازمانی شرکت با موفقیت ذخیره گردید.');
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      {/* Settings Panel */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-xs p-6 space-y-6">
        
        <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
            <SettingsIcon size={20} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800">تنظیمات پروفایل شرکت</h3>
            <p className="text-[10px] text-slate-400 mt-0.5">مشخصات رسمی شرکت که در سربرگ فاکتورهای چاپی درج می‌شود</p>
          </div>
        </div>

        <form onSubmit={handleFormSubmit} className="space-y-4 text-xs">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            <div>
              <label className="block font-bold text-slate-600 mb-1.5">نام رسمی شرکت / بنگاه تجاری *</label>
              <input 
                type="text" 
                required
                value={companyInfo.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="شرکت نمونه البرز"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-600 mb-1.5">سال مالی جاری *</label>
              <input 
                type="text" 
                required
                value={companyInfo.financialYear}
                onChange={(e) => handleInputChange('financialYear', e.target.value)}
                placeholder="۱۴۰۵ (جاری)"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-center font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-600 mb-1.5">شماره اقتصادی / شناسه مالیاتی</label>
              <input 
                type="text" 
                value={companyInfo.taxNumber || ''}
                onChange={(e) => handleInputChange('taxNumber', e.target.value)}
                placeholder="شناسه ۱۱ رقمی مالیاتی"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-600 mb-1.5">تلفن‌های تماس شرکت *</label>
              <input 
                type="text" 
                required
                value={companyInfo.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                placeholder="۰۲۱-۸۸۹۹۸۸۹۹"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-mono text-left"
                dir="ltr"
              />
            </div>

          </div>

          <div>
            <label className="block font-bold text-slate-600 mb-1.5">نشانی پستی دفتر مرکزی *</label>
            <textarea 
              required
              value={companyInfo.address}
              onChange={(e) => handleInputChange('address', e.target.value)}
              placeholder="تهران، میدان آزادی، خیابان آزادی..."
              rows={3}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            ></textarea>
          </div>

          {/* Quick Notice */}
          <div className="p-3.5 bg-blue-50/40 rounded-xl border border-blue-100 flex gap-2 text-[10px] text-slate-600 leading-relaxed">
            <ShieldAlert size={16} className="text-blue-500 shrink-0" />
            <span>
              اطلاعات بالا مبنای رسمیت حقوقی شرکت هستند. در سیستم واقعی حسابفا، این اطلاعات با ثبت اسناد در سامانه مودیان کشور مطابقت داده می‌شوند.
            </span>
          </div>

          {/* Save Button */}
          <div className="flex justify-end pt-2">
            <button 
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-5 py-2 rounded-xl transition-all shadow-sm"
            >
              ذخیره تنظیمات بنگاه
            </button>
          </div>

        </form>

      </div>

      {/* Database Reset Option */}
      <div className="bg-red-50/50 rounded-2xl border border-red-100 p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-red-100 text-red-600 rounded-xl">
            <RefreshCw size={18} />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-800">منطقه حساس: بازنشانی دیتابیس دمو</h4>
            <p className="text-[10px] text-slate-400 mt-0.5">پاکسازی تمام فاکتورها، تراکنش‌ها، اشخاص ثبت‌شده و بازگشت به تنظیمات اولیه</p>
          </div>
        </div>

        <p className="text-[10px] text-slate-600 leading-relaxed">
          اگر تمایل دارید تمامی داده‌هایی که ثبت کرده‌اید پاک شده و سیستم به دیتای اولیه آزمایشی حسابفا ریست شود، از گزینه زیر استفاده کنید. توجه کنید که این عملیات غیرقابل بازگشت است.
        </p>

        <button 
          onClick={onResetDatabase}
          className="bg-red-600 hover:bg-red-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-colors shadow-sm"
        >
          بازنشانی کامل دیتابیس دمو
        </button>
      </div>

    </div>
  );
}
