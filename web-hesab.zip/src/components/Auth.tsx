/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, UserSession } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Lock, Mail, Building2, User as UserIcon, Moon, Sun, ShieldCheck, ArrowLeft, KeyRound } from 'lucide-react';

interface AuthProps {
  onLoginSuccess: (session: UserSession) => void;
  isDark: boolean;
  setIsDark: (dark: boolean) => void;
}

// Native high-security cryptographic SHA-256 hashing
async function hashPassword(password: string): Promise<string> {
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  } catch (err) {
    // Fallback simple hash if subtle crypto fails in unsecure contexts
    let hash = 0;
    for (let i = 0; i < password.length; i++) {
      const char = password.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash;
    }
    return 'fallback_' + Math.abs(hash).toString(16);
  }
}

export default function Auth({ onLoginSuccess, isDark, setIsDark }: AuthProps) {
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  
  // Login fields
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  // Register fields
  const [regFullName, setRegFullName] = useState('');
  const [regCompanyName, setRegCompanyName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');

  // Statuses
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Retrieve stored users
  const getStoredUsers = (): User[] => {
    const data = localStorage.getItem('mani_users');
    return data ? JSON.parse(data) : [];
  };

  // Save users to storage
  const saveUser = (user: User) => {
    const users = getStoredUsers();
    users.push(user);
    localStorage.setItem('mani_users', JSON.stringify(users));
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    if (!loginEmail || !loginPassword) {
      setError('لطفاً تمامی فیلدها را پر کنید.');
      setIsLoading(false);
      return;
    }

    try {
      const users = getStoredUsers();
      const user = users.find(u => u.email.toLowerCase() === loginEmail.trim().toLowerCase());
      
      if (!user) {
        // Create an initial admin if database is empty for convenience, or show error
        if (users.length === 0 && loginEmail.trim() === 'admin@mani.com') {
          // Auto create initial admin for demo ease
          const defaultPassHash = await hashPassword('123456');
          const newAdmin: User = {
            id: 'u-admin',
            email: 'admin@mani.com',
            passwordHash: defaultPassHash,
            fullName: 'مدیر مالی مانی',
            companyName: 'حسابداری مانی',
            createdAt: new Date().toISOString()
          };
          saveUser(newAdmin);
          proceedWithSession(newAdmin);
          return;
        }
        setError('کاربری با این مشخصات یافت نشد.');
        setIsLoading(false);
        return;
      }

      const inputHash = await hashPassword(loginPassword);
      if (user.passwordHash !== inputHash) {
        setError('کلمه عبور وارد شده صحیح نمی‌باشد.');
        setIsLoading(false);
        return;
      }

      setSuccess('ورود با موفقیت انجام شد. در حال هدایت به پنل...');
      setTimeout(() => {
        proceedWithSession(user);
      }, 1000);

    } catch (err) {
      setError('خطایی در فرآیند ورود رخ داد.');
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setIsLoading(true);

    if (!regFullName || !regCompanyName || !regEmail || !regPassword || !regConfirmPassword) {
      setError('لطفاً تمامی فیلدها را پر کنید.');
      setIsLoading(false);
      return;
    }

    if (regPassword.length < 6) {
      setError('کلمه عبور باید حداقل ۶ کاراکتر باشد.');
      setIsLoading(false);
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setError('کلمه عبور و تاییدیه آن یکسان نیستند.');
      setIsLoading(false);
      return;
    }

    try {
      const users = getStoredUsers();
      const exists = users.some(u => u.email.toLowerCase() === regEmail.trim().toLowerCase());
      
      if (exists) {
        setError('این ایمیل قبلاً در سامانه ثبت شده است.');
        setIsLoading(false);
        return;
      }

      const hash = await hashPassword(regPassword);
      const newUser: User = {
        id: 'u-' + Math.random().toString(36).substr(2, 9),
        email: regEmail.trim(),
        passwordHash: hash,
        fullName: regFullName.trim(),
        companyName: regCompanyName.trim(),
        createdAt: new Date().toISOString()
      };

      saveUser(newUser);
      setSuccess('ثبت‌نام شما با موفقیت انجام شد!');
      
      setTimeout(() => {
        // Auto-login after registration
        proceedWithSession(newUser);
      }, 1200);

    } catch (err) {
      setError('خطایی در فرآیند ثبت‌نام رخ داد.');
      setIsLoading(false);
    }
  };

  const proceedWithSession = (user: User) => {
    const session: UserSession = {
      userId: user.id,
      email: user.email,
      companyName: user.companyName,
      fullName: user.fullName,
      token: 'token-' + Math.random().toString(36).substr(2, 12)
    };
    
    // Save company info dynamically to the app defaults
    localStorage.setItem('hesabfa_company', JSON.stringify({
      name: user.companyName,
      financialYear: '۱۴۰۵ (جاری)',
      phone: '۰۲۱-۸۸۸۸۸۸۸۸',
      address: 'تهران، دفتر مرکزی شرکت ' + user.companyName,
      taxNumber: '۱۰۳۲' + Math.floor(1000000 + Math.random() * 9000000)
    }));

    onLoginSuccess(session);
  };

  return (
    <div className={`min-h-screen w-full flex flex-col items-center justify-center p-4 relative overflow-hidden transition-all duration-500 font-sans ${isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`} dir="rtl">
      
      {/* Background Glowing Blobs for Glassmorphism */}
      <div className="absolute inset-0 -z-10 pointer-events-none">
        <div className={`absolute top-[15%] left-[10%] w-72 h-72 rounded-full blur-3xl animate-pulse duration-10000 ${isDark ? 'bg-indigo-600/20' : 'bg-indigo-400/10'}`}></div>
        <div className={`absolute bottom-[20%] right-[10%] w-96 h-96 rounded-full blur-3xl animate-pulse duration-8000 ${isDark ? 'bg-blue-600/20' : 'bg-blue-400/15'}`}></div>
        <div className={`absolute top-[40%] right-[40%] w-80 h-80 rounded-full blur-3xl animate-pulse duration-6000 ${isDark ? 'bg-violet-600/15' : 'bg-violet-400/10'}`}></div>
      </div>

      {/* Floating Theme Button */}
      <button
        onClick={() => setIsDark(!isDark)}
        className={`absolute top-6 left-6 p-3 rounded-2xl border transition-all duration-300 backdrop-blur-md shadow-xs ${
          isDark 
            ? 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-amber-400' 
            : 'bg-white/60 border-slate-200 hover:border-slate-300 text-slate-600'
        }`}
        id="theme-toggle-auth"
      >
        {isDark ? <Sun size={18} /> : <Moon size={18} />}
      </button>

      {/* Main Glassmorphic Panel */}
      <div className="w-full max-w-md z-10 flex flex-col items-center">
        
        {/* App Logo & Header */}
        <div className="text-center mb-6">
          <div className={`w-16 h-16 rounded-2xl flex items-center justify-center font-black text-3xl mx-auto shadow-lg mb-4 transition-all duration-300 ${isDark ? 'bg-blue-600 text-white shadow-blue-500/10' : 'bg-blue-600 text-white shadow-blue-500/20'}`}>
            م
          </div>
          <h2 className={`text-xl font-black transition-colors ${isDark ? 'text-white' : 'text-slate-950'}`}>سامانه مالی و حسابداری مانی</h2>
          <p className={`text-[11px] mt-1.5 font-medium ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            تکنولوژی نوین مدیریت یکپارچه حساب‌ها و فاکتورها با رابط کاربری شیشه‌ای
          </p>
        </div>

        {/* Card Body */}
        <div className={`w-full rounded-3xl border backdrop-blur-xl shadow-2xl overflow-hidden transition-all duration-300 p-6 sm:p-8 ${
          isDark 
            ? 'bg-slate-900/40 border-white/5 shadow-black/40' 
            : 'bg-white/40 border-white/40 shadow-slate-200/50'
        }`}>
          
          {/* Tabs Selector */}
          <div className={`flex rounded-2xl p-1 mb-6 border ${isDark ? 'bg-slate-950/40 border-white/5' : 'bg-slate-200/50 border-white/20'}`}>
            <button
              onClick={() => { setActiveTab('login'); setError(null); }}
              className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all duration-300 ${
                activeTab === 'login'
                  ? 'bg-blue-600 text-white shadow-md'
                  : isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              ورود به مانی
            </button>
            <button
              onClick={() => { setActiveTab('register'); setError(null); }}
              className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all duration-300 ${
                activeTab === 'register'
                  ? 'bg-blue-600 text-white shadow-md'
                  : isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              عضویت (ثبت‌نام)
            </button>
          </div>

          {/* Feedback Messages */}
          <AnimatePresence mode="wait">
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mb-4 p-3 rounded-xl text-xs font-bold bg-rose-500/10 text-rose-500 border border-rose-500/20 text-center"
              >
                {error}
              </motion.div>
            )}

            {success && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mb-4 p-3 rounded-xl text-xs font-bold bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 text-center"
              >
                {success}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Form Switch Area */}
          <AnimatePresence mode="wait">
            {activeTab === 'login' ? (
              <motion.form
                key="login-form"
                onSubmit={handleLogin}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                <div>
                  <label className={`block text-[11px] font-bold mb-1.5 ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>پست الکترونیک (ایمیل)</label>
                  <div className="relative">
                    <span className="absolute right-3.5 top-2.5 text-slate-400">
                      <Mail size={16} />
                    </span>
                    <input
                      type="email"
                      required
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      placeholder="name@company.com"
                      className={`w-full pl-4 pr-10 py-2.5 text-xs rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 transition-all font-mono ltr ${
                        isDark 
                          ? 'bg-slate-950/60 border border-white/5 text-white placeholder-slate-500' 
                          : 'bg-white/80 border border-slate-200 text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className={`block text-[11px] font-bold ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>کلمه عبور (پسورد)</label>
                  </div>
                  <div className="relative">
                    <span className="absolute right-3.5 top-2.5 text-slate-400">
                      <Lock size={16} />
                    </span>
                    <input
                      type="password"
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••"
                      className={`w-full pl-4 pr-10 py-2.5 text-xs rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 transition-all font-mono ltr ${
                        isDark 
                          ? 'bg-slate-950/60 border border-white/5 text-white placeholder-slate-500' 
                          : 'bg-white/80 border border-slate-200 text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1 text-[10px] text-slate-400">
                  <ShieldCheck size={14} className="text-blue-500" />
                  <span>داده‌ها به صورت رمزنگاری شده ذخیره می‌گردند.</span>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-all shadow-md shadow-blue-600/10 cursor-pointer"
                >
                  {isLoading ? 'در حال راستی‌آزمایی...' : 'ورود امن به سیستم'}
                </button>

                {/* Helpful Hint */}
                <div className={`p-2.5 rounded-xl border text-[10px] leading-relaxed text-center ${isDark ? 'bg-slate-950/40 border-white/5 text-slate-400' : 'bg-slate-50 border-slate-100 text-slate-500'}`}>
                  ایمیل پیش‌فرض دمو: <span className="font-mono font-bold text-blue-500">admin@mani.com</span> و کلمه عبور: <span className="font-mono font-bold text-blue-500">123456</span>
                </div>

              </motion.form>
            ) : (
              <motion.form
                key="register-form"
                onSubmit={handleRegister}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.2 }}
                className="space-y-3.5"
              >
                <div>
                  <label className={`block text-[11px] font-bold mb-1.5 ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>نام و نام خانوادگی مدیر ارشد</label>
                  <div className="relative">
                    <span className="absolute right-3.5 top-2.5 text-slate-400">
                      <UserIcon size={16} />
                    </span>
                    <input
                      type="text"
                      required
                      value={regFullName}
                      onChange={(e) => setRegFullName(e.target.value)}
                      placeholder="بهنام مانی"
                      className={`w-full pl-4 pr-10 py-2.5 text-xs rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 transition-all ${
                        isDark 
                          ? 'bg-slate-950/60 border border-white/5 text-white placeholder-slate-500' 
                          : 'bg-white/80 border border-slate-200 text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>
                </div>

                <div>
                  <label className={`block text-[11px] font-bold mb-1.5 ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>نام شرکت یا بنگاه تجاری</label>
                  <div className="relative">
                    <span className="absolute right-3.5 top-2.5 text-slate-400">
                      <Building2 size={16} />
                    </span>
                    <input
                      type="text"
                      required
                      value={regCompanyName}
                      onChange={(e) => setRegCompanyName(e.target.value)}
                      placeholder="بازرگانی البرز"
                      className={`w-full pl-4 pr-10 py-2.5 text-xs rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 transition-all ${
                        isDark 
                          ? 'bg-slate-950/60 border border-white/5 text-white placeholder-slate-500' 
                          : 'bg-white/80 border border-slate-200 text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>
                </div>

                <div>
                  <label className={`block text-[11px] font-bold mb-1.5 ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>پست الکترونیک (ایمیل)</label>
                  <div className="relative">
                    <span className="absolute right-3.5 top-2.5 text-slate-400">
                      <Mail size={16} />
                    </span>
                    <input
                      type="email"
                      required
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="name@company.com"
                      className={`w-full pl-4 pr-10 py-2.5 text-xs rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 transition-all font-mono ltr ${
                        isDark 
                          ? 'bg-slate-950/60 border border-white/5 text-white placeholder-slate-500' 
                          : 'bg-white/80 border border-slate-200 text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className={`block text-[11px] font-bold mb-1.5 ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>کلمه عبور</label>
                    <div className="relative">
                      <span className="absolute right-3 top-2.5 text-slate-400">
                        <KeyRound size={15} />
                      </span>
                      <input
                        type="password"
                        required
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        placeholder="••••••"
                        className={`w-full pl-3 pr-8.5 py-2.5 text-xs rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 transition-all font-mono ltr ${
                          isDark 
                            ? 'bg-slate-950/60 border border-white/5 text-white placeholder-slate-500' 
                            : 'bg-white/80 border border-slate-200 text-slate-900 placeholder-slate-400'
                        }`}
                      />
                    </div>
                  </div>

                  <div>
                    <label className={`block text-[11px] font-bold mb-1.5 ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>تایید عبور</label>
                    <div className="relative">
                      <span className="absolute right-3 top-2.5 text-slate-400">
                        <KeyRound size={15} />
                      </span>
                      <input
                        type="password"
                        required
                        value={regConfirmPassword}
                        onChange={(e) => setRegConfirmPassword(e.target.value)}
                        placeholder="••••••"
                        className={`w-full pl-3 pr-8.5 py-2.5 text-xs rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 transition-all font-mono ltr ${
                          isDark 
                            ? 'bg-slate-950/60 border border-white/5 text-white placeholder-slate-500' 
                            : 'bg-white/80 border border-slate-200 text-slate-900 placeholder-slate-400'
                        }`}
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-all shadow-md shadow-blue-600/10 cursor-pointer mt-2"
                >
                  {isLoading ? 'در حال ثبت اطلاعات...' : 'ثبت نام و ایجاد شرکت مانی'}
                </button>
              </motion.form>
            )}
          </AnimatePresence>

        </div>

        {/* Footer Credit */}
        <div className={`mt-8 text-center text-[10px] flex items-center gap-1 font-semibold ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
          <span>تضمین امنیت با رمزنگاری کلاینت‌ساید</span>
          <span className="text-blue-500">•</span>
          <span>سامانه حسابداری مانی ۱۴۰۵</span>
        </div>

      </div>
    </div>
  );
}
