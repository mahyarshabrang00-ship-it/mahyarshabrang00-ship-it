/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ItemService } from '../types';
import { 
  Cpu, 
  Plus, 
  Trash2, 
  Calculator, 
  CheckCircle, 
  Clipboard, 
  TrendingUp, 
  RefreshCw, 
  AlertTriangle 
} from 'lucide-react';

interface ProductionProps {
  items: ItemService[];
  setItems: React.Dispatch<React.SetStateAction<ItemService[]>>;
  subTabAction?: any;
  setSubTabAction?: any;
}

interface Formula {
  id: string;
  name: string;
  targetItemId: string;
  targetQty: number;
  components: {
    itemId: string;
    qty: number;
  }[];
  overheadCost: number; // هزینه سربار
}

interface ProductionOrder {
  id: string;
  formulaId: string;
  qtyToProduce: number;
  status: 'pending' | 'completed';
  date: string;
}

export default function Production({ items, setItems, subTabAction, setSubTabAction }: ProductionProps) {
  const [activeTab, setActiveTab] = useState<'formulas' | 'orders' | 'requirements'>('formulas');

  // Initial Seed Formulas
  const [formulas, setFormulas] = useState<Formula[]>(() => {
    return [
      {
        id: 'f-1',
        name: 'بسته‌بندی ست چای مجلل',
        targetItemId: '1', // Suppose item id 1 is a final item, we'll map dynamically
        targetQty: 10,
        components: [
          { itemId: '2', qty: 10 },
          { itemId: '3', qty: 2 }
        ],
        overheadCost: 150000
      }
    ];
  });

  const [orders, setOrders] = useState<ProductionOrder[]>([
    {
      id: 'po-101',
      formulaId: 'f-1',
      qtyToProduce: 50,
      status: 'pending',
      date: '۱۴۰۵/۰۴/۱۸'
    }
  ]);

  // Form states for Formula
  const [isNewFormulaOpen, setIsNewFormulaOpen] = useState(false);
  const [formulaName, setFormulaName] = useState('');
  const [targetItemId, setTargetItemId] = useState('');
  const [targetQty, setTargetQty] = useState(1);
  const [overheadCost, setOverheadCost] = useState(0);
  const [formulaComponents, setFormulaComponents] = useState<{ itemId: string; qty: number }[]>([
    { itemId: '', qty: 1 }
  ]);

  // Form states for Order
  const [isNewOrderOpen, setIsNewOrderOpen] = useState(false);
  const [orderFormulaId, setOrderFormulaId] = useState('');
  const [orderQty, setOrderQty] = useState(1);

  // Handle Action Triggered from Sidebar
  React.useEffect(() => {
    if (subTabAction && subTabAction.tab === 'production') {
      if (subTabAction.action === 'new-formula') {
        setActiveTab('formulas');
        setIsNewFormulaOpen(true);
      } else if (subTabAction.action === 'new-order') {
        setActiveTab('orders');
        setIsNewOrderOpen(true);
      } else if (subTabAction.action === 'requirements') {
        setActiveTab('requirements');
      }
      if (setSubTabAction) {
        setSubTabAction(null);
      }
    }
  }, [subTabAction]);

  const rawMaterials = items.filter(item => !item.isService);

  const formatMoney = (value: number) => {
    return value.toLocaleString('fa-IR') + ' تومان';
  };

  const formatNumber = (value: number) => {
    return value.toLocaleString('fa-IR');
  };

  // Add component row to new formula
  const addComponentRow = () => {
    setFormulaComponents([...formulaComponents, { itemId: '', qty: 1 }]);
  };

  const removeComponentRow = (index: number) => {
    setFormulaComponents(formulaComponents.filter((_, i) => i !== index));
  };

  const handleComponentChange = (index: number, field: 'itemId' | 'qty', value: string | number) => {
    const updated = [...formulaComponents];
    if (field === 'itemId') {
      updated[index].itemId = String(value);
    } else {
      updated[index].qty = Number(value);
    }
    setFormulaComponents(updated);
  };

  const handleCreateFormula = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formulaName.trim() || !targetItemId) return;

    const newFormula: Formula = {
      id: 'f-' + Date.now(),
      name: formulaName,
      targetItemId,
      targetQty,
      components: formulaComponents.filter(c => c.itemId !== ''),
      overheadCost
    };

    setFormulas([...formulas, newFormula]);
    setIsNewFormulaOpen(false);
    // Reset Form
    setFormulaName('');
    setTargetItemId('');
    setTargetQty(1);
    setOverheadCost(0);
    setFormulaComponents([{ itemId: '', qty: 1 }]);
  };

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderFormulaId) return;

    const newOrder: ProductionOrder = {
      id: 'po-' + (100 + orders.length + 1),
      formulaId: orderFormulaId,
      qtyToProduce: orderQty,
      status: 'pending',
      date: '۱۴۰۵/۰۴/' + String(new Date().getDate()).padStart(2, '0')
    };

    setOrders([newOrder, ...orders]);
    setIsNewOrderOpen(false);
  };

  const handleCompleteOrder = (order: ProductionOrder) => {
    const formula = formulas.find(f => f.id === order.formulaId);
    if (!formula) return;

    // Check inventory availability
    const factor = order.qtyToProduce / formula.targetQty;
    let canProduce = true;
    const missingItems: { name: string; missing: number }[] = [];

    formula.components.forEach(comp => {
      const itemInDb = items.find(i => i.id === comp.itemId);
      const needed = comp.qty * factor;
      if (!itemInDb || itemInDb.stock < needed) {
        canProduce = false;
        missingItems.push({
          name: itemInDb ? itemInDb.name : 'کالای نامشخص',
          missing: needed - (itemInDb ? itemInDb.stock : 0)
        });
      }
    });

    if (!canProduce) {
      alert(`موجودی انبار کافی نیست!\nکمبود اقلام زیر مانع تولید است:\n` + 
        missingItems.map(m => `- ${m.name}: کمبود ${formatNumber(m.missing)} واحد`).join('\n')
      );
      return;
    }

    // Deduct stock from components, increase stock for target item
    const updatedItems = items.map(item => {
      // Is it a component?
      const comp = formula.components.find(c => c.itemId === item.id);
      if (comp) {
        return { ...item, stock: item.stock - (comp.qty * factor) };
      }
      // Is it the produced item?
      if (item.id === formula.targetItemId) {
        return { ...item, stock: item.stock + order.qtyToProduce };
      }
      return item;
    });

    setItems(updatedItems);
    setOrders(orders.map(o => o.id === order.id ? { ...o, status: 'completed' } : o));
    alert('تولید محصول با موفقیت انجام شد و حواله انبار ثبت گردید!');
  };

  return (
    <div className="space-y-6">
      
      {/* Tab Selectors */}
      <div className="flex border-b border-slate-200/40 pb-px print:hidden">
        <button
          onClick={() => setActiveTab('formulas')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'formulas' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Cpu size={14} />
          فرمول‌های تولید (BOM)
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'orders' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Clipboard size={14} />
          دستورات و سفارشات تولید
        </button>
        <button
          onClick={() => setActiveTab('requirements')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'requirements' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Calculator size={14} />
          نیازسنجی مواد اولیه
        </button>
      </div>

      {/* formulas tab */}
      {activeTab === 'formulas' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-slate-700">لیست فرمول‌های ثبت شده برای فرآورده‌ها</h3>
            <button
              onClick={() => setIsNewFormulaOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold px-3 py-2 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm shadow-blue-100"
            >
              <Plus size={14} />
              فرمول تولید جدید
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {formulas.map(formula => {
              const target = items.find(i => i.id === formula.targetItemId);
              // Calculate unit cost
              let componentsCost = 0;
              formula.components.forEach(comp => {
                const item = items.find(i => i.id === comp.itemId);
                componentsCost += (item?.purchasePrice || 0) * comp.qty;
              });
              const totalCost = componentsCost + formula.overheadCost;
              const unitCost = totalCost / formula.targetQty;

              return (
                <div key={formula.id} className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm relative overflow-hidden group">
                  <div className="absolute top-0 right-0 left-0 h-1.5 bg-blue-500/10 group-hover:bg-blue-500/20 transition-colors"></div>
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h4 className="font-black text-xs text-slate-800">{formula.name}</h4>
                      <p className="text-[10px] text-slate-400 mt-1">محصول نهایی: {target ? target.name : 'نامشخص'}</p>
                    </div>
                    <span className="bg-blue-50 text-blue-700 font-black text-[9px] px-2.5 py-1 rounded-lg">
                      تعداد خروجی: {formatNumber(formula.targetQty)} {target?.unit || 'عدد'}
                    </span>
                  </div>

                  {/* Components */}
                  <div className="space-y-2 border-t border-slate-50 pt-3">
                    <span className="text-[9px] font-bold text-slate-400 block">مواد مورد نیاز:</span>
                    {formula.components.map((comp, idx) => {
                      const compItem = items.find(i => i.id === comp.itemId);
                      return (
                        <div key={idx} className="flex items-center justify-between text-[11px] text-slate-600 bg-slate-50/40 px-2 py-1.5 rounded-lg border border-slate-50">
                          <span className="font-semibold">{compItem ? compItem.name : 'کالای حذف شده'}</span>
                          <span className="font-mono text-[10px]">{formatNumber(comp.qty)} {compItem?.unit || 'واحد'}</span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Costing Footer */}
                  <div className="border-t border-slate-50 mt-4 pt-3 flex items-center justify-between text-[11px]">
                    <div>
                      <span className="text-[9px] text-slate-400 block">هزینه سربار تولید</span>
                      <span className="font-bold text-slate-700">{formatMoney(formula.overheadCost)}</span>
                    </div>
                    <div className="text-left">
                      <span className="text-[9px] text-slate-400 block">بهای تمام شده هر واحد</span>
                      <span className="font-black text-emerald-600">{formatMoney(unitCost)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* New Formula Modal */}
          {isNewFormulaOpen && (
            <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
              <div className="bg-white border border-slate-100 rounded-3xl w-full max-w-2xl shadow-2xl p-6 text-right max-h-[85vh] overflow-y-auto">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                  <h3 className="font-black text-slate-800 text-sm">فرمول تولید جدید (BOM)</h3>
                  <button onClick={() => setIsNewFormulaOpen(false)} className="text-slate-400 hover:text-slate-600 text-lg cursor-pointer">×</button>
                </div>

                <form onSubmit={handleCreateFormula} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 mb-1">نام فرمول تولید</label>
                      <input 
                        type="text" 
                        required
                        value={formulaName}
                        onChange={(e) => setFormulaName(e.target.value)}
                        placeholder="مانند: بسته‌بندی پکیج یلدا"
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-semibold"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 mb-1">محصول فرآوری شده نهایی</label>
                      <select 
                        required
                        value={targetItemId}
                        onChange={(e) => setTargetItemId(e.target.value)}
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-semibold"
                      >
                        <option value="">انتخاب محصول نهایی...</option>
                        {items.map(item => (
                          <option key={item.id} value={item.id}>{item.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 mb-1">تعداد خروجی فرآورده</label>
                      <input 
                        type="number" 
                        required
                        min="1"
                        value={targetQty}
                        onChange={(e) => setTargetQty(Number(e.target.value))}
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 mb-1">هزینه سربار مستقیم (تومان)</label>
                      <input 
                        type="number" 
                        required
                        min="0"
                        value={overheadCost}
                        onChange={(e) => setOverheadCost(Number(e.target.value))}
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-mono"
                      />
                    </div>
                  </div>

                  {/* Components Builder */}
                  <div className="space-y-2 border-t border-slate-50 pt-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-slate-500">لیست مواد اولیه مصرفی</span>
                      <button 
                        type="button" 
                        onClick={addComponentRow}
                        className="text-blue-600 hover:text-blue-700 font-black text-[10px] flex items-center gap-1 cursor-pointer"
                      >
                        <Plus size={12} />
                        افزودن ردیف ماده اولیه
                      </button>
                    </div>

                    {formulaComponents.map((component, index) => (
                      <div key={index} className="flex items-center gap-2 bg-slate-50/40 p-2 rounded-xl border border-slate-50">
                        <div className="flex-1">
                          <select
                            required
                            value={component.itemId}
                            onChange={(e) => handleComponentChange(index, 'itemId', e.target.value)}
                            className="w-full text-xs bg-white p-2 rounded-lg border border-slate-100"
                          >
                            <option value="">انتخاب ماده اولیه...</option>
                            {rawMaterials.map(m => (
                              <option key={m.id} value={m.id}>{m.name} (موجودی: {formatNumber(m.stock)})</option>
                            ))}
                          </select>
                        </div>
                        <div className="w-24">
                          <input
                            type="number"
                            required
                            min="0.1"
                            step="any"
                            value={component.qty}
                            onChange={(e) => handleComponentChange(index, 'qty', e.target.value)}
                            placeholder="مقدار"
                            className="w-full text-xs bg-white p-2 rounded-lg border border-slate-100 text-center font-mono"
                          />
                        </div>
                        {formulaComponents.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeComponentRow(index)}
                            className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg cursor-pointer"
                          >
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setIsNewFormulaOpen(false)}
                      className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-50 rounded-xl cursor-pointer"
                    >
                      انصراف
                    </button>
                    <button
                      type="submit"
                      className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-black px-4 py-2 rounded-xl cursor-pointer"
                    >
                      ثبت فرمول تولید
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* orders tab */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-slate-700">لیست دستورات تولید فعال و معلق</h3>
            <button
              onClick={() => setIsNewOrderOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold px-3 py-2 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm shadow-blue-100"
            >
              <Plus size={14} />
              دستور تولید جدید
            </button>
          </div>

          <div className="bg-white border border-slate-100 rounded-3xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50/80 border-b border-slate-100 text-slate-500 font-bold">
                  <tr>
                    <th className="p-4">شماره دستور</th>
                    <th className="p-4">فرمول تولید</th>
                    <th className="p-4">فرآورده نهایی</th>
                    <th className="p-4">مقدار تولید</th>
                    <th className="p-4">تاریخ صدور</th>
                    <th className="p-4">وضعیت عملیات</th>
                    <th className="p-4">اقدام</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {orders.map(order => {
                    const formula = formulas.find(f => f.id === order.formulaId);
                    const target = items.find(i => i?.id === formula?.targetItemId);

                    return (
                      <tr key={order.id} className="hover:bg-slate-50/40">
                        <td className="p-4 font-mono font-black text-slate-800">{order.id}</td>
                        <td className="p-4 font-bold">{formula ? formula.name : 'نامشخص'}</td>
                        <td className="p-4 text-slate-500">{target ? target.name : 'نامشخص'}</td>
                        <td className="p-4 font-mono font-bold text-slate-700">
                          {formatNumber(order.qtyToProduce)} {target?.unit || 'واحد'}
                        </td>
                        <td className="p-4 font-mono text-slate-400">{order.date}</td>
                        <td className="p-4">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold text-[9px] ${
                            order.status === 'completed'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                              : 'bg-amber-50 text-amber-700 border border-amber-100'
                          }`}>
                            <span className={`w-1 h-1 rounded-full ${order.status === 'completed' ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`}></span>
                            {order.status === 'completed' ? 'تولید شده' : 'در انتظار تولید'}
                          </span>
                        </td>
                        <td className="p-4">
                          {order.status === 'pending' ? (
                            <button
                              onClick={() => handleCompleteOrder(order)}
                              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] px-2.5 py-1.5 rounded-lg cursor-pointer flex items-center gap-1 shadow-xs"
                            >
                              <CheckCircle size={12} />
                              اجرای فرآیند تولید
                            </button>
                          ) : (
                            <span className="text-[10px] font-bold text-slate-400">حواله شده</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* New Order Modal */}
          {isNewOrderOpen && (
            <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
              <div className="bg-white border border-slate-100 rounded-3xl w-full max-w-md shadow-2xl p-6 text-right">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                  <h3 className="font-black text-slate-800 text-sm">صدور دستور تولید جدید</h3>
                  <button onClick={() => setIsNewOrderOpen(false)} className="text-slate-400 hover:text-slate-600 text-lg cursor-pointer">×</button>
                </div>

                <form onSubmit={handleCreateOrder} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1">انتخاب فرمول تولید مبنا</label>
                    <select
                      required
                      value={orderFormulaId}
                      onChange={(e) => setOrderFormulaId(e.target.value)}
                      className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-semibold"
                    >
                      <option value="">یک فرمول انتخاب کنید...</option>
                      {formulas.map(f => {
                        const target = items.find(i => i.id === f.targetItemId);
                        return (
                          <option key={f.id} value={f.id}>
                            {f.name} (هدف: {target?.name})
                          </option>
                        );
                      })}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1">تعداد/مقدار فرآورده نهایی برای تولید</label>
                    <input
                      type="number"
                      required
                      min="1"
                      value={orderQty}
                      onChange={(e) => setOrderQty(Number(e.target.value))}
                      className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-mono"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setIsNewOrderOpen(false)}
                      className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-50 rounded-xl cursor-pointer"
                    >
                      انصراف
                    </button>
                    <button
                      type="submit"
                      className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-black px-4 py-2 rounded-xl cursor-pointer"
                    >
                      ثبت دستور تولید
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* requirements tab */}
      {activeTab === 'requirements' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-xs">
            <h4 className="font-black text-xs text-slate-800 mb-2">آنالیز و کسری مواد اولیه برای کل سفارشات معلق</h4>
            <p className="text-[10px] text-slate-400">سیستم به صورت خودکار فرمول محصولات معلق را خوانده و با موجودی زنده انبار مقایسه می‌کند.</p>

            <div className="mt-5 space-y-3">
              {orders.filter(o => o.status === 'pending').map(order => {
                const formula = formulas.find(f => f.id === order.formulaId);
                const target = items.find(i => i.id === formula?.targetItemId);
                if (!formula || !target) return null;

                const factor = order.qtyToProduce / formula.targetQty;

                return (
                  <div key={order.id} className="border border-slate-100 rounded-2xl p-4 bg-slate-50/20">
                    <div className="flex items-center justify-between mb-3 text-[11px] font-bold text-slate-700">
                      <span>سفارش شماره {order.id} (تولید {formatNumber(order.qtyToProduce)} {target.name})</span>
                      <span className="text-[9px] text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md">در صف آنالیز کسری</span>
                    </div>

                    <div className="space-y-2">
                      {formula.components.map(comp => {
                        const rawItem = items.find(i => i.id === comp.itemId);
                        if (!rawItem) return null;
                        const neededQty = comp.qty * factor;
                        const hasDeficit = rawItem.stock < neededQty;
                        const deficitAmount = hasDeficit ? neededQty - rawItem.stock : 0;

                        return (
                          <div key={comp.itemId} className="flex items-center justify-between text-xs py-1 border-b border-slate-100/50 last:border-0">
                            <div>
                              <span className="font-semibold text-slate-800">{rawItem.name}</span>
                              <span className="text-[9px] text-slate-400 block">نیاز برای این سفارش: {formatNumber(neededQty)} {rawItem.unit} | موجود در انبار: {formatNumber(rawItem.stock)} {rawItem.unit}</span>
                            </div>
                            <div>
                              {hasDeficit ? (
                                <span className="inline-flex items-center gap-1 text-[10px] font-black text-rose-600 bg-rose-50 px-2 py-1 rounded-lg">
                                  <AlertTriangle size={11} />
                                  کسری دارد: {formatNumber(deficitAmount)} {rawItem.unit}
                                </span>
                              ) : (
                                <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">تامین شده</span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}

              {orders.filter(o => o.status === 'pending').length === 0 && (
                <div className="text-center py-8 text-slate-400">
                  <TrendingUp size={32} className="mx-auto mb-2 text-slate-300" />
                  <p className="text-xs">هیچ سفارش تولید معلقی برای آنالیز کسری وجود ندارد.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
