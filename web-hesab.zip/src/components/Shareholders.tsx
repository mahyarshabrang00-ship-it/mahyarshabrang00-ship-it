/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Shareholder, Contact } from '../types';
import { 
  Plus, 
  Trash2, 
  ArrowRight, 
  Save, 
  Check, 
  AlertTriangle, 
  UserPlus,
  ArrowLeft,
  Users
} from 'lucide-react';

interface ShareholdersProps {
  contacts: Contact[];
  setContacts: React.Dispatch<React.SetStateAction<Contact[]>>;
  shareholders: Shareholder[];
  setShareholders: React.Dispatch<React.SetStateAction<Shareholder[]>>;
  onBack?: () => void;
}

export default function Shareholders({
  contacts,
  setContacts,
  shareholders,
  setShareholders,
  onBack
}: ShareholdersProps) {
  const [items, setItems] = useState<Shareholder[]>([]);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [quickContactOpen, setQuickContactOpen] = useState(false);
  const [quickName, setQuickName] = useState('');

  // Sync state from props on mount/update
  useEffect(() => {
    if (shareholders && shareholders.length > 0) {
      setItems(shareholders);
    } else {
      // Default initial shareholders
      const defaults: Shareholder[] = [
        { id: 'sh1', contactId: 'sh_c1', contactName: 'آقای جمالی', percentage: 50 },
        { id: 'sh2', contactId: 'sh_c2', contactName: 'مهندس قنبرزاده', percentage: 50 }
      ];
      setItems(defaults);
    }
  }, [shareholders]);

  // Calculations
  const totalCount = items.length;
  const totalPercentage = items.reduce((sum, item) => sum + (Number(item.percentage) || 0), 0);

  // Add a new row
  const handleAddRow = () => {
    const newItem: Shareholder = {
      id: `sh_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      contactId: '',
      contactName: '',
      percentage: 0
    };
    setItems([...items, newItem]);
  };

  // Remove a row
  const handleRemoveRow = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  // Update a field in a row
  const handleUpdateRow = (id: string, field: keyof Shareholder, value: any) => {
    setItems(items.map(item => {
      if (item.id === id) {
        if (field === 'contactId') {
          // Find the contact's actual name to cache it
          const contact = contacts.find(c => c.id === value);
          return {
            ...item,
            contactId: value,
            contactName: contact ? contact.name : ''
          };
        }
        return { ...item, [field]: value };
      }
      return item;
    }));
  };

  // Create quick contact
  const handleCreateQuickContact = () => {
    if (!quickName.trim()) return;
    const newId = `c_${Date.now()}`;
    const newContact: Contact = {
      id: newId,
      code: `۰۰۰${contacts.length + 1}`.slice(-5),
      name: quickName.trim(),
      phone: '',
      email: '',
      type: 'shareholder',
      balance: 0,
      address: '',
      nationalId: '',
      category: 'سهامداران',
      isActive: true
    };
    setContacts(prev => [...prev, newContact]);
    
    // Auto-select this contact in any empty or newly added row
    setItems(prev => {
      // Find the first item with empty contactId, or add a new one
      const emptyIndex = prev.findIndex(item => !item.contactId);
      if (emptyIndex !== -1) {
        return prev.map((item, idx) => idx === emptyIndex ? { ...item, contactId: newId, contactName: quickName.trim() } : item);
      } else {
        return [...prev, { id: `sh_${Date.now()}`, contactId: newId, contactName: quickName.trim(), percentage: 0 }];
      }
    });

    setQuickName('');
    setQuickContactOpen(false);
  };

  // Save changes
  const handleSave = () => {
    setShareholders(items);
    localStorage.setItem('hesabfa_shareholders', JSON.stringify(items));
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  // Filter contacts who are shareholders or general
  const shareholderContacts = contacts.filter(c => c.type === 'shareholder' || c.category === 'سهامداران' || c.type === 'both');

  return (
    <div className="flex flex-col h-full bg-slate-50/50" dir="rtl" id="shareholders-root">
      {/* Top Header */}
      <div className="flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
            <Users size={22} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">سهامداران</h1>
            <p className="text-xs text-slate-500 mt-0.5">مدیریت اعضای هیئت مدیره و سهامداران شرکت مانی</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Save Button */}
          <button 
            onClick={handleSave}
            id="btn-save-shareholders"
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-medium transition shadow-sm text-sm"
          >
            {saveSuccess ? <Check size={16} /> : <Save size={16} />}
            <span>{saveSuccess ? 'ذخیره شد' : 'ذخیره تغییرات'}</span>
          </button>

          {/* Quick Contact Button */}
          <button 
            onClick={() => setQuickContactOpen(true)}
            id="btn-quick-contact"
            className="flex items-center gap-2 px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-600 bg-white rounded-xl transition text-sm"
          >
            <UserPlus size={16} />
            <span>افزودن شخص جدید</span>
          </button>

          {/* Back Button */}
          {onBack && (
            <button 
              onClick={onBack}
              id="btn-back-shareholders"
              className="flex items-center justify-center p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition"
              title="بازگشت"
            >
              <ArrowLeft size={20} />
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 p-6 space-y-6 overflow-y-auto">
        {/* Statistics Green-Bordered Card */}
        <div id="stats-card" className="bg-emerald-50/30 border-2 border-emerald-500/30 rounded-2xl p-5 flex flex-col md:flex-row items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center gap-6">
            <div className="flex flex-col">
              <span className="text-xs text-slate-500">تعداد کل سهامداران</span>
              <span className="text-2xl font-black text-slate-800 mt-1">{totalCount} نفر</span>
            </div>
            
            <div className="w-px h-10 bg-slate-200 hidden md:block"></div>
            
            <div className="flex flex-col">
              <span className="text-xs text-slate-500">مجموع سهام توزیع شده</span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className={`text-2xl font-black ${totalPercentage === 100 ? 'text-emerald-600' : 'text-amber-600'}`}>
                  {totalPercentage}٪
                </span>
                {totalPercentage !== 100 && (
                  <span className="text-xs text-amber-600 font-medium flex items-center gap-1 mr-2 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200">
                    <AlertTriangle size={12} />
                    باید ۱۰۰٪ باشد
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Add Row Button inside statistics */}
          <button 
            onClick={handleAddRow}
            id="btn-add-row"
            className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition shadow-md shadow-emerald-600/10 hover:shadow-lg hover:shadow-emerald-600/20 text-sm"
          >
            <Plus size={16} />
            <span>افزودن ردیف</span>
          </button>
        </div>

        {/* Shareholders Table Container */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm" id="shareholders-table-container">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-semibold select-none">
                <th className="py-4 px-6 text-center w-16">#</th>
                <th className="py-4 px-6">سهامدار</th>
                <th className="py-4 px-6 w-48 text-center">درصد سهم</th>
                <th className="py-4 px-6 w-16 text-center">حذف</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {items.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-slate-400 text-sm">
                    هیچ ردیفی تعریف نشده است. بر روی دکمه <strong className="text-emerald-600 font-bold">افزودن ردیف</strong> کلیک کنید.
                  </td>
                </tr>
              ) : (
                items.map((item, index) => (
                  <tr key={item.id} className="hover:bg-slate-50/50 group transition duration-150">
                    {/* Index */}
                    <td className="py-3 px-6 text-center text-slate-400 font-medium text-sm w-16 select-none">
                      {index + 1}
                    </td>

                    {/* Shareholder Dropdown / Free text Selection */}
                    <td className="py-3 px-6">
                      <div className="flex items-center gap-2">
                        <select
                          value={item.contactId || ''}
                          onChange={(e) => handleUpdateRow(item.id, 'contactId', e.target.value)}
                          className="flex-1 max-w-lg bg-slate-50 hover:bg-slate-100/70 border border-slate-200 focus:border-emerald-500 rounded-xl px-3 py-2 text-slate-700 text-sm font-medium transition outline-none"
                        >
                          <option value="">-- انتخاب سهامدار --</option>
                          {shareholderContacts.map(c => (
                            <option key={c.id} value={c.id}>
                              {c.code ? `${c.code} - ` : ''}{c.name}
                            </option>
                          ))}
                          {/* If current contact is not in list but we have it, show as custom option */}
                          {item.contactId && !shareholderContacts.find(c => c.id === item.contactId) && (
                            <option value={item.contactId}>
                              {item.contactName}
                            </option>
                          )}
                        </select>

                        {/* Or inline prompt to add name directly */}
                        {!item.contactId && (
                          <input
                            type="text"
                            placeholder="یا نام سهامدار را وارد کنید..."
                            value={item.contactName || ''}
                            onChange={(e) => handleUpdateRow(item.id, 'contactName', e.target.value)}
                            className="flex-1 bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3 py-2 text-slate-700 text-sm transition outline-none"
                          />
                        )}
                      </div>
                    </td>

                    {/* Percentage input */}
                    <td className="py-3 px-6 w-48 text-center">
                      <div className="flex items-center justify-center gap-2 max-w-[140px] mx-auto bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 focus-within:border-emerald-500 transition">
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={item.percentage === 0 ? '' : item.percentage}
                          onChange={(e) => {
                            const val = e.target.value === '' ? 0 : Math.min(100, Math.max(0, Number(e.target.value)));
                            handleUpdateRow(item.id, 'percentage', val);
                          }}
                          className="w-16 bg-transparent text-center font-bold text-slate-800 text-base outline-none border-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                          placeholder="۰"
                        />
                        <span className="text-slate-400 font-bold">%</span>
                      </div>
                    </td>

                    {/* Delete action */}
                    <td className="py-3 px-6 text-center w-16">
                      <button
                        onClick={() => handleRemoveRow(item.id)}
                        className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition duration-150"
                        title="حذف ردیف"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Contact Modal */}
      {quickContactOpen && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center z-50 p-4 transition duration-200">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-xl border border-slate-100 overflow-hidden" id="quick-contact-modal">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-800">تعریف شخص جدید (سهامدار)</h3>
              <button 
                onClick={() => setQuickContactOpen(false)}
                className="text-slate-400 hover:text-slate-600 transition"
              >
                <X size={18} />
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">نام و نام خانوادگی *</label>
                <input
                  type="text"
                  placeholder="مثال: جناب آقای دکتر سهرابی"
                  value={quickName}
                  onChange={(e) => setQuickName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-sm text-slate-800 outline-none transition"
                  autoFocus
                />
              </div>
            </div>

            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                onClick={() => setQuickContactOpen(false)}
                className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-100 transition text-sm font-medium"
              >
                انصراف
              </button>
              <button
                onClick={handleCreateQuickContact}
                disabled={!quickName.trim()}
                className="px-5 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition text-sm font-medium disabled:opacity-50"
              >
                ایجاد و انتخاب
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Inline X Icon as fallback
function X({ size, className }: { size?: number, className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width={size || 24} 
      height={size || 24} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M18 6 6 18M6 6l12 12" />
    </svg>
  );
}
