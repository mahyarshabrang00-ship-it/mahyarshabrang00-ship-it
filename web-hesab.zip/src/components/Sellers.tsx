/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Seller, Contact, ItemService } from '../types';
import { 
  Plus, 
  Trash2, 
  Edit2, 
  Save, 
  ArrowLeft, 
  Check, 
  X, 
  Search, 
  User, 
  Coins, 
  TrendingUp, 
  Sliders, 
  Activity, 
  ChevronRight, 
  ChevronLeft,
  ChevronDown,
  DollarSign,
  Briefcase,
  Percent,
  ArrowRight
} from 'lucide-react';

interface SellersProps {
  contacts: Contact[];
  setContacts: React.Dispatch<React.SetStateAction<Contact[]>>;
  sellers: Seller[];
  setSellers: React.Dispatch<React.SetStateAction<Seller[]>>;
  items: ItemService[];
  setItems: React.Dispatch<React.SetStateAction<ItemService[]>>;
  onBack?: () => void;
}

export interface CategoryItem {
  id: string;
  name: string;
  level: number;
  parentId: string | null;
}

export const SYSTEM_CATEGORIES: CategoryItem[] = [
  { id: 'cat_goods', name: 'کالاها', level: 0, parentId: null },
  { id: 'cat_kitchen_appliances', name: 'لوازم برقی آشپزخانه', level: 1, parentId: 'cat_goods' },
  { id: 'cat_samsung_kitchen', name: 'سامسونگ', level: 2, parentId: 'cat_kitchen_appliances' },
  { id: 'cat_lg_kitchen', name: 'ال جی', level: 2, parentId: 'cat_kitchen_appliances' },
  { id: 'cat_bosch_kitchen', name: 'بوش', level: 2, parentId: 'cat_kitchen_appliances' },
  { id: 'cat_philips_kitchen', name: 'فیلیپس', level: 2, parentId: 'cat_kitchen_appliances' },
  { id: 'cat_snowa_kitchen', name: 'اسنوا', level: 2, parentId: 'cat_kitchen_appliances' },
  { id: 'cat_depoint_kitchen', name: 'دیپوینت', level: 2, parentId: 'cat_kitchen_appliances' },
  { id: 'cat_home_appliances', name: 'برقی منزل', level: 1, parentId: 'cat_goods' },
  { id: 'cat_bosch_home', name: 'بوش', level: 2, parentId: 'cat_home_appliances' },
  { id: 'cat_sony_home', name: 'سونی', level: 2, parentId: 'cat_home_appliances' },
  { id: 'cat_samsung_home', name: 'سامسونگ', level: 2, parentId: 'cat_home_appliances' },
  { id: 'cat_lg_home', name: 'ال جی', level: 2, parentId: 'cat_home_appliances' },
  { id: 'cat_henrich_home', name: 'هنریج', level: 2, parentId: 'cat_home_appliances' },
  { id: 'cat_dyson_home', name: 'دایسون', level: 2, parentId: 'cat_home_appliances' },
  { id: 'cat_lighting', name: 'روشنایی', level: 1, parentId: 'cat_goods' },
  { id: 'cat_kitchenware', name: 'لوازم آشپزخانه', level: 1, parentId: 'cat_goods' },
  { id: 'cat_decorative', name: 'تزیینی', level: 1, parentId: 'cat_goods' },
  { id: 'cat_hygiene', name: 'بهداشتی و حمام', level: 1, parentId: 'cat_goods' },
  { id: 'cat_serving', name: 'لوازم و ابزار پذیرایی', level: 1, parentId: 'cat_goods' },
  { id: 'cat_raw_materials', name: 'مواد اولیه', level: 0, parentId: null },
  { id: 'cat_services', name: 'خدمات', level: 0, parentId: null }
];

export default function Sellers({
  contacts,
  setContacts,
  sellers,
  setSellers,
  items,
  setItems,
  onBack
}: SellersProps) {
  // Views: 'list' or 'form'
  const [viewMode, setViewMode] = useState<'list' | 'form'>('list');
  const [editingSeller, setEditingSeller] = useState<Seller | null>(null);

  // Selection
  const [selectedSellerIds, setSelectedSellerIds] = useState<string[]>([]);

  // List search/filters
  const [filterCode, setFilterCode] = useState('');
  const [filterName, setFilterName] = useState('');
  const [filterExpense, setFilterExpense] = useState('');
  const [filterContact, setFilterContact] = useState('');
  const [filterActive, setFilterActive] = useState<'all' | 'active' | 'inactive'>('all');
  const [filterCommission, setFilterCommission] = useState<'all' | 'yes' | 'no'>('all');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Form Fields State
  const [code, setCode] = useState('');
  const [isAutoCode, setIsAutoCode] = useState(true);
  const [isActive, setIsActive] = useState(true);
  const [name, setName] = useState('');
  const [salesPercent, setSalesPercent] = useState<number>(0);
  const [returnPercent, setReturnPercent] = useState<number>(0);
  const [salesAmount, setSalesAmount] = useState<number>(0);
  const [returnAmount, setReturnAmount] = useState<number>(0);
  const [excludeProductDiscount, setExcludeProductDiscount] = useState(false);
  const [excludeInvoiceAdjustments, setExcludeInvoiceAdjustments] = useState(false);
  const [commissionInInvoice, setCommissionInInvoice] = useState(true);
  const [expenseAccount, setExpenseAccount] = useState('هزینه بازاریابی و پورسانت');
  const [relatedContactId, setRelatedContactId] = useState('');
  const [description, setDescription] = useState('');
  const [productCommissions, setProductCommissions] = useState<{ itemId: string; salesPercent: number; returnPercent: number; }[]>([]);
  const [categoryCommissions, setCategoryCommissions] = useState<{ categoryId: string; salesPercent: number; returnPercent: number; }[]>([]);

  // Product & Category Commissions Editing States
  const [editedProdPercents, setEditedProdPercents] = useState<Record<string, { sales: string; return: string }>>({});
  const [editedCatPercents, setEditedCatPercents] = useState<Record<string, { sales: string; return: string }>>({});
  const [selectedProdIds, setSelectedProdIds] = useState<string[]>([]);
  const [selectedCatIds, setSelectedCatIds] = useState<string[]>([]);

  // Product spreadsheet filters
  const [prodFilterCode, setProdFilterCode] = useState('');
  const [prodFilterCategory, setProdFilterCategory] = useState('');
  const [prodFilterName, setProdFilterName] = useState('');
  const [prodFilterProductCode, setProdFilterProductCode] = useState('');
  const [prodFilterType, setProdFilterType] = useState<'all' | 'product' | 'service'>('all');
  const [prodFilterActive, setProdFilterActive] = useState<'all' | 'active' | 'inactive'>('all');

  // Category search state
  const [catSearchTerm, setCatSearchTerm] = useState('');

  // Pagination for products
  const [prodCurrentPage, setProdCurrentPage] = useState(1);
  const [prodPageSize, setProdPageSize] = useState(10);

  // Collapse status for hierarchical category tree
  const [collapsedCategories, setCollapsedCategories] = useState<string[]>([]);

  // Batch action modal
  const [isBatchOpen, setIsBatchOpen] = useState(false);
  const [batchSales, setBatchSales] = useState('');
  const [batchReturn, setBatchReturn] = useState('');

  // Auxiliary UI States
  const [activeDialog, setActiveDialog] = useState<string | null>(null); // 'product' | 'category'
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Helper: Next code generator
  const getNextCode = () => {
    if (sellers.length === 0) return '۰۰۰۰۱';
    const codes = sellers.map(s => {
      // Parse Persian/Arabic/English numbers
      const englishDigits = s.code.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d).toString());
      return parseInt(englishDigits, 10) || 0;
    });
    const max = Math.max(...codes, 0);
    const nextVal = max + 1;
    // Format to Persian 5-digit string
    const formattedEng = `00000${nextVal}`.slice(-5);
    return formattedEng.replace(/[0-9]/g, d => '۰۰۱۲۳۴۵۶۷۸۹'[parseInt(d, 10)]);
  };

  // Sync auto code generator
  useEffect(() => {
    if (isAutoCode && viewMode === 'form' && !editingSeller) {
      setCode(getNextCode());
    }
  }, [isAutoCode, viewMode, editingSeller, sellers]);

  // Sync edit states when dialog opens
  useEffect(() => {
    if (activeDialog === 'product') {
      const initial: Record<string, { sales: string; return: string }> = {};
      items.forEach(item => {
        const found = productCommissions.find(p => p.itemId === item.id);
        initial[item.id] = {
          sales: found && found.salesPercent !== 0 ? found.salesPercent.toString() : '',
          return: found && found.returnPercent !== 0 ? found.returnPercent.toString() : ''
        };
      });
      setEditedProdPercents(initial);
      setSelectedProdIds([]);
      setProdCurrentPage(1);
    } else if (activeDialog === 'category') {
      const initial: Record<string, { sales: string; return: string }> = {};
      SYSTEM_CATEGORIES.forEach(cat => {
        const found = categoryCommissions.find(c => c.categoryId === cat.id);
        initial[cat.id] = {
          sales: found && found.salesPercent !== 0 ? found.salesPercent.toString() : '',
          return: found && found.returnPercent !== 0 ? found.returnPercent.toString() : ''
        };
      });
      setEditedCatPercents(initial);
      setSelectedCatIds([]);
    }
  }, [activeDialog]);

  // Save product edits back to state
  const saveProductCommissions = () => {
    const updated: { itemId: string; salesPercent: number; returnPercent: number; }[] = [];
    Object.keys(editedProdPercents).forEach(itemId => {
      const val = editedProdPercents[itemId];
      if (!val) return;
      const sales = val.sales === '' ? 0 : parseFloat(val.sales);
      const ret = val.return === '' ? 0 : parseFloat(val.return);
      if (sales !== 0 || ret !== 0) {
        updated.push({
          itemId,
          salesPercent: isNaN(sales) ? 0 : sales,
          returnPercent: isNaN(ret) ? 0 : ret
        });
      }
    });
    setProductCommissions(updated);
    setActiveDialog(null);
  };

  // Save category edits back to state
  const saveCategoryCommissions = () => {
    const updated: { categoryId: string; salesPercent: number; returnPercent: number; }[] = [];
    Object.keys(editedCatPercents).forEach(catId => {
      const val = editedCatPercents[catId];
      if (!val) return;
      const sales = val.sales === '' ? 0 : parseFloat(val.sales);
      const ret = val.return === '' ? 0 : parseFloat(val.return);
      if (sales !== 0 || ret !== 0) {
        updated.push({
          categoryId: catId,
          salesPercent: isNaN(sales) ? 0 : sales,
          returnPercent: isNaN(ret) ? 0 : ret
        });
      }
    });
    setCategoryCommissions(updated);
    setActiveDialog(null);
  };

  // Product spreadsheet filter logic (computed on render)
  const filteredProducts = items.filter(item => {
    if (prodFilterCode && !item.code.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d).toString()).includes(prodFilterCode.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d).toString()))) return false;
    if (prodFilterCategory && !item.category?.toLowerCase().includes(prodFilterCategory.toLowerCase())) return false;
    if (prodFilterName && !item.name.toLowerCase().includes(prodFilterName.toLowerCase())) return false;
    if (prodFilterProductCode && item.productCode && !item.productCode.toLowerCase().includes(prodFilterProductCode.toLowerCase())) return false;
    if (prodFilterType === 'product' && item.isService) return false;
    if (prodFilterType === 'service' && !item.isService) return false;
    if (prodFilterActive === 'active' && item.isActive === false) return false;
    if (prodFilterActive === 'inactive' && item.isActive !== false) return false;
    return true;
  });

  const prodIndexOfLastItem = prodCurrentPage * prodPageSize;
  const prodIndexOfFirstItem = prodIndexOfLastItem - prodPageSize;
  const currentProdItems = filteredProducts.slice(prodIndexOfFirstItem, prodIndexOfLastItem);
  const prodTotalPages = Math.ceil(filteredProducts.length / prodPageSize) || 1;

  // Handle Form Open
  const handleOpenAddForm = () => {
    setEditingSeller(null);
    setCode(getNextCode());
    setIsAutoCode(true);
    setIsActive(true);
    setName('');
    setSalesPercent(0);
    setReturnPercent(0);
    setSalesAmount(0);
    setReturnAmount(0);
    setExcludeProductDiscount(false);
    setExcludeInvoiceAdjustments(false);
    setCommissionInInvoice(true);
    setExpenseAccount('هزینه بازاریابی و پورسانت');
    setRelatedContactId('');
    setDescription('');
    setProductCommissions([]);
    setCategoryCommissions([]);
    setViewMode('form');
  };

  // Handle Edit Form
  const handleOpenEditForm = (seller: Seller) => {
    setEditingSeller(seller);
    setCode(seller.code);
    setIsAutoCode(false);
    setIsActive(seller.isActive);
    setName(seller.name);
    setSalesPercent(seller.salesPercent);
    setReturnPercent(seller.returnPercent);
    setSalesAmount(seller.salesAmount || 0);
    setReturnAmount(seller.returnAmount || 0);
    setExcludeProductDiscount(seller.excludeProductDiscount || false);
    setExcludeInvoiceAdjustments(seller.excludeInvoiceAdjustments || false);
    setCommissionInInvoice(seller.commissionInInvoice !== false);
    setExpenseAccount(seller.expenseAccount || 'هزینه بازاریابی و پورسانت');
    setRelatedContactId(seller.relatedContactId || '');
    setDescription(seller.description || '');
    setProductCommissions(seller.productCommissions || []);
    setCategoryCommissions(seller.categoryCommissions || []);
    setViewMode('form');
  };

  // Handle Save
  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!name.trim()) return;

    const matchedContact = contacts.find(c => c.id === relatedContactId);
    const sellerData: Seller = {
      id: editingSeller ? editingSeller.id : `sel_${Date.now()}`,
      code,
      name: name.trim(),
      isActive,
      salesPercent: Number(salesPercent) || 0,
      returnPercent: Number(returnPercent) || 0,
      salesAmount: Number(salesAmount) || 0,
      returnAmount: Number(returnAmount) || 0,
      excludeProductDiscount,
      excludeInvoiceAdjustments,
      commissionInInvoice,
      expenseAccount,
      relatedContactId,
      relatedContactName: matchedContact ? matchedContact.name : '',
      description: description.trim(),
      productCommissions,
      categoryCommissions
    };

    let updatedSellers: Seller[];
    if (editingSeller) {
      updatedSellers = sellers.map(s => s.id === editingSeller.id ? sellerData : s);
    } else {
      updatedSellers = [...sellers, sellerData];
    }

    setSellers(updatedSellers);
    localStorage.setItem('hesabfa_sellers', JSON.stringify(updatedSellers));
    
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      setViewMode('list');
    }, 1000);
  };

  // Handle Delete Single
  const handleDeleteSeller = (id: string) => {
    if (window.confirm('آیا از حذف این فروشنده اطمینان دارید؟')) {
      const updated = sellers.filter(s => s.id !== id);
      setSellers(updated);
      localStorage.setItem('hesabfa_sellers', JSON.stringify(updated));
      setSelectedSellerIds(selectedSellerIds.filter(x => x !== id));
    }
  };

  // Handle Batch Delete
  const handleBatchDelete = () => {
    if (selectedSellerIds.length === 0) return;
    if (window.confirm(`آیا از حذف ${selectedSellerIds.length} فروشنده انتخاب شده اطمینان دارید؟`)) {
      const updated = sellers.filter(s => !selectedSellerIds.includes(s.id));
      setSellers(updated);
      localStorage.setItem('hesabfa_sellers', JSON.stringify(updated));
      setSelectedSellerIds([]);
    }
  };

  // Toggle selection
  const toggleSelectSeller = (id: string) => {
    if (selectedSellerIds.includes(id)) {
      setSelectedSellerIds(selectedSellerIds.filter(x => x !== id));
    } else {
      setSelectedSellerIds([...selectedSellerIds, id]);
    }
  };

  const toggleSelectAll = () => {
    if (selectedSellerIds.length === filteredSellers.length) {
      setSelectedSellerIds([]);
    } else {
      setSelectedSellerIds(filteredSellers.map(s => s.id));
    }
  };

  // Filtering Logic
  const filteredSellers = sellers.filter(seller => {
    // Code filter
    if (filterCode && !seller.code.includes(filterCode)) return false;
    // Name filter
    if (filterName && !seller.name.toLowerCase().includes(filterName.toLowerCase())) return false;
    // Expense filter
    if (filterExpense && !seller.expenseAccount.toLowerCase().includes(filterExpense.toLowerCase())) return false;
    // Contact filter
    if (filterContact && !seller.relatedContactName.toLowerCase().includes(filterContact.toLowerCase())) return false;
    // Active status filter
    if (filterActive === 'active' && !seller.isActive) return false;
    if (filterActive === 'inactive' && seller.isActive) return false;
    // Commission in invoice status filter
    if (filterCommission === 'yes' && !seller.commissionInInvoice) return false;
    if (filterCommission === 'no' && seller.commissionInInvoice) return false;

    return true;
  });

  // Pagination Logic
  const indexOfLastItem = currentPage * pageSize;
  const indexOfFirstItem = indexOfLastItem - pageSize;
  const currentSellers = filteredSellers.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredSellers.length / pageSize) || 1;

  // Filter contacts who can be linked (employees or general)
  const employeeContacts = contacts.filter(c => c.type === 'employee' || c.category === 'کارمندان' || c.type === 'both');

  return (
    <div className="flex flex-col h-full bg-slate-50/50" dir="rtl" id="sellers-root">
      
      {/* ==================== 1. LIST VIEW ==================== */}
      {viewMode === 'list' && (
        <>
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
                <Briefcase size={22} />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-800">فروشندگان و بازاریاب‌ها</h1>
                <p className="text-xs text-slate-500 mt-0.5">ثبت درصد کمیسیون، پورسانت فروش و حساب تسویه پورسانت</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Batch Actions */}
              {selectedSellerIds.length > 0 && (
                <button
                  onClick={handleBatchDelete}
                  id="btn-batch-delete-sellers"
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-50 border border-rose-200 text-rose-600 rounded-xl hover:bg-rose-100 transition text-sm font-semibold"
                >
                  <Trash2 size={16} />
                  <span>حذف ({selectedSellerIds.length})</span>
                </button>
              )}

              {/* Edit Selected Button (Only visible if exactly 1 is selected) */}
              {selectedSellerIds.length === 1 && (
                <button
                  onClick={() => {
                    const sel = sellers.find(s => s.id === selectedSellerIds[0]);
                    if (sel) handleOpenEditForm(sel);
                  }}
                  id="btn-edit-selected-seller"
                  className="flex items-center gap-1.5 px-3.5 py-2 border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 rounded-xl transition text-sm font-semibold"
                >
                  <Edit2 size={16} />
                  <span>ویرایش</span>
                </button>
              )}

              {/* Add Seller Button */}
              <button 
                onClick={handleOpenAddForm}
                id="btn-add-seller"
                className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition shadow-md shadow-indigo-600/10 hover:shadow-lg hover:shadow-indigo-600/20 text-sm"
              >
                <Plus size={16} />
                <span>تعریف فروشنده جدید</span>
              </button>

              {/* Back button */}
              {onBack && (
                <button 
                  onClick={onBack}
                  id="btn-back-sellers"
                  className="flex items-center justify-center p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition"
                  title="بازگشت"
                >
                  <ArrowLeft size={20} />
                </button>
              )}
            </div>
          </div>

          {/* Table list */}
          <div className="flex-1 p-6 space-y-4 overflow-y-auto">
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm" id="sellers-table-container">
              <table className="w-full text-right border-collapse">
                <thead>
                  {/* Column titles */}
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-bold select-none">
                    <th className="py-3 px-4 text-center w-12">
                      <input
                        type="checkbox"
                        checked={selectedSellerIds.length > 0 && selectedSellerIds.length === filteredSellers.length}
                        onChange={toggleSelectAll}
                        className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                      />
                    </th>
                    <th className="py-3 px-4 text-center w-12">#</th>
                    <th className="py-3 px-4 w-24 text-center">کد</th>
                    <th className="py-3 px-4">نام</th>
                    <th className="py-3 px-4 text-center w-36">ثبت پورسانت در فاکتور</th>
                    <th className="py-3 px-4 text-center w-28">درصد فروش</th>
                    <th className="py-3 px-4 text-center w-28">درصد برگشت</th>
                    <th className="py-3 px-4">حساب هزینه</th>
                    <th className="py-3 px-4">شخص مرتبط</th>
                    <th className="py-3 px-4 text-center w-20">فعال</th>
                  </tr>

                  {/* Spreadsheet style interactive filters */}
                  <tr className="bg-slate-100/50 border-b border-slate-200 select-none">
                    <td className="py-2 px-4"></td>
                    <td className="py-2 px-4"></td>
                    {/* Code filter */}
                    <td className="py-1 px-3 text-center">
                      <div className="flex items-center bg-white border border-slate-200 rounded-lg px-2 py-1 max-w-[90px] mx-auto">
                        <Search size={12} className="text-slate-400 ml-1.5 shrink-0" />
                        <input
                          type="text"
                          value={filterCode}
                          onChange={(e) => setFilterCode(e.target.value)}
                          className="w-full bg-transparent text-xs text-slate-700 outline-none border-none p-0"
                          placeholder="کد"
                        />
                      </div>
                    </td>
                    {/* Name filter */}
                    <td className="py-1 px-3">
                      <div className="flex items-center bg-white border border-slate-200 rounded-lg px-2 py-1">
                        <Search size={12} className="text-slate-400 ml-1.5 shrink-0" />
                        <input
                          type="text"
                          value={filterName}
                          onChange={(e) => setFilterName(e.target.value)}
                          className="w-full bg-transparent text-xs text-slate-700 outline-none border-none p-0"
                          placeholder="جستجوی نام..."
                        />
                      </div>
                    </td>
                    {/* Register in invoice status */}
                    <td className="py-1 px-3">
                      <select
                        value={filterCommission}
                        onChange={(e) => setFilterCommission(e.target.value as any)}
                        className="w-full bg-white border border-slate-200 rounded-lg py-1 px-2 text-xs text-slate-600 outline-none"
                      >
                        <option value="all">(همه)</option>
                        <option value="yes">بله</option>
                        <option value="no">خیر</option>
                      </select>
                    </td>
                    {/* Percent filters are static */}
                    <td className="py-2 px-4"></td>
                    <td className="py-2 px-4"></td>
                    {/* Expense Account Filter */}
                    <td className="py-1 px-3">
                      <div className="flex items-center bg-white border border-slate-200 rounded-lg px-2 py-1">
                        <Search size={12} className="text-slate-400 ml-1.5 shrink-0" />
                        <input
                          type="text"
                          value={filterExpense}
                          onChange={(e) => setFilterExpense(e.target.value)}
                          className="w-full bg-transparent text-xs text-slate-700 outline-none border-none p-0"
                          placeholder="جستجوی حساب هزینه..."
                        />
                      </div>
                    </td>
                    {/* Contact Filter */}
                    <td className="py-1 px-3">
                      <div className="flex items-center bg-white border border-slate-200 rounded-lg px-2 py-1">
                        <Search size={12} className="text-slate-400 ml-1.5 shrink-0" />
                        <input
                          type="text"
                          value={filterContact}
                          onChange={(e) => setFilterContact(e.target.value)}
                          className="w-full bg-transparent text-xs text-slate-700 outline-none border-none p-0"
                          placeholder="جستجوی شخص..."
                        />
                      </div>
                    </td>
                    {/* Active filter */}
                    <td className="py-1 px-3 text-center">
                      <select
                        value={filterActive}
                        onChange={(e) => setFilterActive(e.target.value as any)}
                        className="w-full bg-white border border-slate-200 rounded-lg py-1 px-1.5 text-xs text-slate-600 outline-none"
                      >
                        <option value="all">(همه)</option>
                        <option value="active">فعال</option>
                        <option value="inactive">غیرفعال</option>
                      </select>
                    </td>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100 text-slate-700 text-sm">
                  {currentSellers.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="py-12 text-center text-slate-400 text-sm">
                        هیچ فروشنده‌ای منطبق با فیلترها یافت نشد.
                      </td>
                    </tr>
                  ) : (
                    currentSellers.map((seller, index) => (
                      <tr 
                        key={seller.id} 
                        onClick={() => handleOpenEditForm(seller)}
                        className="hover:bg-slate-50/70 cursor-pointer group transition duration-150"
                      >
                        {/* Checkbox */}
                        <td 
                          className="py-3 px-4 text-center w-12"
                          onClick={(e) => {
                            e.stopPropagation(); // Don't trigger edit form
                            toggleSelectSeller(seller.id);
                          }}
                        >
                          <input
                            type="checkbox"
                            checked={selectedSellerIds.includes(seller.id)}
                            onChange={() => {}} // Controlled by onClick
                            className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                          />
                        </td>

                        {/* Index */}
                        <td className="py-3 px-4 text-center text-slate-400 font-medium select-none w-12">
                          {indexOfFirstItem + index + 1}
                        </td>

                        {/* Code */}
                        <td className="py-3 px-4 text-center font-mono text-xs text-slate-500 w-24">
                          {seller.code}
                        </td>

                        {/* Name */}
                        <td className="py-3 px-4 font-bold text-slate-800">
                          {seller.name}
                        </td>

                        {/* Register Commission */}
                        <td className="py-3 px-4 text-center w-36">
                          <span className={`inline-flex items-center justify-center w-6 h-6 rounded-lg ${seller.commissionInInvoice ? 'bg-indigo-50 text-indigo-600' : 'bg-slate-100 text-slate-400'}`}>
                            {seller.commissionInInvoice ? '✓' : ''}
                          </span>
                        </td>

                        {/* Sales Percent */}
                        <td className="py-3 px-4 text-center font-bold text-slate-700 w-28">
                          {seller.salesPercent}٪
                        </td>

                        {/* Return Percent */}
                        <td className="py-3 px-4 text-center text-slate-500 w-28">
                          {seller.returnPercent}٪
                        </td>

                        {/* Expense Account */}
                        <td className="py-3 px-4 text-slate-600 text-xs">
                          {seller.expenseAccount}
                        </td>

                        {/* Related Person */}
                        <td className="py-3 px-4 text-slate-700 text-xs font-semibold">
                          {seller.relatedContactName || '---'}
                        </td>

                        {/* Active checkbox */}
                        <td className="py-3 px-4 text-center w-20">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${seller.isActive ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                            {seller.isActive ? '✓' : '✖'}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>

              {/* Pagination footer */}
              <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-xs">
                <div className="flex items-center gap-4">
                  <span>صفحه {currentPage} از {totalPages} ({filteredSellers.length} آیتم)</span>
                  
                  <div className="flex items-center gap-1.5">
                    <span>اندازه صفحه:</span>
                    <select
                      value={pageSize}
                      onChange={(e) => {
                        setPageSize(Number(e.target.value));
                        setCurrentPage(1);
                      }}
                      className="bg-white border border-slate-200 rounded-lg px-2 py-0.5 outline-none text-slate-600 cursor-pointer"
                    >
                      {[5, 10, 15, 20, 30, 50, 100].map(size => (
                        <option key={size} value={size}>{size}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    className="p-1.5 border border-slate-200 rounded-lg hover:bg-slate-100 bg-white transition disabled:opacity-40 disabled:hover:bg-white"
                  >
                    <ChevronRight size={14} />
                  </button>
                  <button
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                    className="p-1.5 border border-slate-200 rounded-lg hover:bg-slate-100 bg-white transition disabled:opacity-40 disabled:hover:bg-white"
                  >
                    <ChevronLeft size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}


      {/* ==================== 2. DETAILS / FORM VIEW ==================== */}
      {viewMode === 'form' && (
        <form onSubmit={handleSave} className="flex flex-col h-full bg-slate-50/50" id="seller-form">
          {/* Form Header */}
          <div className="flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
                <Sliders size={22} />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-800">
                  {editingSeller ? 'مشخصات فروشنده' : 'تعریف مشخصات فروشنده'}
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">ثبت شناسه‌ها، حساب‌های بانکی و نرخ پورسانت‌های نقدی و درصدی</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Add New Button */}
              {!editingSeller && (
                <button
                  type="button"
                  onClick={handleOpenAddForm}
                  className="p-2 border border-slate-200 hover:bg-slate-50 bg-white rounded-xl text-slate-600 transition"
                  title="سند جدید"
                >
                  <Plus size={18} />
                </button>
              )}

              {/* Save Button */}
              <button 
                type="submit"
                id="btn-save-seller-form"
                disabled={!name.trim()}
                className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl font-bold transition shadow-sm text-sm"
              >
                {saveSuccess ? <Check size={16} /> : <Save size={16} />}
                <span>{saveSuccess ? 'ذخیره شد' : 'ذخیره مشخصات'}</span>
              </button>

              {/* Cancel Button */}
              <button 
                type="button"
                onClick={() => setViewMode('list')}
                className="flex items-center justify-center p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition"
                title="انصراف"
              >
                <ArrowLeft size={20} />
              </button>
            </div>
          </div>

          {/* Form Body - Split layout */}
          <div className="flex-1 p-6 overflow-y-auto">
            <div className="max-w-5xl mx-auto bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row gap-8">
              
              {/* Left Side: Form Fields */}
              <div className="flex-1 space-y-6">
                
                {/* 1. Code & State */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1.5">کد فروشنده</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        disabled={isAutoCode}
                        value={code}
                        onChange={(e) => setCode(e.target.value)}
                        className="bg-slate-50 disabled:bg-slate-100/50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2.5 text-sm text-slate-800 font-mono outline-none transition w-full"
                      />
                      <label className="flex items-center gap-1 text-xs text-slate-600 shrink-0 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={isAutoCode}
                          onChange={(e) => setIsAutoCode(e.target.checked)}
                          className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                        />
                        <span>اتوماتیک</span>
                      </label>
                    </div>
                  </div>

                  <div className="flex items-center md:pt-6">
                    <label className="flex items-center gap-2 text-sm text-slate-700 font-semibold cursor-pointer">
                      <input
                        type="checkbox"
                        checked={isActive}
                        onChange={(e) => setIsActive(e.target.checked)}
                        className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4.5 h-4.5 cursor-pointer"
                      />
                      <span>این فروشنده فعال باشد</span>
                    </label>
                  </div>
                </div>

                {/* 2. Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">نام فروشنده / بازاریاب *</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: محسن پور یا خانم حسینیان"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-sm text-slate-800 font-bold outline-none transition"
                  />
                </div>

                {/* 3. Comission Percentage Rates */}
                <div className="bg-slate-50/50 border border-slate-200 rounded-xl p-4 space-y-4">
                  <span className="text-xs font-bold text-slate-700 flex items-center gap-2">
                    <TrendingUp size={14} className="text-indigo-600" />
                    <span>نرخ درصدی پورسانت</span>
                  </span>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-slate-500 mb-1">درصد فروش</label>
                      <div className="flex items-center bg-slate-50 border border-slate-200 focus-within:border-indigo-500 rounded-xl px-3 py-2 transition">
                        <input
                          type="number"
                          step="any"
                          value={salesPercent === 0 ? '' : salesPercent}
                          onChange={(e) => setSalesPercent(e.target.value === '' ? 0 : Number(e.target.value))}
                          className="w-full bg-transparent text-sm text-slate-800 font-bold outline-none border-none p-0"
                          placeholder="۰"
                        />
                        <span className="text-slate-400 font-bold mr-1">%</span>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs text-slate-500 mb-1">درصد برگشت از فروش</label>
                      <div className="flex items-center bg-slate-50 border border-slate-200 focus-within:border-indigo-500 rounded-xl px-3 py-2 transition">
                        <input
                          type="number"
                          step="any"
                          value={returnPercent === 0 ? '' : returnPercent}
                          onChange={(e) => setReturnPercent(e.target.value === '' ? 0 : Number(e.target.value))}
                          className="w-full bg-transparent text-sm text-slate-800 font-bold outline-none border-none p-0"
                          placeholder="۰"
                        />
                        <span className="text-slate-400 font-bold mr-1">%</span>
                      </div>
                    </div>
                  </div>

                  {/* Helper Links precisely from the screenshot */}
                  <div className="flex items-center gap-4 text-xs font-bold pt-1 text-indigo-600 select-none">
                    <button 
                      type="button" 
                      onClick={() => setActiveDialog('product')}
                      className="hover:underline transition cursor-pointer"
                    >
                      درصد به تفکیک کالا
                    </button>
                    <span className="text-slate-300">|</span>
                    <button 
                      type="button"
                      onClick={() => setActiveDialog('category')}
                      className="hover:underline transition cursor-pointer"
                    >
                      درصد به تفکیک دسته‌بندی
                    </button>
                  </div>
                </div>

                {/* 4. flat amount commissions */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">مبلغ فروش ثابت</label>
                    <div className="flex items-center bg-slate-50 border border-slate-200 focus-within:border-indigo-500 rounded-xl px-3 py-2 transition">
                      <input
                        type="number"
                        value={salesAmount === 0 ? '' : salesAmount}
                        onChange={(e) => setSalesAmount(Number(e.target.value))}
                        className="w-full bg-transparent text-sm text-slate-800 font-bold outline-none border-none p-0"
                        placeholder="۰"
                      />
                      <span className="text-slate-400 text-xs shrink-0 mr-1.5">ریال</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-500 mb-1">مبلغ برگشت ثابت</label>
                    <div className="flex items-center bg-slate-50 border border-slate-200 focus-within:border-indigo-500 rounded-xl px-3 py-2 transition">
                      <input
                        type="number"
                        value={returnAmount === 0 ? '' : returnAmount}
                        onChange={(e) => setReturnAmount(Number(e.target.value))}
                        className="w-full bg-transparent text-sm text-slate-800 font-bold outline-none border-none p-0"
                        placeholder="۰"
                      />
                      <span className="text-slate-400 text-xs shrink-0 mr-1.5">ریال</span>
                    </div>
                  </div>
                </div>

                {/* 5. Dropdowns: Related Person & Expense Account */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1.5">شخص مرتبط در سامانه (اشخاص)</label>
                    <select
                      value={relatedContactId}
                      onChange={(e) => setRelatedContactId(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2.5 text-sm text-slate-700 outline-none transition"
                    >
                      <option value="">-- انتخاب شخص مرتبط --</option>
                      {employeeContacts.map(c => (
                        <option key={c.id} value={c.id}>
                          {c.code ? `${c.code} - ` : ''}{c.name} ({c.category || 'کارمندان'})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1.5">معین حساب هزینه پورسانت</label>
                    <select
                      value={expenseAccount}
                      onChange={(e) => setExpenseAccount(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2.5 text-sm text-slate-700 outline-none transition"
                    >
                      <option value="هزینه بازاریابی و پورسانت">هزینه بازاریابی و پورسانت</option>
                      <option value="هزینه توزیع و فروش">هزینه توزیع و فروش</option>
                      <option value="هزینه حقوق و دستمزد بازاریابان">هزینه حقوق و دستمزد بازاریابان</option>
                    </select>
                  </div>
                </div>

                {/* 6. Settings and switches precisely from the screenshot */}
                <div className="bg-slate-50/50 border border-slate-200 rounded-xl p-4 space-y-3.5">
                  <span className="text-xs font-bold text-slate-700 flex items-center gap-2">
                    <Sliders size={14} className="text-indigo-600" />
                    <span>تنظیمات محاسباتی اسناد</span>
                  </span>

                  <div className="space-y-2">
                    <label className="flex items-center gap-2.5 text-xs text-slate-700 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={excludeProductDiscount}
                        onChange={(e) => setExcludeProductDiscount(e.target.checked)}
                        className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                      />
                      <span>عدم محاسبه تخفیف کالا در پورسانت (پورسانت روی مبلغ ناخالص کالا محاسبه شود)</span>
                    </label>

                    <label className="flex items-center gap-2.5 text-xs text-slate-700 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={excludeInvoiceAdjustments}
                        onChange={(e) => setExcludeInvoiceAdjustments(e.target.checked)}
                        className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                      />
                      <span>عدم محاسبه اضافات و کسورات فاکتور (هزینه حمل، نصب و کسورات کسر نشوند)</span>
                    </label>

                    <label className="flex items-center gap-2.5 text-xs text-slate-700 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={commissionInInvoice}
                        onChange={(e) => setCommissionInInvoice(e.target.checked)}
                        className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                      />
                      <span>ثبت خودکار سند معین پورسانت همزمان با فاکتور فروش (ثبت پورسانت در سند فاکتور)</span>
                    </label>
                  </div>
                </div>

                {/* 7. Description */}
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">توضیحات</label>
                  <textarea
                    rows={3}
                    placeholder="توضیحات تکمیلی یا شرایط توافق بازاریابی را اینجا بنویسید..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-sm text-slate-800 outline-none transition resize-none"
                  />
                </div>

              </div>

              {/* Right Side: Professional Avatar circle from screenshot */}
              <div className="w-full md:w-72 flex flex-col items-center justify-start py-6 border-t md:border-t-0 md:border-r border-slate-100 md:pr-8">
                <div className="relative group">
                  {/* Golden circular avatar frame exactly like screenshot */}
                  <div className="w-48 h-48 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-400 p-1 flex items-center justify-center shadow-md">
                    <div className="w-full h-full rounded-full bg-slate-100 flex items-center justify-center overflow-hidden border-4 border-white relative">
                      
                      {/* Placeholder vector icon resembling the portrait bust */}
                      <div className="w-full h-full bg-blue-100 flex flex-col items-center justify-end pt-6">
                        <div className="w-24 h-24 bg-slate-700 rounded-full mb-1 border-2 border-white shadow-sm shrink-0"></div>
                        <div className="w-36 h-16 bg-blue-600 rounded-t-full border-t-2 border-white shadow-inner shrink-0"></div>
                      </div>

                      {/* Coin badge overlay */}
                      <div className="absolute bottom-2 left-2 bg-gradient-to-tr from-amber-600 to-amber-500 border-2 border-white text-white p-2.5 rounded-full shadow-md">
                        <Coins size={20} />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-center mt-5 space-y-1">
                  <h3 className="font-bold text-slate-800 text-base">{name || 'مشخصات بازاریاب'}</h3>
                  <p className="text-xs text-slate-400">کد اختصاصی: {code || '-----'}</p>
                </div>

                {/* Auxiliary helpful guide */}
                <div className="mt-8 bg-indigo-50/40 border border-indigo-100 rounded-xl p-4 text-xs text-indigo-700 leading-relaxed text-right w-full">
                  <span className="font-bold flex items-center gap-1.5 mb-1 text-indigo-800">
                    <Activity size={13} />
                    نحوه اثر پورسانت
                  </span>
                  با انتساب این فروشنده در فاکتورهای فروش، پورسانت مربوطه به صورت خودکار محاسبه شده و حساب اشخاص (بازاریاب) بستانکار می‌گردد.
                </div>
              </div>

            </div>
          </div>
        </form>
      )}

      {/* Auxiliary Dialogs for "درصد به تفکیک کالا / دسته بندی" */}
      {activeDialog === 'product' && (
        <div className="fixed inset-0 bg-slate-100 z-50 flex flex-col overflow-hidden" id="product-commissions-view" dir="rtl">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200 shadow-sm">
            <div className="flex items-center gap-3">
              <button 
                type="button"
                onClick={saveProductCommissions}
                className="p-2 hover:bg-slate-100 rounded-xl text-slate-700 transition"
                title="بازگشت و ذخیره"
              >
                <ArrowRight size={22} className="text-slate-600" />
              </button>
              <div>
                <h1 className="text-lg font-bold text-slate-800">درصد به تفکیک کالا</h1>
                <p className="text-xs text-slate-500 mt-0.5">تعیین درصد پورسانت فروش و برگشت اختصاصی برای هر کالا</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {selectedProdIds.length > 0 && (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedProdIds.length === 0) return;
                      if (window.confirm('آیا مطمئن هستید که می‌خواهید درصد‌های ردیف‌های انتخاب شده را بازنشانی کنید؟')) {
                        setEditedProdPercents(prev => {
                          const copy = { ...prev };
                          selectedProdIds.forEach(id => {
                            copy[id] = { sales: '', return: '' };
                          });
                          return copy;
                        });
                        setSelectedProdIds([]);
                      }
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 bg-rose-50 border border-rose-200 text-rose-600 rounded-xl hover:bg-rose-100 transition text-xs font-semibold"
                    title="حذف درصدهای انتخاب شده"
                  >
                    <Trash2 size={15} />
                    <span>حذف ({selectedProdIds.length})</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsBatchOpen(true)}
                    className="flex items-center gap-1.5 px-3 py-2 bg-indigo-50 border border-indigo-200 text-indigo-600 rounded-xl hover:bg-indigo-100 transition text-xs font-semibold"
                    title="اعمال درصد گروهی"
                  >
                    <Percent size={15} />
                    <span>اعمال درصد گروهی</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Spreadsheet Table Container */}
          <div className="flex-1 p-6 overflow-auto">
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
              <table className="w-full text-right border-collapse">
                <thead>
                  {/* Column Titles */}
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-bold select-none">
                    <th className="py-3 px-4 text-center w-12">
                      <input
                        type="checkbox"
                        checked={filteredProducts.length > 0 && selectedProdIds.length === filteredProducts.length}
                        onChange={() => {
                          if (selectedProdIds.length === filteredProducts.length) {
                            setSelectedProdIds([]);
                          } else {
                            setSelectedProdIds(filteredProducts.map(p => p.id));
                          }
                        }}
                        className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                      />
                    </th>
                    <th className="py-3 px-4 text-center w-12">#</th>
                    <th className="py-3 px-4 text-center w-24">کد</th>
                    <th className="py-3 px-4">دسته بندی</th>
                    <th className="py-3 px-4">نام</th>
                    <th className="py-3 px-4">کد کالا</th>
                    <th className="py-3 px-4 text-center w-32 bg-indigo-50/20">درصد فروش</th>
                    <th className="py-3 px-4 text-center w-36 bg-rose-50/10">درصد برگشت از فروش</th>
                    <th className="py-3 px-4 text-left">قیمت فروش</th>
                    <th className="py-3 px-4 text-left">قیمت خرید</th>
                    <th className="py-3 px-4 text-center w-24">نوع کالا</th>
                    <th className="py-3 px-4 text-center w-16">فعال</th>
                  </tr>

                  {/* Spreadsheet Interactive Filters */}
                  <tr className="bg-slate-100/50 border-b border-slate-200 select-none">
                    <td className="py-2 px-4"></td>
                    <td className="py-2 px-4"></td>
                    {/* Code Filter */}
                    <td className="py-1 px-3 text-center">
                      <div className="flex items-center bg-white border border-slate-200 rounded-lg px-2 py-1 max-w-[90px] mx-auto">
                        <Search size={12} className="text-slate-400 ml-1 shrink-0" />
                        <input
                          type="text"
                          value={prodFilterCode}
                          onChange={(e) => { setProdFilterCode(e.target.value); setProdCurrentPage(1); }}
                          className="w-full bg-transparent text-xs text-slate-700 outline-none border-none p-0"
                          placeholder="کد"
                        />
                      </div>
                    </td>
                    {/* Category Filter */}
                    <td className="py-1 px-3">
                      <div className="flex items-center bg-white border border-slate-200 rounded-lg px-2 py-1">
                        <Search size={12} className="text-slate-400 ml-1 shrink-0" />
                        <input
                          type="text"
                          value={prodFilterCategory}
                          onChange={(e) => { setProdFilterCategory(e.target.value); setProdCurrentPage(1); }}
                          className="w-full bg-transparent text-xs text-slate-700 outline-none border-none p-0"
                          placeholder="جستجوی دسته‌بندی..."
                        />
                      </div>
                    </td>
                    {/* Name Filter */}
                    <td className="py-1 px-3">
                      <div className="flex items-center bg-white border border-slate-200 rounded-lg px-2 py-1">
                        <Search size={12} className="text-slate-400 ml-1 shrink-0" />
                        <input
                          type="text"
                          value={prodFilterName}
                          onChange={(e) => { setProdFilterName(e.target.value); setProdCurrentPage(1); }}
                          className="w-full bg-transparent text-xs text-slate-700 outline-none border-none p-0"
                          placeholder="جستجوی نام..."
                        />
                      </div>
                    </td>
                    {/* Product Code Filter */}
                    <td className="py-1 px-3">
                      <div className="flex items-center bg-white border border-slate-200 rounded-lg px-2 py-1">
                        <Search size={12} className="text-slate-400 ml-1 shrink-0" />
                        <input
                          type="text"
                          value={prodFilterProductCode}
                          onChange={(e) => { setProdFilterProductCode(e.target.value); setProdCurrentPage(1); }}
                          className="w-full bg-transparent text-xs text-slate-700 outline-none border-none p-0"
                          placeholder="کد کالا..."
                        />
                      </div>
                    </td>
                    <td className="py-2 px-4 bg-indigo-50/10"></td>
                    <td className="py-2 px-4 bg-rose-50/5"></td>
                    <td className="py-2 px-4"></td>
                    <td className="py-2 px-4"></td>
                    {/* Type Filter */}
                    <td className="py-1 px-3 text-center">
                      <select
                        value={prodFilterType}
                        onChange={(e) => { setProdFilterType(e.target.value as any); setProdCurrentPage(1); }}
                        className="w-full bg-white border border-slate-200 rounded-lg py-1 px-1 text-xs text-slate-600 outline-none"
                      >
                        <option value="all">(همه)</option>
                        <option value="product">کالا</option>
                        <option value="service">خدمات</option>
                      </select>
                    </td>
                    {/* Active Filter */}
                    <td className="py-1 px-3 text-center">
                      <select
                        value={prodFilterActive}
                        onChange={(e) => { setProdFilterActive(e.target.value as any); setProdCurrentPage(1); }}
                        className="w-full bg-white border border-slate-200 rounded-lg py-1 px-0.5 text-xs text-slate-600 outline-none"
                      >
                        <option value="all">(همه)</option>
                        <option value="active">فعال</option>
                        <option value="inactive">غیرفعال</option>
                      </select>
                    </td>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100 text-slate-700 text-sm">
                  {currentProdItems.length === 0 ? (
                    <tr>
                      <td colSpan={12} className="py-12 text-center text-slate-400 text-sm">
                        هیچ کالایی منطبق با فیلترها یافت نشد.
                      </td>
                    </tr>
                  ) : (
                    currentProdItems.map((item, index) => {
                      const isSelected = selectedProdIds.includes(item.id);
                      return (
                        <tr 
                          key={item.id}
                          className={`hover:bg-slate-50 transition duration-150 ${isSelected ? 'bg-indigo-50/30' : ''}`}
                        >
                          {/* Checkbox */}
                          <td 
                            className="py-3 px-4 text-center w-12"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedProdIds(prev => prev.includes(item.id) ? prev.filter(x => x !== item.id) : [...prev, item.id]);
                            }}
                          >
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => {}}
                              className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                            />
                          </td>

                          {/* Index */}
                          <td className="py-3 px-4 text-center text-slate-400 font-medium w-12">
                            {prodIndexOfFirstItem + index + 1}
                          </td>

                          {/* Code */}
                          <td className="py-3 px-4 text-center font-mono text-xs text-slate-500 w-24">
                            {item.code}
                          </td>

                          {/* Category */}
                          <td className="py-3 px-4 text-slate-600 font-medium">
                            {item.category || '---'}
                          </td>

                          {/* Name */}
                          <td className="py-3 px-4 font-bold text-slate-800">
                            {item.name}
                          </td>

                          {/* Product Code */}
                          <td className="py-3 px-4 font-mono text-xs text-slate-500">
                            {item.productCode || '---'}
                          </td>

                          {/* Sales Percent input */}
                          <td className="py-2 px-3 text-center bg-indigo-50/10 w-32">
                            <div className="flex items-center justify-center bg-white border border-slate-200 focus-within:border-indigo-500 rounded-lg px-2 py-0.5 max-w-[85px] mx-auto shadow-sm">
                              <input
                                type="text"
                                value={editedProdPercents[item.id]?.sales ?? ''}
                                onChange={(e) => {
                                  const text = e.target.value.replace(/[^0-9.]/g, '');
                                  setEditedProdPercents(prev => ({
                                    ...prev,
                                    [item.id]: { ...prev[item.id], sales: text }
                                  }));
                                }}
                                placeholder="---"
                                className="w-full bg-transparent text-center text-xs font-bold text-slate-800 outline-none border-none p-0"
                              />
                              <span className="text-slate-400 text-[10px] mr-0.5">%</span>
                            </div>
                          </td>

                          {/* Return Percent input */}
                          <td className="py-2 px-3 text-center bg-rose-50/5 w-36">
                            <div className="flex items-center justify-center bg-white border border-slate-200 focus-within:border-indigo-500 rounded-lg px-2 py-0.5 max-w-[85px] mx-auto shadow-sm">
                              <input
                                type="text"
                                value={editedProdPercents[item.id]?.return ?? ''}
                                onChange={(e) => {
                                  const text = e.target.value.replace(/[^0-9.]/g, '');
                                  setEditedProdPercents(prev => ({
                                    ...prev,
                                    [item.id]: { ...prev[item.id], return: text }
                                  }));
                                }}
                                placeholder="---"
                                className="w-full bg-transparent text-center text-xs font-bold text-slate-800 outline-none border-none p-0"
                              />
                              <span className="text-slate-400 text-[10px] mr-0.5">%</span>
                            </div>
                          </td>

                          {/* Sales Price */}
                          <td className="py-3 px-4 text-left font-mono text-xs text-slate-700 font-bold">
                            {item.salePrice.toLocaleString('fa-IR')} ریال
                          </td>

                          {/* Purchase Price */}
                          <td className="py-3 px-4 text-left font-mono text-xs text-slate-500">
                            {item.purchasePrice.toLocaleString('fa-IR')} ریال
                          </td>

                          {/* Type */}
                          <td className="py-3 px-4 text-center text-slate-600 font-medium text-xs">
                            <span className={`inline-flex px-2 py-0.5 rounded-md ${item.isService ? 'bg-amber-50 text-amber-600' : 'bg-blue-50 text-blue-600'}`}>
                              {item.isService ? 'خدمات' : 'کالا'}
                            </span>
                          </td>

                          {/* Active */}
                          <td className="py-3 px-4 text-center w-16">
                            <span className="text-emerald-600 font-bold">✓</span>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>

              {/* Pagination Footer */}
              <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-xs select-none">
                <div className="flex items-center gap-4">
                  <span>صفحه {prodCurrentPage} از {prodTotalPages} ({filteredProducts.length} کالا)</span>
                  
                  <div className="flex items-center gap-1.5">
                    <span>اندازه صفحه:</span>
                    <select
                      value={prodPageSize}
                      onChange={(e) => {
                        setProdPageSize(Number(e.target.value));
                        setProdCurrentPage(1);
                      }}
                      className="bg-white border border-slate-200 rounded-lg px-2 py-0.5 outline-none text-slate-600 cursor-pointer"
                    >
                      {[5, 10, 15, 20, 30, 50, 100].map(size => (
                        <option key={size} value={size}>{size}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    disabled={prodCurrentPage === 1}
                    onClick={() => setProdCurrentPage(prev => Math.max(1, prev - 1))}
                    className="p-1.5 border border-slate-200 rounded-lg hover:bg-slate-100 bg-white transition disabled:opacity-40 disabled:hover:bg-white"
                  >
                    <ChevronRight size={14} />
                  </button>
                  {Array.from({ length: prodTotalPages }, (_, i) => i + 1).map(pageNum => (
                    <button
                      type="button"
                      key={pageNum}
                      onClick={() => setProdCurrentPage(pageNum)}
                      className={`w-7 h-7 flex items-center justify-center rounded-lg border text-xs font-semibold transition ${prodCurrentPage === pageNum ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm' : 'border-slate-200 hover:bg-slate-100 bg-white'}`}
                    >
                      {pageNum.toLocaleString('fa-IR')}
                    </button>
                  ))}
                  <button
                    type="button"
                    disabled={prodCurrentPage === prodTotalPages}
                    onClick={() => setProdCurrentPage(prev => Math.min(prodTotalPages, prev + 1))}
                    className="p-1.5 border border-slate-200 rounded-lg hover:bg-slate-100 bg-white transition disabled:opacity-40 disabled:hover:bg-white"
                  >
                    <ChevronLeft size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeDialog === 'category' && (
        <div className="fixed inset-0 bg-slate-100 z-50 flex flex-col overflow-hidden" id="category-commissions-view" dir="rtl">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200 shadow-sm">
            <div className="flex items-center gap-3">
              <button 
                type="button"
                onClick={saveCategoryCommissions}
                className="p-2 hover:bg-slate-100 rounded-xl text-slate-700 transition"
                title="بازگشت و ذخیره"
              >
                <ArrowRight size={22} className="text-slate-600" />
              </button>
              <div>
                <h1 className="text-lg font-bold text-slate-800">درصد به تفکیک دسته‌بندی</h1>
                <p className="text-xs text-slate-500 mt-0.5">تعیین درصد پورسانت فروش و برگشت اختصاصی برای درخت دسته‌بندی کالاها</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {selectedCatIds.length > 0 && (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedCatIds.length === 0) return;
                      if (window.confirm('آیا مطمئن هستید که می‌خواهید درصد‌های ردیف‌های انتخاب شده را بازنشانی کنید؟')) {
                        setEditedCatPercents(prev => {
                          const copy = { ...prev };
                          selectedCatIds.forEach(id => {
                            copy[id] = { sales: '', return: '' };
                          });
                          return copy;
                        });
                        setSelectedCatIds([]);
                      }
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 bg-rose-50 border border-rose-200 text-rose-600 rounded-xl hover:bg-rose-100 transition text-xs font-semibold"
                    title="حذف درصدهای انتخاب شده"
                  >
                    <Trash2 size={15} />
                    <span>حذف ({selectedCatIds.length})</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsBatchOpen(true)}
                    className="flex items-center gap-1.5 px-3 py-2 bg-indigo-50 border border-indigo-200 text-indigo-600 rounded-xl hover:bg-indigo-100 transition text-xs font-semibold"
                    title="اعمال درصد گروهی"
                  >
                    <Percent size={15} />
                    <span>اعمال درصد گروهی</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Table Container */}
          <div className="flex-1 p-6 space-y-4 overflow-auto">
            {/* Quick search */}
            <div className="max-w-md">
              <div className="relative flex items-center bg-white border border-slate-200 rounded-2xl px-3.5 py-2.5 shadow-sm">
                <Search size={16} className="text-slate-400 ml-2 shrink-0" />
                <input
                  type="text"
                  placeholder="جستجوی دسته‌بندی..."
                  value={catSearchTerm}
                  onChange={(e) => setCatSearchTerm(e.target.value)}
                  className="w-full bg-transparent text-sm text-slate-700 outline-none"
                />
                {catSearchTerm && (
                  <button 
                    type="button"
                    onClick={() => setCatSearchTerm('')}
                    className="text-slate-400 hover:text-slate-600 text-xs font-bold"
                  >
                    پاک کردن
                  </button>
                )}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
              <table className="w-full text-right border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-bold select-none">
                    <th className="py-3 px-4 text-center w-12">
                      <input
                        type="checkbox"
                        checked={SYSTEM_CATEGORIES.length > 0 && selectedCatIds.length === SYSTEM_CATEGORIES.length}
                        onChange={() => {
                          if (selectedCatIds.length === SYSTEM_CATEGORIES.length) {
                            setSelectedCatIds([]);
                          } else {
                            setSelectedCatIds(SYSTEM_CATEGORIES.map(c => c.id));
                          }
                        }}
                        className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                      />
                    </th>
                    <th className="py-3 px-4">دسته‌بندی کالاها و خدمات</th>
                    <th className="py-3 px-4 text-center w-40 bg-indigo-50/20">درصد فروش</th>
                    <th className="py-3 px-4 text-center w-44 bg-rose-50/10">درصد برگشت از فروش</th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100 text-slate-700 text-sm">
                  {(() => {
                    // Filter logic for dynamic categories list
                    let visibleCats = SYSTEM_CATEGORIES;
                    if (catSearchTerm.trim()) {
                      const term = catSearchTerm.toLowerCase();
                      const matchingIds = new Set<string>();
                      SYSTEM_CATEGORIES.forEach(c => {
                        if (c.name.toLowerCase().includes(term)) {
                          matchingIds.add(c.id);
                          let parentId = c.parentId;
                          while (parentId) {
                            matchingIds.add(parentId);
                            const parent = SYSTEM_CATEGORIES.find(x => x.id === parentId);
                            parentId = parent ? parent.parentId : null;
                          }
                        }
                      });
                      visibleCats = SYSTEM_CATEGORIES.filter(c => matchingIds.has(c.id));
                    } else {
                      visibleCats = SYSTEM_CATEGORIES.filter(c => {
                        let pId = c.parentId;
                        while (pId) {
                          if (collapsedCategories.includes(pId)) return false;
                          const parent = SYSTEM_CATEGORIES.find(x => x.id === pId);
                          pId = parent ? parent.parentId : null;
                        }
                        return true;
                      });
                    }

                    if (visibleCats.length === 0) {
                      return (
                        <tr>
                          <td colSpan={4} className="py-12 text-center text-slate-400 text-sm">
                            هیچ دسته‌بندی یافت نشد.
                          </td>
                        </tr>
                      );
                    }

                    return visibleCats.map(cat => {
                      const isSelected = selectedCatIds.includes(cat.id);
                      const hasKids = SYSTEM_CATEGORIES.some(c => c.parentId === cat.id);
                      const isCollapsed = collapsedCategories.includes(cat.id);

                      return (
                        <tr 
                          key={cat.id}
                          className={`hover:bg-slate-50/70 transition duration-150 ${isSelected ? 'bg-indigo-50/20' : ''}`}
                        >
                          {/* Checkbox */}
                          <td 
                            className="py-3.5 px-4 text-center w-12"
                            onClick={(e) => {
                              e.stopPropagation();
                              // Toggle hierarchy logic
                              const descendants: string[] = [];
                              const findDescendants = (pId: string) => {
                                SYSTEM_CATEGORIES.forEach(c => {
                                  if (c.parentId === pId) {
                                    descendants.push(c.id);
                                    findDescendants(c.id);
                                  }
                                });
                              };
                              findDescendants(cat.id);
                              const allIds = [cat.id, ...descendants];
                              const anySelected = allIds.some(id => selectedCatIds.includes(id));

                              if (anySelected) {
                                setSelectedCatIds(prev => prev.filter(id => !allIds.includes(id)));
                              } else {
                                setSelectedCatIds(prev => [...prev, ...allIds.filter(id => !prev.includes(id))]);
                              }
                            }}
                          >
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => {}}
                              className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                            />
                          </td>

                          {/* Category Name with Indentation & Collapse arrow */}
                          <td className="py-3 px-4">
                            <div 
                              className="flex items-center gap-1.5"
                              style={{ paddingRight: `${cat.level * 24}px` }}
                            >
                              {hasKids ? (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setCollapsedCategories(prev => prev.includes(cat.id) ? prev.filter(x => x !== cat.id) : [...prev, cat.id]);
                                  }}
                                  className="p-1 hover:bg-slate-100 rounded text-slate-500 transition shrink-0 ml-1"
                                >
                                  {isCollapsed ? <ChevronRight size={14} /> : <ChevronDown size={14} />}
                                </button>
                              ) : (
                                <span className="w-6 shrink-0"></span>
                              )}
                              
                              <span className={`text-sm ${cat.level === 0 ? 'font-bold text-slate-800' : cat.level === 1 ? 'font-semibold text-slate-700' : 'text-slate-600'}`}>
                                {cat.name}
                              </span>
                            </div>
                          </td>

                          {/* Sales Percent input */}
                          <td className="py-2 px-3 text-center bg-indigo-50/10 w-40">
                            <div className="flex items-center justify-center bg-white border border-slate-200 focus-within:border-indigo-500 rounded-xl px-3 py-1 max-w-[100px] mx-auto shadow-sm">
                              <input
                                type="text"
                                value={editedCatPercents[cat.id]?.sales ?? ''}
                                onChange={(e) => {
                                  const text = e.target.value.replace(/[^0-9.]/g, '');
                                  setEditedCatPercents(prev => ({
                                    ...prev,
                                    [cat.id]: { ...prev[cat.id], sales: text }
                                  }));
                                }}
                                placeholder="---"
                                className="w-full bg-transparent text-center text-xs font-bold text-slate-800 outline-none border-none p-0"
                              />
                              <span className="text-slate-400 text-[10px] mr-1">%</span>
                            </div>
                          </td>

                          {/* Return Percent input */}
                          <td className="py-2 px-3 text-center bg-rose-50/5 w-44">
                            <div className="flex items-center justify-center bg-white border border-slate-200 focus-within:border-indigo-500 rounded-xl px-3 py-1 max-w-[100px] mx-auto shadow-sm">
                              <input
                                type="text"
                                value={editedCatPercents[cat.id]?.return ?? ''}
                                onChange={(e) => {
                                  const text = e.target.value.replace(/[^0-9.]/g, '');
                                  setEditedCatPercents(prev => ({
                                    ...prev,
                                    [cat.id]: { ...prev[cat.id], return: text }
                                  }));
                                }}
                                placeholder="---"
                                className="w-full bg-transparent text-center text-xs font-bold text-slate-800 outline-none border-none p-0"
                              />
                              <span className="text-slate-400 text-[10px] mr-1">%</span>
                            </div>
                          </td>
                        </tr>
                      );
                    });
                  })()}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Batch Percent apply nested overlay */}
      {isBatchOpen && (
        <div className="fixed inset-0 bg-slate-950/45 backdrop-blur-[2px] flex items-center justify-center z-[100] p-4 transition duration-200">
          <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl border border-slate-100 overflow-hidden" dir="rtl">
            <div className="px-5 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
              <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                <Percent size={16} className="text-indigo-600" />
                <span>اعمال درصد گروهی</span>
              </h4>
              <button 
                type="button"
                onClick={() => setIsBatchOpen(false)}
                className="text-slate-400 hover:text-slate-600 transition"
              >
                <X size={18} />
              </button>
            </div>
            
            <div className="p-5 space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed text-right">
                درصدهای وارد شده به صورت همزمان روی {activeDialog === 'product' ? selectedProdIds.length : selectedCatIds.length} ردیف انتخاب شده اعمال خواهند شد.
              </p>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-slate-500 mb-1 text-right font-medium">درصد فروش</label>
                  <div className="flex items-center bg-slate-50 border border-slate-200 focus-within:border-indigo-500 rounded-xl px-3 py-2 transition">
                    <input
                      type="text"
                      value={batchSales}
                      onChange={(e) => setBatchSales(e.target.value.replace(/[^0-9.]/g, ''))}
                      className="w-full bg-transparent text-sm text-slate-800 font-bold outline-none border-none p-0 text-center"
                      placeholder="۰"
                    />
                    <span className="text-slate-400 font-bold mr-1">%</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-slate-500 mb-1 text-right font-medium">درصد برگشت</label>
                  <div className="flex items-center bg-slate-50 border border-slate-200 focus-within:border-indigo-500 rounded-xl px-3 py-2 transition">
                    <input
                      type="text"
                      value={batchReturn}
                      onChange={(e) => setBatchReturn(e.target.value.replace(/[^0-9.]/g, ''))}
                      className="w-full bg-transparent text-sm text-slate-800 font-bold outline-none border-none p-0 text-center"
                      placeholder="۰"
                    />
                    <span className="text-slate-400 font-bold mr-1">%</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="px-5 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsBatchOpen(false)}
                className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 rounded-xl transition text-xs font-semibold"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={() => {
                  if (activeDialog === 'product') {
                    setEditedProdPercents(prev => {
                      const copy = { ...prev };
                      selectedProdIds.forEach(id => {
                        copy[id] = { sales: batchSales, return: batchReturn };
                      });
                      return copy;
                    });
                    setSelectedProdIds([]);
                  } else {
                    setEditedCatPercents(prev => {
                      const copy = { ...prev };
                      selectedCatIds.forEach(id => {
                        copy[id] = { sales: batchSales, return: batchReturn };
                      });
                      return copy;
                    });
                    setSelectedCatIds([]);
                  }
                  setIsBatchOpen(false);
                  setBatchSales('');
                  setBatchReturn('');
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl transition text-xs font-semibold"
              >
                اعمال درصد
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

