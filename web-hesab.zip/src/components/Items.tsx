/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ItemService } from '../types';
import { Search, Plus, Archive, Tag, DollarSign, ListOrdered, Edit2, Trash2, Info } from 'lucide-react';

interface ItemsProps {
  items: ItemService[];
  setItems: React.Dispatch<React.SetStateAction<ItemService[]>>;
  subTabAction?: any;
  setSubTabAction?: any;
}

export default function Items({ items, setItems, subTabAction, setSubTabAction }: ItemsProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTab, setFilterTab] = useState<'all' | 'products' | 'services' | 'outofstock'>('all');

  // Modal control
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ItemService | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [unit, setUnit] = useState('عدد');
  const [salePrice, setSalePrice] = useState<number>(0);
  const [purchasePrice, setPurchasePrice] = useState<number>(0);
  const [stock, setStock] = useState<number>(0);
  const [description, setDescription] = useState('');
  const [isService, setIsService] = useState(false);

  // Advanced fields based on screenshots & user request
  const [isActive, setIsActive] = useState(true);
  const [category, setCategory] = useState('لوازم برقی آشپزخانه');
  const [itemType, setItemType] = useState('محصول نهایی');
  const [barcode, setBarcode] = useState('');
  const [image, setImage] = useState('');
  const [salesDescription, setSalesDescription] = useState('');
  const [purchaseDescription, setPurchaseDescription] = useState('');
  const [controlStock, setControlStock] = useState(false);
  const [reorderPoint, setReorderPoint] = useState<number>(0);
  const [minOrder, setMinOrder] = useState<number>(0);
  const [leadTime, setLeadTime] = useState<number>(0);
  const [taxSales, setTaxSales] = useState(true);
  const [taxPurchase, setTaxPurchase] = useState(true);
  const [salesTaxRate, setSalesTaxRate] = useState<number>(9);
  const [purchaseTaxRate, setPurchaseTaxRate] = useState<number>(9);
  const [taxTypeState, setTaxTypeState] = useState('۱۲- سایر کالا ها');
  const [taxCode, setTaxCode] = useState('');
  const [taxUnit, setTaxUnit] = useState('عدد');
  const [accountingCode, setAccountingCode] = useState('');
  const [isAutoAccountingCode, setIsAutoAccountingCode] = useState(true);

  // Tab control inside modal
  const [modalSubTab, setModalSubTab] = useState<'sales' | 'general' | 'stock' | 'tax'>('sales');

  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const PRODUCT_CATEGORIES = [
    'خدمات',
    'لوازم برقی آشپزخانه',
    'برقی منزل',
    'روشنایی',
    'لوازم آشپزخانه',
    'تزئینی',
    'بهداشت و حمام',
    'مواد اولیه',
    'لوازم و ابزار پذیرایی'
  ];

  const ITEM_TYPES = [
    'ماده اولیه',
    'محصول نهایی',
    'نیمه ساخت'
  ];

  const TAX_TYPES = [
    '۱۲- سایر کالا ها',
    '۱- دارو',
    '۲- دخانیات',
    '۳- موبایل',
    '۴- لوازم خانگی برقی',
    '۵- قطعات مصرفی و یدکی وسایل نقلیه',
    '۶- فرآورده ها و مشتقات نفتی و گازی و پتروشیمیایی',
    '۷- طلا اعم از شمش، مسکوکات و مصنوعات زینتی',
    '۸- منسوجات و پوشاک',
    '۹- اسباب بازی',
    '۱۰- دام زنده، گوشت سفید و قرمز',
    '۱۱- محصولات اساسی کشاورزی'
  ];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  const removeImage = () => {
    setImage('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  React.useEffect(() => {
    if (subTabAction && subTabAction.tab === 'items') {
      if (subTabAction.action === 'add-item') {
        setEditingItem(null);
        setName('');
        setCode('PRD-' + (items.length + 105));
        setUnit('عدد');
        setSalePrice(0);
        setPurchasePrice(0);
        setStock(10);
        setDescription('');
        setIsService(false);
        setIsActive(true);
        setCategory('لوازم برقی آشپزخانه');
        setItemType('محصول نهایی');
        setBarcode('');
        setImage('');
        setSalesDescription('');
        setPurchaseDescription('');
        setControlStock(false);
        setReorderPoint(0);
        setMinOrder(0);
        setLeadTime(0);
        setTaxSales(true);
        setTaxPurchase(true);
        setSalesTaxRate(9);
        setPurchaseTaxRate(9);
        setTaxTypeState('۱۲- سایر کالا ها');
        setTaxCode('');
        setTaxUnit('عدد');
        setAccountingCode('');
        setIsAutoAccountingCode(true);
        setModalSubTab('sales');
        setIsModalOpen(true);
      } else if (subTabAction.action === 'add-service') {
        setEditingItem(null);
        setName('');
        setCode('SRV-' + (items.length + 105));
        setUnit('ساعت');
        setSalePrice(0);
        setPurchasePrice(0);
        setStock(0);
        setDescription('');
        setIsService(true);
        setIsActive(true);
        setCategory('لوازم برقی آشپزخانه');
        setItemType('محصول نهایی');
        setBarcode('');
        setImage('');
        setSalesDescription('');
        setPurchaseDescription('');
        setControlStock(false);
        setReorderPoint(0);
        setMinOrder(0);
        setLeadTime(0);
        setTaxSales(true);
        setTaxPurchase(true);
        setSalesTaxRate(9);
        setPurchaseTaxRate(9);
        setTaxTypeState('۱۲- سایر کالا ها');
        setTaxCode('');
        setTaxUnit('ساعت');
        setAccountingCode('');
        setIsAutoAccountingCode(true);
        setModalSubTab('sales');
        setIsModalOpen(true);
      } else if (subTabAction.action === 'list') {
        setFilterTab('all');
      }
      if (setSubTabAction) {
        setSubTabAction(null);
      }
    }
  }, [subTabAction, items.length, setSubTabAction]);

  const formatMoney = (value: number) => {
    return value.toLocaleString('fa-IR') + ' تومان';
  };

  const formatNumber = (value: number) => {
    return value.toLocaleString('fa-IR');
  };

  // Filter items
  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          item.code.toLowerCase().includes(searchTerm.toLowerCase());
    if (!matchesSearch) return false;

    if (filterTab === 'all') return true;
    if (filterTab === 'products') return !item.isService;
    if (filterTab === 'services') return item.isService;
    if (filterTab === 'outofstock') return !item.isService && item.stock <= 0;

    return true;
  });

  const openAddProductModal = () => {
    setEditingItem(null);
    setName('');
    setCode('PRD-' + (items.length + 105));
    setUnit('عدد');
    setSalePrice(0);
    setPurchasePrice(0);
    setStock(10);
    setDescription('');
    setIsService(false);
    setIsActive(true);
    setCategory('لوازم برقی آشپزخانه');
    setItemType('محصول نهایی');
    setBarcode('');
    setImage('');
    setSalesDescription('');
    setPurchaseDescription('');
    setControlStock(false);
    setReorderPoint(0);
    setMinOrder(0);
    setLeadTime(0);
    setTaxSales(true);
    setTaxPurchase(true);
    setSalesTaxRate(9);
    setPurchaseTaxRate(9);
    setTaxTypeState('۱۲- سایر کالا ها');
    setTaxCode('');
    setTaxUnit('عدد');
    setAccountingCode('');
    setIsAutoAccountingCode(true);
    setModalSubTab('sales');
    setIsModalOpen(true);
  };

  const openAddServiceModal = () => {
    setEditingItem(null);
    setName('');
    setCode('SRV-' + (items.length + 105));
    setUnit('ساعت');
    setSalePrice(0);
    setPurchasePrice(0);
    setStock(0);
    setDescription('');
    setIsService(true);
    setIsActive(true);
    setCategory('خدمات');
    setItemType('محصول نهایی');
    setBarcode('');
    setImage('');
    setSalesDescription('');
    setPurchaseDescription('');
    setControlStock(false);
    setReorderPoint(0);
    setMinOrder(0);
    setLeadTime(0);
    setTaxSales(true);
    setTaxPurchase(true);
    setSalesTaxRate(9);
    setPurchaseTaxRate(9);
    setTaxTypeState('۱۲- سایر کالا ها');
    setTaxCode('');
    setTaxUnit('ساعت');
    setAccountingCode('');
    setIsAutoAccountingCode(true);
    setModalSubTab('sales');
    setIsModalOpen(true);
  };

  const openEditModal = (item: ItemService) => {
    setEditingItem(item);
    setName(item.name);
    setCode(item.code);
    setUnit(item.unit);
    setSalePrice(item.salePrice);
    setPurchasePrice(item.purchasePrice);
    setStock(item.stock);
    setDescription(item.description);
    setIsService(item.isService);
    setIsActive(item.isActive !== false);
    setCategory(item.category || 'لوازم برقی آشپزخانه');
    setItemType(item.itemType || 'محصول نهایی');
    setBarcode(item.barcode || '');
    setImage(item.image || '');
    setSalesDescription(item.salesDescription || '');
    setPurchaseDescription(item.purchaseDescription || '');
    setControlStock(!!item.controlStock);
    setReorderPoint(item.reorderPoint || 0);
    setMinOrder(item.minOrder || 0);
    setLeadTime(item.leadTime || 0);
    setTaxSales(item.taxSales !== false);
    setTaxPurchase(item.taxPurchase !== false);
    setSalesTaxRate(item.salesTaxRate ?? 9);
    setPurchaseTaxRate(item.purchaseTaxRate ?? 9);
    setTaxTypeState(item.taxType || '۱۲- سایر کالا ها');
    setTaxCode(item.taxCode || '');
    setTaxUnit(item.taxUnit || item.unit);
    setAccountingCode(item.accountingCode || '');
    setIsAutoAccountingCode(item.isAutoAccountingCode !== false);
    setModalSubTab('sales');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingItem) {
      // Update
      setItems(items.map(i => i.id === editingItem.id ? {
        ...i,
        name,
        code,
        unit,
        salePrice,
        purchasePrice,
        stock: isService ? 0 : stock,
        description,
        isService,
        isActive,
        category,
        itemType,
        barcode,
        image,
        salesDescription,
        purchaseDescription,
        controlStock,
        reorderPoint,
        minOrder,
        leadTime,
        taxSales,
        taxPurchase,
        salesTaxRate,
        purchaseTaxRate,
        taxType: taxTypeState,
        taxCode,
        taxUnit,
        accountingCode,
        isAutoAccountingCode
      } : i));
    } else {
      // Create
      const newItem: ItemService = {
        id: 'i_' + Date.now(),
        name,
        code,
        unit,
        salePrice,
        purchasePrice,
        stock: isService ? 0 : stock,
        description,
        isService,
        isActive,
        category,
        itemType,
        barcode,
        image,
        salesDescription,
        purchaseDescription,
        controlStock,
        reorderPoint,
        minOrder,
        leadTime,
        taxSales,
        taxPurchase,
        salesTaxRate,
        purchaseTaxRate,
        taxType: taxTypeState,
        taxCode,
        taxUnit,
        accountingCode,
        isAutoAccountingCode
      };
      setItems([...items, newItem]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('آیا از حذف این کالا/خدمت اطمینان دارید؟ در صورت قرار داشتن کالا در فاکتورهای قبلی، رکوردهای قدیمی حفظ خواهند شد.')) {
      setItems(items.filter(i => i.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header controls */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
        
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="جستجوی نام کالا یا کد محصول..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs pr-10 pl-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200"
          />
        </div>

        {/* Buttons and Filter Controls */}
        <div className="flex flex-wrap items-center gap-2">
          
          <div className="flex rounded-xl bg-slate-50 p-1 border border-slate-200">
            <button 
              onClick={() => setFilterTab('all')}
              className={`text-xs px-3 py-1.5 rounded-lg transition-all duration-200 font-medium ${filterTab === 'all' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
            >
              همه موارد
            </button>
            <button 
              onClick={() => setFilterTab('products')}
              className={`text-xs px-3 py-1.5 rounded-lg transition-all duration-200 font-medium ${filterTab === 'products' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
            >
              کالاها
            </button>
            <button 
              onClick={() => setFilterTab('services')}
              className={`text-xs px-3 py-1.5 rounded-lg transition-all duration-200 font-medium ${filterTab === 'services' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
            >
              خدمات
            </button>
            <button 
              onClick={() => setFilterTab('outofstock')}
              className={`text-xs px-3 py-1.5 rounded-lg transition-all duration-200 font-medium ${filterTab === 'outofstock' ? 'bg-white text-rose-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
            >
              بدون موجودی
            </button>
          </div>

          <button 
            onClick={openAddProductModal}
            className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-xs transition-all duration-200"
          >
            <Plus size={16} />
            <span>ثبت کالا جدید</span>
          </button>

          <button 
            onClick={openAddServiceModal}
            className="bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-xs transition-all duration-200"
          >
            <Plus size={16} />
            <span>ثبت خدمت جدید</span>
          </button>

        </div>

      </div>

      {/* Product List Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.length === 0 ? (
          <div className="col-span-full bg-white border border-slate-100 p-12 rounded-2xl text-center text-slate-400">
            <Archive size={48} className="mx-auto mb-3 text-slate-300" />
            <p className="text-sm font-semibold">هیچ کالا یا خدمتی یافت نشد.</p>
            <p className="text-xs mt-1">با فیلترهای دیگر امتحان کنید یا مورد جدیدی اضافه کنید.</p>
          </div>
        ) : (
          filteredItems.map(item => (
            <div 
              key={item.id} 
              className="bg-white rounded-2xl border border-slate-100 p-5 shadow-xs hover:shadow-md transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Name & Code & Thumbnail */}
                <div className="flex gap-3 mb-3">
                  {item.image ? (
                    <img src={item.image} alt={item.name} className="w-12 h-12 rounded-xl object-cover border border-slate-100 shrink-0 shadow-xs" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center border border-slate-100 shrink-0 text-slate-400">
                      <Tag size={18} />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-slate-800 truncate" title={item.name}>{item.name}</h4>
                        <span className="text-[10px] text-slate-400 font-mono mt-0.5 block">کد: {item.code}</span>
                      </div>
                      <div className="flex flex-col gap-1 items-end shrink-0">
                        <span className={`text-[9px] px-2 py-0.5 rounded-md font-bold ${
                          item.isService ? 'bg-purple-50 text-purple-600' : 'bg-blue-50 text-blue-600'
                        }`}>
                          {item.isService ? 'خدمت' : 'کالا'}
                        </span>
                        {item.itemType && !item.isService && (
                          <span className="text-[8px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-sm font-semibold">
                            {item.itemType}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Category & Barcode badges */}
                {(item.category || item.barcode) && (
                  <div className="flex flex-wrap gap-1 mb-3">
                    {item.category && (
                      <span className="text-[9px] bg-indigo-50/70 text-indigo-600 border border-indigo-100/30 px-2 py-0.5 rounded-full font-medium">
                        دسته: {item.category}
                      </span>
                    )}
                    {item.barcode && (
                      <span className="text-[9px] bg-slate-50 text-slate-500 border border-slate-100 px-2 py-0.5 rounded-full font-mono">
                        بارکد: {item.barcode}
                      </span>
                    )}
                  </div>
                )}

                {/* Description */}
                <p className="text-[11px] text-slate-500 line-clamp-2 h-8 mb-4 leading-relaxed">
                  {item.description || 'توضیحی برای این مورد ثبت نشده است.'}
                </p>

                {/* Stock tracker */}
                <div className="bg-slate-50 rounded-xl p-3 space-y-2 mb-4 border border-slate-100">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500 font-medium">موجودی انبار:</span>
                    {item.isService ? (
                      <span className="font-bold text-purple-600">خدمات (نامحدود)</span>
                    ) : item.stock > 5 ? (
                      <span className="font-bold text-emerald-600">{formatNumber(item.stock)} {item.unit}</span>
                    ) : item.stock > 0 ? (
                      <span className="font-bold text-amber-600">کم ({formatNumber(item.stock)} {item.unit})</span>
                    ) : (
                      <span className="font-bold text-rose-600">اتمام موجودی</span>
                    )}
                  </div>
                  
                  {/* Progress bar for stock */}
                  {!item.isService && (
                    <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${item.stock > 5 ? 'bg-emerald-500' : item.stock > 0 ? 'bg-amber-500' : 'bg-rose-500'}`}
                        style={{ width: `${Math.min(100, (item.stock / 50) * 100)}%` }}
                      ></div>
                    </div>
                  )}
                </div>

                {/* Price list */}
                <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-100">
                  <div className="bg-emerald-50/40 p-2 rounded-xl border border-emerald-100/30">
                    <span className="text-[10px] text-emerald-700 font-medium block mb-0.5">قیمت فروش:</span>
                    <span className="font-bold text-emerald-700">{formatMoney(item.salePrice)}</span>
                  </div>
                  <div className="bg-slate-50/60 p-2 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-500 font-medium block mb-0.5">قیمت خرید:</span>
                    <span className="font-bold text-slate-600">{item.purchasePrice > 0 ? formatMoney(item.purchasePrice) : '---'}</span>
                  </div>
                </div>

              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-2 mt-5 pt-3 border-t border-slate-50">
                <button 
                  onClick={() => openEditModal(item)}
                  className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors duration-200"
                  title="ویرایش مشخصات"
                >
                  <Edit2 size={14} />
                </button>
                <button 
                  onClick={() => handleDelete(item.id)}
                  className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors duration-200"
                  title="حذف کالا"
                >
                  <Trash2 size={14} />
                </button>
              </div>

            </div>
          ))
        )}
      </div>

      {/* Add / Edit Dialog (Modal) */}
      {isModalOpen && (
        <div id="item-modal" className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl border border-slate-100 flex flex-col max-h-[90vh]">
            
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-100 flex items-center justify-between" dir="rtl">
              <h3 className="text-sm font-bold text-slate-800">
                {isService 
                  ? (editingItem ? 'مشخصات خدمات / ویرایش' : 'مشخصات خدمات / جدید')
                  : (editingItem ? 'مشخصات کالا / ویرایش' : 'مشخصات کالا / جدید')}
              </h3>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ×
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 flex-1 text-right" dir="rtl">
              
              {/* Hidden file input */}
              <input 
                type="file"
                ref={fileInputRef}
                onChange={handleImageChange}
                accept="image/*"
                className="hidden"
              />

              {/* Top Section: Inputs and Image Box */}
              <div className="flex flex-col-reverse md:flex-row gap-6">
                
                {/* Main fields (Left/Center) */}
                <div className="flex-1 space-y-4">
                  
                  {/* Accounting code & Active checkbox */}
                  <div className="flex flex-wrap items-end justify-between gap-3">
                    <div className="flex-1 min-w-[200px]">
                      <label className="block text-xs font-bold text-slate-600 mb-1.5">کد حسابداری</label>
                      <div className="flex gap-1.5">
                        <input 
                          type="text"
                          disabled={isAutoAccountingCode}
                          value={isAutoAccountingCode ? 'سیستمی (اتوماتیک)' : accountingCode}
                          onChange={(e) => setAccountingCode(e.target.value)}
                          placeholder="مثال: ۱۴۰۱"
                          className="flex-1 text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 disabled:opacity-75 disabled:bg-slate-100/80 font-mono text-left"
                          dir="ltr"
                        />
                        <button 
                          type="button"
                          onClick={() => setIsAutoAccountingCode(!isAutoAccountingCode)}
                          className={`text-[10px] font-bold px-3 py-2 rounded-xl border transition-all duration-200 shrink-0 ${
                            isAutoAccountingCode 
                              ? 'bg-blue-50 border-blue-200 text-blue-600' 
                              : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
                          }`}
                        >
                          اتوماتیک
                        </button>
                      </div>
                    </div>
                    
                    <label className="flex items-center gap-2 cursor-pointer pb-2">
                      <input 
                        type="checkbox"
                        checked={isActive}
                        onChange={(e) => setIsActive(e.target.checked)}
                        className="rounded-sm border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                      />
                      <span className="text-xs font-bold text-slate-600">فعال</span>
                    </label>
                  </div>

                  {/* Item Name */}
                  <div>
                    <label className="block text-xs font-bold text-slate-600 mb-1.5">
                      {isService ? 'عنوان خدمات' : 'نام کالا'} <span className="text-rose-500">*</span>
                    </label>
                    <input 
                      type="text" 
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={isService ? "عنوان یا نام خدمت را وارد کنید..." : "عنوان یا نام کالا را وارد کنید..."}
                      className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 font-semibold"
                    />
                  </div>

                  {/* Code & Barcode */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1.5">
                        {isService ? 'کد خدمات' : 'کد کالا'}
                      </label>
                      <input 
                        type="text" 
                        required
                        value={code}
                        onChange={(e) => setCode(e.target.value)}
                        placeholder={isService ? "SRV-101" : "PRD-101"}
                        className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 text-left font-mono"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1.5">بارکد</label>
                      <input 
                        type="text" 
                        value={barcode}
                        onChange={(e) => setBarcode(e.target.value)}
                        placeholder="بارکد..."
                        className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 text-left font-mono"
                        dir="ltr"
                      />
                      <span className="text-[9px] text-slate-400 mt-1 block leading-normal">
                        بارکدهای مختلف را با ; از هم جدا کنید.
                      </span>
                    </div>
                  </div>

                  {/* Category & Item Type */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className={isService ? "col-span-2" : ""}>
                      <label className="block text-xs font-bold text-slate-600 mb-1.5">دسته بندی</label>
                      <select 
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 font-medium"
                      >
                        {PRODUCT_CATEGORIES.map(cat => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                    {!isService && (
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">نوع کالا</label>
                        <select 
                          value={itemType}
                          onChange={(e) => setItemType(e.target.value)}
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 font-medium"
                        >
                          {ITEM_TYPES.map(type => (
                            <option key={type} value={type}>{type}</option>
                          ))}
                        </select>
                      </div>
                    )}
                  </div>

                </div>

                {/* Right side: Image avatar uploader */}
                <div className="flex flex-col items-center justify-start shrink-0">
                  <div className="relative group w-36 h-36 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center overflow-hidden transition-all duration-300 hover:border-blue-400">
                    {image ? (
                      <img 
                        src={image} 
                        alt="Avatar" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : isService ? (
                      <div className="flex flex-col items-center text-center p-2 text-slate-400">
                        {/* Custom Service Tool Icon */}
                        <svg className="w-16 h-16 mb-1 rounded-2xl shadow-sm" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <rect width="100" height="100" rx="24" fill="url(#greenGrad)" />
                          <g transform="translate(15, 15) scale(0.7)">
                            {/* Wrench */}
                            <path d="M20 80 L60 40" stroke="#E2E8F0" strokeWidth="10" strokeLinecap="round" />
                            <path d="M20 80 L60 40" stroke="#94A3B8" strokeWidth="6" strokeLinecap="round" />
                            <path d="M60 40 C65 35 75 35 80 40 C85 45 85 55 80 60 L70 50" stroke="#E2E8F0" strokeWidth="8" strokeLinecap="round" fill="none" />
                            <path d="M15 75 C10 70 5 70 5 75 C5 80 10 85 15 80" stroke="#E2E8F0" strokeWidth="8" strokeLinecap="round" fill="none" />
                          </g>
                          <g transform="translate(15, 15) scale(0.7)">
                            {/* Screwdriver */}
                            <path d="M80 20 L45 55" stroke="#CBD5E1" strokeWidth="5" strokeLinecap="round" />
                            <path d="M85 15 L78 22" stroke="#94A3B8" strokeWidth="6" strokeLinecap="round" />
                            <path d="M45 55 L25 75" stroke="#F59E0B" strokeWidth="14" strokeLinecap="round" />
                            <path d="M38 62 L22 78" stroke="#D97706" strokeWidth="8" strokeLinecap="round" />
                          </g>
                          <defs>
                            <linearGradient id="greenGrad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
                              <stop stopColor="#10B981" />
                              <stop stopColor="#059669" />
                            </linearGradient>
                          </defs>
                        </svg>
                        <span className="text-[10px] font-bold text-slate-500">مشخصات خدمات</span>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center text-center p-3 text-slate-400">
                        {/* 3D boxes SVG mock */}
                        <svg className="w-12 h-12 mb-2 text-slate-300 group-hover:text-blue-400 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-9v9" />
                        </svg>
                        <span className="text-[10px] font-bold text-slate-500">مشخصات کالا</span>
                      </div>
                    )}
                  </div>
                  
                  {/* Image Picker labels */}
                  <div className="flex items-center gap-4 mt-3 text-xs">
                    <button 
                      type="button"
                      onClick={triggerFileSelect}
                      className="text-blue-600 hover:text-blue-700 font-bold transition-colors"
                    >
                      انتخاب
                    </button>
                    {image && (
                      <button 
                        type="button"
                        onClick={removeImage}
                        className="text-rose-600 hover:text-rose-700 font-bold transition-colors"
                      >
                        حذف
                      </button>
                    )}
                  </div>
                </div>

              </div>

              {/* Tab Navigation */}
              <div className="flex border-b border-slate-100 text-xs font-bold" dir="rtl">
                <button
                  type="button"
                  onClick={() => setModalSubTab('sales')}
                  className={`flex-1 pb-2.5 text-center transition-all border-b-2 ${
                    modalSubTab === 'sales' ? 'border-blue-500 text-blue-600' : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                >
                  فروش
                </button>
                <button
                  type="button"
                  onClick={() => setModalSubTab('general')}
                  className={`flex-1 pb-2.5 text-center transition-all border-b-2 ${
                    modalSubTab === 'general' ? 'border-blue-500 text-blue-600' : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                >
                  عمومی
                </button>
                {!isService && (
                  <button
                    type="button"
                    onClick={() => setModalSubTab('stock')}
                    className={`flex-1 pb-2.5 text-center transition-all border-b-2 ${
                      modalSubTab === 'stock' ? 'border-blue-500 text-blue-600' : 'border-transparent text-slate-400 hover:text-slate-600'
                    }`}
                  >
                    موجودی کالا
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setModalSubTab('tax')}
                  className={`flex-1 pb-2.5 text-center transition-all border-b-2 ${
                    modalSubTab === 'tax' ? 'border-blue-500 text-blue-600' : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                >
                  مالیات
                </button>
              </div>

              {/* Tab Contents */}
              <div className="min-h-[160px] pt-1">
                
                {/* 1. SALES / PURCHASE TAB */}
                {modalSubTab === 'sales' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Default Sales Price */}
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">قیمت فروش پیش‌فرض *</label>
                        <div className="relative">
                          <input 
                            type="number" 
                            required
                            value={salePrice}
                            onChange={(e) => setSalePrice(Number(e.target.value))}
                            placeholder="۴۵۰۰۰۰"
                            className="w-full text-xs pl-12 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 text-left font-mono"
                            dir="ltr"
                          />
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-bold">ریال</span>
                        </div>
                      </div>
                      
                      {/* Sales Description */}
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">توضیحات فروش</label>
                        <input 
                          type="text"
                          value={salesDescription}
                          onChange={(e) => setSalesDescription(e.target.value)}
                          placeholder="توضیحات فاکتور فروش..."
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Default Purchase Price */}
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">قیمت خرید پیش‌فرض</label>
                        <div className="relative">
                          <input 
                            type="number" 
                            value={purchasePrice}
                            onChange={(e) => setPurchasePrice(Number(e.target.value))}
                            placeholder="۳۸۰۰۰۰"
                            className="w-full text-xs pl-12 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 text-left font-mono"
                            dir="ltr"
                          />
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-bold">ریال</span>
                        </div>
                      </div>

                      {/* Purchase Description */}
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">توضیحات خرید</label>
                        <input 
                          type="text"
                          value={purchaseDescription}
                          onChange={(e) => setPurchaseDescription(e.target.value)}
                          placeholder="توضیحات فاکتور خرید..."
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* 2. GENERAL TAB */}
                {modalSubTab === 'general' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">واحد اصلی *</label>
                        <input 
                          type="text" 
                          required
                          value={unit}
                          onChange={(e) => setUnit(e.target.value)}
                          placeholder="عدد، متر، کیلوگرم، ساعت..."
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200"
                        />
                      </div>
                      
                      {/* Main description details */}
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">توضیحات</label>
                        <input 
                          type="text"
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          placeholder="مشخصات کلی، رنگ، گارانتی..."
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* 3. STOCK TAB */}
                {modalSubTab === 'stock' && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 mb-2">
                      <input 
                        type="checkbox"
                        id="controlStock"
                        checked={controlStock}
                        onChange={(e) => setControlStock(e.target.checked)}
                        className="rounded-sm border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                      />
                      <label htmlFor="controlStock" className="text-xs font-bold text-slate-600 cursor-pointer">
                        کنترل موجودی
                      </label>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">موجودی فعلی (انبار)</label>
                        <input 
                          type="number" 
                          disabled={isService}
                          value={stock}
                          onChange={(e) => setStock(Number(e.target.value))}
                          placeholder="مثال: ۱۵"
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 disabled:opacity-50 disabled:bg-slate-100"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">نقطه سفارش</label>
                        <input 
                          type="number" 
                          value={reorderPoint}
                          onChange={(e) => setReorderPoint(Number(e.target.value))}
                          placeholder="مثال: ۵"
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">حداقل سفارش</label>
                        <input 
                          type="number" 
                          value={minOrder}
                          onChange={(e) => setMinOrder(Number(e.target.value))}
                          placeholder="مثال: ۲"
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1.5">زمان انتظار</label>
                      <input 
                        type="number" 
                        value={leadTime}
                        onChange={(e) => setLeadTime(Number(e.target.value))}
                        placeholder="زمان تقریبی تحویل (روز)..."
                        className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200"
                      />
                    </div>
                  </div>
                )}

                {/* 4. TAX TAB */}
                {modalSubTab === 'tax' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-3">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input 
                            type="checkbox"
                            checked={taxSales}
                            onChange={(e) => setTaxSales(e.target.checked)}
                            className="rounded-sm border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                          />
                          <span className="text-xs font-bold text-slate-600">مشمول مالیات فروش</span>
                        </label>
                        <div className="relative">
                          <input 
                            type="number" 
                            disabled={!taxSales}
                            value={salesTaxRate}
                            onChange={(e) => setSalesTaxRate(Number(e.target.value))}
                            placeholder="۹"
                            className="w-full text-xs pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 text-left font-mono disabled:opacity-50"
                            dir="ltr"
                          />
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-bold">%</span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input 
                            type="checkbox"
                            checked={taxPurchase}
                            onChange={(e) => setTaxPurchase(e.target.checked)}
                            className="rounded-sm border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                          />
                          <span className="text-xs font-bold text-slate-600">مشمول مالیات خرید</span>
                        </label>
                        <div className="relative">
                          <input 
                            type="number" 
                            disabled={!taxPurchase}
                            value={purchaseTaxRate}
                            onChange={(e) => setPurchaseTaxRate(Number(e.target.value))}
                            placeholder="۹"
                            className="w-full text-xs pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 text-left font-mono disabled:opacity-50"
                            dir="ltr"
                          />
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-bold">%</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1.5">نوع مالیات</label>
                      <select 
                        value={taxTypeState}
                        onChange={(e) => setTaxTypeState(e.target.value)}
                        className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 font-medium"
                      >
                        {TAX_TYPES.map(tx => (
                          <option key={tx} value={tx}>{tx}</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">کد مالیاتی کالا</label>
                        <input 
                          type="text" 
                          value={taxCode}
                          onChange={(e) => setTaxCode(e.target.value)}
                          placeholder="کد سامانه مودیان..."
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 font-mono text-left"
                          dir="ltr"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1.5">واحد مالیاتی</label>
                        <select 
                          value={taxUnit}
                          onChange={(e) => setTaxUnit(e.target.value)}
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 font-medium"
                        >
                          <option value="عدد">عدد</option>
                          <option value="بسته">بسته</option>
                          <option value="کیلوگرم">کیلوگرم</option>
                          <option value="ساعت">ساعت</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

              </div>

              {/* Disclaimer */}
              <div className="p-3 bg-indigo-50/50 rounded-xl border border-indigo-100 flex gap-2 text-[10px] text-slate-600 leading-relaxed" dir="rtl">
                <Info size={16} className="text-indigo-500 shrink-0" />
                <span>
                  با ثبت کالا، در هنگام صدور فاکتورهای فروش و خرید، کافی است نام کالا را تایپ کنید تا قیمت پیش‌فرض و شرح فنی به صورت خودکار برای خریدار بارگذاری و تکمیل گردد.
                </span>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="text-xs font-bold text-slate-500 hover:text-slate-700 px-6 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 transition-colors"
                >
                  انصراف
                </button>
                <button 
                  type="submit"
                  className="bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold px-8 py-2.5 rounded-xl transition-colors shadow-xs"
                >
                  {editingItem ? 'ویرایش و ذخیره' : (isService ? 'ثبت خدمت جدید' : 'ثبت در انبار')}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
