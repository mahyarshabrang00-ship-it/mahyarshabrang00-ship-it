/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Invoice } from '../types';
import { 
  Building, 
  Send, 
  Mail, 
  Settings, 
  FileCheck, 
  Folder, 
  Plus, 
  Trash2, 
  CheckCircle, 
  Code 
} from 'lucide-react';

interface OtherFeaturesProps {
  invoices: Invoice[];
  subTabAction?: any;
  setSubTabAction?: any;
}

interface TaxPayload {
  invoiceNumber: string;
  uniqueTaxId: string; // ۲۲ رقمی
  date: string;
  subtotal: number;
  tax: number;
  total: number;
  status: 'sent' | 'pending';
}

interface ArchiveDoc {
  id: string;
  name: string;
  size: string;
  type: string;
  date: string;
}

export default function OtherFeatures({ invoices, subTabAction, setSubTabAction }: OtherFeaturesProps) {
  const [activeTab, setActiveTab] = useState<'mودیان' | 'sms' | 'archive'>('mودیان');

  // Seed Tax payloads
  const [taxInvoices, setTaxInvoices] = useState<TaxPayload[]>([
    {
      invoiceNumber: 'INV-103',
      uniqueTaxId: 'A84FF70299921004128935',
      date: '۱۴۰۵/۰۴/۱۶',
      subtotal: 10000000,
      tax: 1000000,
      total: 11000000,
      status: 'sent'
    }
  ]);

  // SMS Settings
  const [smsGateway, setSmsGateway] = useState('kavehnegar');
  const [apiKey, setApiKey] = useState('••••••••••••••••••••••••••••••••');
  const [smsTemplate, setSmsTemplate] = useState('جناب آقای/سرکار خانم {نام}، فاکتور شماره {شماره} به مبلغ {مبلغ} ریال صادر شد. با سپاس، مانی');

  // Archive Documents
  const [docs, setDocs] = useState<ArchiveDoc[]>([
    { id: 'doc-1', name: 'تصویر اجاره‌نامه مردادماه.pdf', size: '2.4 MB', type: 'PDF', date: '۱۴۰۵/۰۴/۱۰' },
    { id: 'doc-2', name: 'رسید پرداخت فاکتور ۱۰۰۴.png', size: '840 KB', type: 'PNG', date: '۱۴۰۵/۰۴/۱۷' }
  ]);

  // Tax Submission Working States
  const [isTaxSubmitting, setIsTaxSubmitting] = useState(false);
  const [currentTaxPayload, setCurrentTaxPayload] = useState<any | null>(null);

  // Responsive commands
  React.useEffect(() => {
    if (subTabAction && subTabAction.tab === 'other') {
      if (subTabAction.action === 'tax-authority') {
        setActiveTab('mودیان');
      } else if (subTabAction.action === 'sms-panel') {
        setActiveTab('sms');
      } else if (subTabAction.action === 'document-archive') {
        setActiveTab('archive');
      }
      if (setSubTabAction) {
        setSubTabAction(null);
      }
    }
  }, [subTabAction]);

  const formatMoney = (val: number) => val.toLocaleString('fa-IR') + ' تومان';
  const formatNumber = (val: number) => val.toLocaleString('fa-IR');

  const generateTaxId = (invNum: string) => {
    // Generate a 22-character unique tax id: 6 char tax code (e.g. 299921) + 5 char date + 10 char random hex + 1 check digit
    const companyCode = '29992';
    const dateCode = '10041'; // Mock julian date
    const randomHex = Math.floor(Math.random() * 0xffffffff).toString(16).padEnd(10, '0').toUpperCase().slice(0, 10);
    const checkDigit = Math.floor(Math.random() * 10).toString();
    return `${companyCode}${dateCode}${randomHex}${checkDigit}`;
  };

  const handleSendToTaxAuthority = (invoice: Invoice) => {
    setIsTaxSubmitting(true);
    
    // Create payload
    const generatedId = generateTaxId(invoice.number);
    const payload = {
      header: {
        taxid: generatedId,
        indatim: Date.now(),
        Inty: 1, // Type 1: Standard invoice
        Inp: 1, // Cash payment method
        tins: '14002931049', // Company national economic number
        bid: '10103982401' // Buyer economic number
      },
      body: invoice.items.map((item, idx) => ({
        sstid: '2330000129034', // Iranian merchandise ID standard
        sstt: item.itemName,
        am: item.qty,
        mu: 162, // count unit standard
        fee: item.unitPrice,
        dis: item.discount,
        tax: item.tax,
        tot: item.total
      }))
    };

    setCurrentTaxPayload(payload);

    setTimeout(() => {
      // Done submitting
      setIsTaxSubmitting(false);
      setTaxInvoices([
        {
          invoiceNumber: invoice.number,
          uniqueTaxId: generatedId,
          date: invoice.date,
          subtotal: invoice.total - invoice.tax,
          tax: invoice.tax,
          total: invoice.total,
          status: 'sent'
        },
        ...taxInvoices
      ]);
      alert('صورتحساب با موفقیت ممهور به امضای دیجیتال مانی شد و با وضعیت «تایید شده» در کارپوشه سامانه مودیان نشست!');
      setCurrentTaxPayload(null);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Sub tabs header */}
      <div className="flex border-b border-slate-200/40 pb-px print:hidden">
        <button
          onClick={() => setActiveTab('mودیان')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'mودیان' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Building size={14} />
          سامانه مودیان مالیاتی کشور
        </button>
        <button
          onClick={() => setActiveTab('sms')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'sms' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Mail size={14} />
          تنظیمات پنل پیامک و اطلاع‌رسانی
        </button>
        <button
          onClick={() => setActiveTab('archive')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'archive' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Folder size={14} />
          آرشیو اسناد فیزیکی و ضمایم
        </button>
      </div>

      {/* TAX AUTHORITY TAB */}
      {activeTab === 'mودیان' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-xs space-y-3">
            <h4 className="font-black text-xs text-slate-800">امضای دیجیتال و ارسال خودکار صورتحساب‌ها به مودیان</h4>
            <p className="text-[10px] text-slate-400 leading-relaxed">مطابق قانون پایانه‌های فروشگاهی، کلیه فاکتورهای فروش رسمی باید ممهور به امضای دیجیتال کلید خصوصی شرکت شده و مستقیماً به سرور کارپوشه دولتی فرستاده شوند.</p>
            <div className="bg-slate-50 border border-slate-100 p-3.5 rounded-2xl flex items-center justify-between text-xs font-bold text-slate-700">
              <span>شناسه یکتای حافظه مالیاتی شرکت: A84FF7 (فعال)</span>
              <span className="text-emerald-600 flex items-center gap-1">
                <CheckCircle size={14} />
                توکن سخت‌افزاری متصل است
              </span>
            </div>
          </div>

          {/* Action: Send new invoices to tax authority */}
          <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-xs">
            <h5 className="font-black text-xs text-slate-800 mb-3">فاکتورهای آماده جهت ارسال به سامانه مودیان</h5>
            <div className="space-y-3">
              {invoices.filter(inv => inv.type === 'sales' && !taxInvoices.some(t => t.invoiceNumber === inv.number)).map(inv => (
                <div key={inv.id} className="border border-slate-100 rounded-2xl p-4 bg-slate-50/20 flex items-center justify-between flex-wrap gap-4">
                  <div>
                    <span className="font-black text-xs text-slate-800 block">فاکتور شماره {inv.number} ({inv.contactName})</span>
                    <span className="text-[10px] text-slate-400 mt-1 block">تاریخ صدور: {inv.date} | جمع ناخالص با ارزش افزوده: {formatMoney(inv.total)}</span>
                  </div>
                  <button
                    onClick={() => handleSendToTaxAuthority(inv)}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send size={13} />
                    امضا و ارسال به کارپوشه مودیان
                  </button>
                </div>
              ))}

              {invoices.filter(inv => inv.type === 'sales' && !taxInvoices.some(t => t.invoiceNumber === inv.number)).length === 0 && (
                <p className="text-[10px] text-slate-400 text-center py-4 font-bold">تمام فاکتورهای فروش صادر شده پیش‌تر ارسال شده‌اند یا فاکتور واجد شرایطی وجود ندارد.</p>
              )}
            </div>
          </div>

          {/* Tax Invoice Logs */}
          <div className="bg-white border border-slate-100 rounded-3xl shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-50">
              <h5 className="font-black text-xs text-slate-800">لیست صورتحساب‌های ثبت نهایی شده قانون مودیان</h5>
            </div>
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-100 text-slate-500 font-bold">
                <tr>
                  <th className="p-4">شماره فاکتور</th>
                  <th className="p-4">شماره ۲۲ رقمی منحصر بفرد مالیاتی</th>
                  <th className="p-4">تاریخ ارسال</th>
                  <th className="p-4 text-left">مجموع صورتحساب</th>
                  <th className="p-4">وضعیت سامانه</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {taxInvoices.map((t, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/40">
                    <td className="p-4 font-mono font-black text-slate-800">{t.invoiceNumber}</td>
                    <td className="p-4 font-mono font-bold text-blue-600 tracking-wide">{t.uniqueTaxId}</td>
                    <td className="p-4 font-mono text-slate-400">{t.date}</td>
                    <td className="p-4 font-mono text-left font-bold text-slate-700">{formatMoney(t.total)}</td>
                    <td className="p-4">
                      <span className="bg-emerald-50 text-emerald-700 font-black text-[9px] px-2.5 py-1 rounded-lg border border-emerald-100">
                        مورد تایید سازمان (قانون پایانه‌ها)
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Submission Modal simulator */}
          {isTaxSubmitting && (
            <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
              <div className="bg-white border border-slate-100 rounded-3xl w-full max-w-lg shadow-2xl p-6 text-right">
                <div className="flex items-center gap-3 mb-4 text-blue-600">
                  <span className="w-2 h-2 bg-blue-500 rounded-full animate-ping"></span>
                  <h4 className="font-black text-sm">در حال بسته‌بندی رمزنگاری و ارسال به کارپوشه...</h4>
                </div>

                {currentTaxPayload && (
                  <div className="space-y-4">
                    <p className="text-[11px] text-slate-500">سند با کلید خصوصی سخت‌افزاری مهر امضای دیجیتال خورد. خروجی استاندارد JSON ارسالی:</p>
                    <div className="bg-slate-900 text-slate-300 font-mono text-[9px] p-4 rounded-xl max-h-48 overflow-y-auto text-left whitespace-pre">
                      {JSON.stringify(currentTaxPayload, null, 2)}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* SMS SETTINGS TAB */}
      {activeTab === 'sms' && (
        <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-xs space-y-4">
          <h4 className="font-black text-xs text-slate-800">پیکربندی پنل اطلاع رسانی پیامکی</h4>
          <p className="text-[10px] text-slate-400">ارسال اتوماتیک پیامک پیگیری فاکتورها، اعلام سررسید بدهی و خوش‌آمدگویی به مشتریان را تنظیم کنید.</p>

          <form className="space-y-4 max-w-xl text-right">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">درگاه ارائه دهنده</label>
                <select
                  value={smsGateway}
                  onChange={(e) => setSmsGateway(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-bold text-slate-700"
                >
                  <option value="kavehnegar">کاوه نگار (توصیه شده)</option>
                  <option value="mellipayamak">ملی پیامک</option>
                  <option value="farazsms">فراز اس‌ام‌اس</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">کلید دسترسی API Key</label>
                <input
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-500 mb-1">الگوی پیامک صدور فاکتور جدید</label>
              <textarea
                rows={3}
                value={smsTemplate}
                onChange={(e) => setSmsTemplate(e.target.value)}
                className="w-full text-xs p-3.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-semibold leading-relaxed"
              ></textarea>
              <span className="text-[9px] text-slate-400 mt-1 block">راهنما: از متغیرهای {'{نام}'}، {'{شماره}'} و {'{مبلغ}'} استفاده کنید.</span>
            </div>

            <button
              type="button"
              onClick={() => alert('تغییرات با موفقیت ذخیره شد. پیامک تستی به مدیریت ارسال گردید.')}
              className="bg-blue-600 hover:bg-blue-700 text-white font-black text-xs px-4 py-2 rounded-xl cursor-pointer"
            >
              ذخیره تنظیمات درگاه پیامک
            </button>
          </form>
        </div>
      )}

      {/* DOCUMENT ARCHIVE TAB */}
      {activeTab === 'archive' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-black text-xs text-slate-800">بایگانی دیجیتال اسناد و پیوست‌های فیزیکی</h4>
            <button
              onClick={() => alert('سیستم درگاه پیوست فایل فعال است. شما می‌توانید فایل خود را برای آپلود به این قسمت بکشید.')}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-3 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer"
            >
              <Plus size={14} />
              افزودن سند پیوستی جدید
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {docs.map(doc => (
              <div key={doc.id} className="bg-white border border-slate-100 rounded-3xl p-4 shadow-xs flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-slate-100 text-slate-500 rounded-xl flex items-center justify-center font-black text-xs">
                    {doc.type}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-800 block">{doc.name}</span>
                    <span className="text-[9px] text-slate-400 mt-1 block">اندازه: {doc.size} | تاریخ ثبت: {doc.date}</span>
                  </div>
                </div>
                <button
                  onClick={() => setDocs(docs.filter(d => d.id !== doc.id))}
                  className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg cursor-pointer"
                  title="حذف سند"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
