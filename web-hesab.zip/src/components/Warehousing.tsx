/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ItemService } from '../types';
import { 
  Boxes, 
  Plus, 
  TrendingUp, 
  Shuffle, 
  ClipboardCheck, 
  AlertTriangle, 
  ShieldCheck, 
  Layers 
} from 'lucide-react';

interface WarehousingProps {
  items: ItemService[];
  setItems: React.Dispatch<React.SetStateAction<ItemService[]>>;
  subTabAction?: any;
  setSubTabAction?: any;
}

interface Warehouse {
  id: string;
  name: string;
  code: string;
  location: string;
  isMain: boolean;
}

interface StockMovement {
  id: string;
  itemId: string;
  itemName: string;
  fromWarehouseId: string;
  toWarehouseId: string;
  qty: number;
  date: string;
  type: 'transfer' | 'receipt' | 'dispatch' | 'audit_adj';
  refNumber: string;
}

interface AuditRecord {
  id: string;
  date: string;
  warehouseId: string;
  status: 'draft' | 'finalized';
  discrepanciesCount: number;
}

export default function Warehousing({ items, setItems, subTabAction, setSubTabAction }: WarehousingProps) {
  const [activeTab, setActiveTab] = useState<'warehouses' | 'movements' | 'inventory' | 'audit'>('inventory');

  // Initial Seed Warehouses
  const [warehouses, setWarehouses] = useState<Warehouse[]>([
    { id: 'w-1', name: 'انبار مرکزی مانی', code: 'W-01', location: 'تهران، جاده مخصوص کرج', isMain: true },
    { id: 'w-2', name: 'انبار توزیع شرق', code: 'W-02', location: 'تهران، تهرانپارس، خ فرجام', isMain: false },
    { id: 'w-3', name: 'انبار ضایعات و مرجوعی', code: 'W-03', location: 'تهران، کهریزک', isMain: false }
  ]);

  // Initial Movements
  const [movements, setMovements] = useState<StockMovement[]>([
    {
      id: 'sm-201',
      itemId: '2',
      itemName: 'چای کیسه‌ای لاهیجان',
      fromWarehouseId: 'w-1',
      toWarehouseId: 'w-2',
      qty: 150,
      date: '۱۴۰۵/۰۴/۱۵',
      type: 'transfer',
      refNumber: 'TR-10492'
    }
  ]);

  // Audit Records
  const [audits, setAudits] = useState<AuditRecord[]>([
    { id: 'aud-501', date: '۱۴۰۵/۰۳/۳۰', warehouseId: 'w-1', status: 'finalized', discrepanciesCount: 2 }
  ]);

  // Form states
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transferItemId, setTransferItemId] = useState('');
  const [transferFromWh, setTransferFromWh] = useState('w-1');
  const [transferToWh, setTransferToWh] = useState('w-2');
  const [transferQty, setTransferQty] = useState(1);
  const [transferRef, setTransferRef] = useState('');

  // Audit form states
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [auditWhId, setAuditWhId] = useState('w-1');
  const [auditQuantities, setAuditQuantities] = useState<Record<string, number>>({});

  // Responsive sidebar commands
  React.useEffect(() => {
    if (subTabAction && subTabAction.tab === 'warehousing') {
      if (subTabAction.action === 'new-transfer') {
        setActiveTab('movements');
        setIsTransferModalOpen(true);
      } else if (subTabAction.action === 'warehouses-list') {
        setActiveTab('warehouses');
      } else if (subTabAction.action === 'inventory-list') {
        setActiveTab('inventory');
      } else if (subTabAction.action === 'audit-start') {
        setActiveTab('audit');
        setIsAuditModalOpen(true);
      }
      if (setSubTabAction) {
        setSubTabAction(null);
      }
    }
  }, [subTabAction]);

  const formatNumber = (val: number) => val.toLocaleString('fa-IR');

  const handleCreateTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transferItemId || transferFromWh === transferToWh) return;

    const item = items.find(i => i.id === transferItemId);
    if (!item) return;

    if (item.stock < transferQty) {
      alert(`موجودی انبار مبدا کافی نیست! موجودی فعلی: ${formatNumber(item.stock)}`);
      return;
    }

    // Register movement
    const newMvt: StockMovement = {
      id: 'sm-' + Date.now(),
      itemId: transferItemId,
      itemName: item.name,
      fromWarehouseId: transferFromWh,
      toWarehouseId: transferToWh,
      qty: transferQty,
      date: '۱۴۰۵/۰۴/' + String(new Date().getDate()).padStart(2, '0'),
      type: 'transfer',
      refNumber: transferRef || 'TR-' + Math.floor(10000 + Math.random() * 90000)
    };

    setMovements([newMvt, ...movements]);
    setIsTransferModalOpen(false);

    // Note: Stock on item itself remains same because it's just a warehouse transfer, 
    // but in a multi-warehouse system we'd track per warehouse. Here we show notification.
    alert(`حواله انتقال بین انبار ثبت شد. مقدار ${formatNumber(transferQty)} واحد کالا انتقال یافت.`);
  };

  const handleStartAudit = () => {
    // Populate quantities
    const initialQuants: Record<string, number> = {};
    items.filter(i => !i.isService).forEach(item => {
      initialQuants[item.id] = item.stock;
    });
    setAuditQuantities(initialQuants);
    setIsAuditModalOpen(true);
  };

  const handleSaveAudit = (e: React.FormEvent) => {
    e.preventDefault();

    let diffsCount = 0;
    const updatedItems = items.map(item => {
      if (item.isService) return item;
      const count = auditQuantities[item.id];
      if (count !== undefined && count !== item.stock) {
        diffsCount++;
        return { ...item, stock: count };
      }
      return item;
    });

    setItems(updatedItems);

    const newAudit: AuditRecord = {
      id: 'aud-' + Date.now().toString().slice(-4),
      date: '۱۴۰۵/۰۴/' + String(new Date().getDate()).padStart(2, '0'),
      warehouseId: auditWhId,
      status: 'finalized',
      discrepanciesCount: diffsCount
    };

    setAudits([newAudit, ...audits]);
    setIsAuditModalOpen(false);
    alert(`انبارگردانی نهایی شد! کاردکس کالا اصلاح گردید. تعداد ${formatNumber(diffsCount)} مورد مغایرت شناسایی و تعدیل شد.`);
  };

  return (
    <div className="space-y-6">
      
      {/* Sub tabs header */}
      <div className="flex border-b border-slate-200/40 pb-px print:hidden">
        <button
          onClick={() => setActiveTab('inventory')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'inventory' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Layers size={14} />
          موجودی زنده کالاها
        </button>
        <button
          onClick={() => setActiveTab('movements')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'movements' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Shuffle size={14} />
          حواله ها و نقل و انتقالات
        </button>
        <button
          onClick={() => setActiveTab('warehouses')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'warehouses' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Boxes size={14} />
          تعریف انبارها
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'audit' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <ClipboardCheck size={14} />
          انبارگردانی دوره‌ای
        </button>
      </div>

      {/* INVENTORY TAB */}
      {activeTab === 'inventory' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-slate-700">وضعیت موجودی فیزیکی و ارزش کالاها</h3>
            <div className="flex gap-2">
              <span className="bg-emerald-50 text-emerald-700 font-black text-[9px] px-2.5 py-1 rounded-lg flex items-center gap-1 border border-emerald-100">
                <ShieldCheck size={12} />
                تطبیق کاردکس با انبار مرکزی
              </span>
            </div>
          </div>

          <div className="bg-white border border-slate-100 rounded-3xl shadow-xs overflow-hidden">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-100 text-slate-500 font-bold">
                <tr>
                  <th className="p-4">کد کالا</th>
                  <th className="p-4">شرح کالا</th>
                  <th className="p-4">واحد سنجش</th>
                  <th className="p-4">موجودی فعلی</th>
                  <th className="p-4">آستانه هشدار کسری</th>
                  <th className="p-4">ارزیابی وضعیت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {items.filter(i => !i.isService).map(item => {
                  const isLow = item.stock <= 5; // Suppose 5 is critical threshold
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/40">
                      <td className="p-4 font-mono font-black text-slate-400">{item.code}</td>
                      <td className="p-4 font-bold text-slate-800">{item.name}</td>
                      <td className="p-4 text-slate-500">{item.unit}</td>
                      <td className="p-4 font-mono font-bold text-slate-700">{formatNumber(item.stock)}</td>
                      <td className="p-4 font-mono text-slate-400">{formatNumber(5)}</td>
                      <td className="p-4">
                        {isLow ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-black text-rose-600 bg-rose-50 px-2 py-1 rounded-lg">
                            <AlertTriangle size={11} />
                            کسری بحرانی
                          </span>
                        ) : (
                          <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">مطلوب</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MOVEMENTS TAB */}
      {activeTab === 'movements' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-slate-700">لیست حواله های خروجی و رسیدهای ورودی انبار</h3>
            <button
              onClick={() => setIsTransferModalOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold px-3 py-2 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm shadow-blue-100"
            >
              <Plus size={14} />
              حواله انتقال جدید
            </button>
          </div>

          <div className="bg-white border border-slate-100 rounded-3xl shadow-xs overflow-hidden">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-100 text-slate-500 font-bold">
                <tr>
                  <th className="p-4">شماره حواله</th>
                  <th className="p-4">کالا</th>
                  <th className="p-4">نوع سند</th>
                  <th className="p-4">انبار مبدا</th>
                  <th className="p-4">انبار مقصد</th>
                  <th className="p-4">تعداد انتقال</th>
                  <th className="p-4">تاریخ ثبت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {movements.map(mvt => (
                  <tr key={mvt.id} className="hover:bg-slate-50/40">
                    <td className="p-4 font-mono font-black text-slate-800">{mvt.refNumber}</td>
                    <td className="p-4 font-bold">{mvt.itemName}</td>
                    <td className="p-4">
                      <span className="bg-blue-50 text-blue-700 font-bold text-[9px] px-2 py-0.5 rounded-md">
                        انتقال بین انبار
                      </span>
                    </td>
                    <td className="p-4 text-slate-500">
                      {warehouses.find(w => w.id === mvt.fromWarehouseId)?.name || 'مبدا'}
                    </td>
                    <td className="p-4 text-slate-500">
                      {warehouses.find(w => w.id === mvt.toWarehouseId)?.name || 'مقصد'}
                    </td>
                    <td className="p-4 font-mono font-bold text-slate-700">{formatNumber(mvt.qty)}</td>
                    <td className="p-4 font-mono text-slate-400">{mvt.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* New Transfer Modal */}
          {isTransferModalOpen && (
            <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
              <div className="bg-white border border-slate-100 rounded-3xl w-full max-w-md shadow-2xl p-6 text-right">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                  <h3 className="font-black text-slate-800 text-sm">ثبت حواله انتقال بین انبار</h3>
                  <button onClick={() => setIsTransferModalOpen(false)} className="text-slate-400 hover:text-slate-600 text-lg cursor-pointer">×</button>
                </div>

                <form onSubmit={handleCreateTransfer} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1">انتخاب کالای ارسالی</label>
                    <select
                      required
                      value={transferItemId}
                      onChange={(e) => setTransferItemId(e.target.value)}
                      className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-semibold"
                    >
                      <option value="">انتخاب کالا...</option>
                      {items.filter(i => !i.isService).map(item => (
                        <option key={item.id} value={item.id}>{item.name} (موجودی: {formatNumber(item.stock)})</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 mb-1">از انبار مبدا</label>
                      <select
                        value={transferFromWh}
                        onChange={(e) => setTransferFromWh(e.target.value)}
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-semibold"
                      >
                        {warehouses.map(wh => (
                          <option key={wh.id} value={wh.id}>{wh.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 mb-1">به انبار مقصد</label>
                      <select
                        value={transferToWh}
                        onChange={(e) => setTransferToWh(e.target.value)}
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-semibold"
                      >
                        {warehouses.map(wh => (
                          <option key={wh.id} value={wh.id}>{wh.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 mb-1">تعداد انتقال</label>
                      <input
                        type="number"
                        required
                        min="1"
                        value={transferQty}
                        onChange={(e) => setTransferQty(Number(e.target.value))}
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 mb-1">شماره مرجع حواله</label>
                      <input
                        type="text"
                        value={transferRef}
                        onChange={(e) => setTransferRef(e.target.value)}
                        placeholder="اختیاری"
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-mono"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setIsTransferModalOpen(false)}
                      className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-50 rounded-xl cursor-pointer"
                    >
                      انصراف
                    </button>
                    <button
                      type="submit"
                      className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-black px-4 py-2 rounded-xl cursor-pointer"
                    >
                      ثبت حواله انتقال
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* WAREHOUSES TAB */}
      {activeTab === 'warehouses' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {warehouses.map(wh => (
            <div key={wh.id} className="bg-white border border-slate-100 rounded-3xl p-5 shadow-xs relative">
              {wh.isMain && (
                <span className="absolute top-4 left-4 bg-emerald-50 text-emerald-700 text-[8px] font-black px-2 py-0.5 rounded-md">
                  انبار پیش‌فرض
                </span>
              )}
              <h4 className="font-black text-xs text-slate-800">{wh.name}</h4>
              <p className="text-[10px] text-slate-400 mt-1 font-mono">{wh.code}</p>

              <div className="mt-4 pt-3 border-t border-slate-50 text-[11px] text-slate-500 space-y-1">
                <p>موقعیت: {wh.location}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* AUDIT TAB */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-slate-700">تاریخچه انبارگردانی دوره‌ای و تعدیلات</h3>
            <button
              onClick={handleStartAudit}
              className="bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold px-3 py-2 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm shadow-blue-100"
            >
              <ClipboardCheck size={14} />
              شروع انبارگردانی جدید
            </button>
          </div>

          <div className="bg-white border border-slate-100 rounded-3xl shadow-xs overflow-hidden">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-100 text-slate-500 font-bold">
                <tr>
                  <th className="p-4">کد دوره</th>
                  <th className="p-4">تاریخ اجرا</th>
                  <th className="p-4">انبار هدف</th>
                  <th className="p-4">تعداد مغایرت‌های تعدیل‌شده</th>
                  <th className="p-4">وضعیت سند</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {audits.map(aud => (
                  <tr key={aud.id} className="hover:bg-slate-50/40">
                    <td className="p-4 font-mono font-black text-slate-800">{aud.id}</td>
                    <td className="p-4 font-mono text-slate-500">{aud.date}</td>
                    <td className="p-4 text-slate-700">
                      {warehouses.find(w => w.id === aud.warehouseId)?.name || 'انبار'}
                    </td>
                    <td className="p-4 font-mono font-bold text-rose-600">{formatNumber(aud.discrepanciesCount)} مورد</td>
                    <td className="p-4">
                      <span className="bg-emerald-50 text-emerald-700 text-[9px] font-black px-2.5 py-1 rounded-lg border border-emerald-100">
                        نهایی و تعدیل شده
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Audit Working Modal */}
          {isAuditModalOpen && (
            <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
              <div className="bg-white border border-slate-100 rounded-3xl w-full max-w-lg shadow-2xl p-6 text-right max-h-[80vh] overflow-y-auto">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                  <h3 className="font-black text-slate-800 text-sm">فرم شمارش انبارگردانی</h3>
                  <button onClick={() => setIsAuditModalOpen(false)} className="text-slate-400 hover:text-slate-600 text-lg cursor-pointer">×</button>
                </div>

                <form onSubmit={handleSaveAudit} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1">انبار هدف شمارش</label>
                    <select
                      value={auditWhId}
                      onChange={(e) => setAuditWhId(e.target.value)}
                      className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-semibold"
                    >
                      {warehouses.map(wh => (
                        <option key={wh.id} value={wh.id}>{wh.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-3 pt-3 border-t border-slate-50">
                    <span className="text-[10px] font-bold text-slate-400 block mb-2">ثبت مقادیر واقعی شمارش شده:</span>
                    {items.filter(i => !i.isService).map(item => (
                      <div key={item.id} className="flex items-center justify-between bg-slate-50/40 p-2 rounded-xl border border-slate-50">
                        <div>
                          <span className="text-xs font-bold text-slate-800">{item.name}</span>
                          <span className="text-[9px] text-slate-400 block font-mono">سیستمی فعلی: {formatNumber(item.stock)}</span>
                        </div>
                        <div className="w-24">
                          <input
                            type="number"
                            min="0"
                            value={auditQuantities[item.id] !== undefined ? auditQuantities[item.id] : item.stock}
                            onChange={(e) => {
                              const updated = { ...auditQuantities };
                              updated[item.id] = Number(e.target.value);
                              setAuditQuantities(updated);
                            }}
                            className="w-full text-xs bg-white border border-slate-100 p-2 rounded-lg text-center font-mono font-black"
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setIsAuditModalOpen(false)}
                      className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-50 rounded-xl cursor-pointer"
                    >
                      انصراف
                    </button>
                    <button
                      type="submit"
                      className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-black px-4 py-2 rounded-xl cursor-pointer"
                    >
                      ثبت نهایی و تعدیل خودکار کاردکس
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

    </div>
  );
}
