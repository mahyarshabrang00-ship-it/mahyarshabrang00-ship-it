/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Contact, 
  BankAccount, 
  Payment, 
  PaymentItem, 
  Project, 
  Transaction,
  Invoice
} from '../types';
import { 
  Plus, 
  Trash2, 
  Edit3, 
  Eye, 
  Search, 
  Calendar, 
  Check, 
  X, 
  ArrowRight, 
  Settings, 
  CheckCircle, 
  Info,
  ChevronLeft,
  ChevronRight,
  MoreHorizontal,
  User,
  List,
  FolderPlus,
  CreditCard
} from 'lucide-react';

interface PaymentsProps {
  contacts: Contact[];
  setContacts: React.Dispatch<React.SetStateAction<Contact[]>>;
  banks: BankAccount[];
  setBanks: React.Dispatch<React.SetStateAction<BankAccount[]>>;
  payments: Payment[];
  setPayments: React.Dispatch<React.SetStateAction<Payment[]>>;
  projects: Project[];
  setProjects: React.Dispatch<React.SetStateAction<Project[]>>;
  frequentDescriptions: string[];
  setFrequentDescriptions: React.Dispatch<React.SetStateAction<string[]>>;
  subTabAction: { tab: string; action: string; payload?: any } | null;
  setSubTabAction: React.Dispatch<React.SetStateAction<{ tab: string; action: string; payload?: any } | null>>;
  invoices: Invoice[];
  setInvoices: React.Dispatch<React.SetStateAction<Invoice[]>>;
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
}

export default function Payments({
  contacts,
  setContacts,
  banks,
  setBanks,
  payments,
  setPayments,
  projects,
  setProjects,
  frequentDescriptions,
  setFrequentDescriptions,
  subTabAction,
  setSubTabAction,
  invoices,
  setInvoices,
  transactions,
  setTransactions
}: PaymentsProps) {
  
  // Tab/View control: 'list' or 'form'
  const [viewMode, setViewMode] = useState<'list' | 'form'>('list');
  const [listTab, setListTab] = useState<'all' | 'items'>('all');

  // Multi-select for list
  const [selectedPaymentIds, setSelectedPaymentIds] = useState<string[]>([]);

  // Modals state
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [isFreqDescOpen, setIsFreqDescOpen] = useState(false);
  const [isQuickContactOpen, setIsQuickContactOpen] = useState(false);
  const [viewDetailPayment, setViewDetailPayment] = useState<Payment | null>(null);

  // Quick Project Form State
  const [newProjName, setNewProjName] = useState('');
  const [newProjActive, setNewProjActive] = useState(true);
  const [newProjDefault, setNewProjDefault] = useState(false);

  // Quick Contact Form State
  const [quickContactName, setQuickContactName] = useState('');
  const [quickContactPhone, setQuickContactPhone] = useState('');
  const [quickContactType, setQuickContactType] = useState<'customer' | 'supplier' | 'employee' | 'shareholder'>('supplier');

  // Frequent Description State
  const [newFreqDesc, setNewFreqDesc] = useState('');

  // FORM STATE for single/multi-item Payments
  const [paymentId, setPaymentId] = useState<string | null>(null);
  const [isAutoNum, setIsAutoNum] = useState(true);
  const [paymentNum, setPaymentNum] = useState('');
  const [accountingDoc, setAccountingDoc] = useState('');
  const [paymentDate, setPaymentDate] = useState(() => {
    return '۱۴۰۵/۰۴/۱۷'; // Default matching current Persian date in screenshot
  });
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [selectedCurrency, setSelectedCurrency] = useState('IRR - ریال ایران');
  const [globalDesc, setGlobalDesc] = useState('حواله پرداخت');
  const [selectedBankId, setSelectedBankId] = useState('b1'); // source account

  // Payment items list
  const [formItems, setFormItems] = useState<PaymentItem[]>([
    { id: 'item_1', contactId: '', contactName: '', amount: 0, description: 'حواله پرداخت' }
  ]);

  // Filters state for column-wise searching
  const [filterNum, setFilterNum] = useState('');
  const [filterDoc, setFilterDoc] = useState('');
  const [filterDate, setFilterDate] = useState('');
  const [filterContact, setFilterContact] = useState('');
  const [filterDesc, setFilterDesc] = useState('');
  const [filterProj, setFilterProj] = useState('');
  const [filterAmount, setFilterAmount] = useState('');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Currencies list matching screenshot
  const currencies = [
    'IRR - ریال ایران',
    'AED - درهم امارات متحدهٔ عربی',
    'CAD - دلار کانادا',
    'EUR - یورو',
    'OMR - ریال عمان',
    'USD - دلار امریکا'
  ];

  // Handle external sidebar sub-navigation
  useEffect(() => {
    if (subTabAction && subTabAction.tab === 'payments') {
      if (subTabAction.action === 'add-payment') {
        // Reset and open form
        setPaymentId(null);
        setIsAutoNum(true);
        setPaymentNum('');
        setAccountingDoc('');
        setGlobalDesc('حواله پرداخت');
        setSelectedProjectId('');
        setSelectedCurrency('IRR - ریال ایران');
        setFormItems([{ id: 'item_1', contactId: '', contactName: '', amount: 0, description: 'حواله پرداخت' }]);
        setViewMode('form');
      } else if (subTabAction.action === 'list-payments') {
        setViewMode('list');
      }
      setSubTabAction(null);
    }
  }, [subTabAction]);

  // Format Helper
  const formatMoney = (val: number) => {
    return val.toLocaleString('fa-IR');
  };

  // Generate next automatic payment number
  const getNextPaymentNum = () => {
    if (payments.length === 0) return '۲۰Ax'; // Start clean with custom pattern
    const numbers = payments
      .map(p => parseInt(p.number.replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))))
      .filter(n => !isNaN(n));
    if (numbers.length === 0) return '۲۰۰۱';
    const nextVal = Math.max(...numbers) + 1;
    return nextVal.toString().replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d)]);
  };

  const getNextDocNum = () => {
    if (payments.length === 0) return '۴';
    const docs = payments
      .map(p => parseInt(p.accountingDocNo.replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))))
      .filter(n => !isNaN(n));
    if (docs.length === 0) return '۴';
    const nextVal = Math.max(...docs) + 2;
    return nextVal.toString().replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d)]);
  };

  // Create Project
  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjName.trim()) return;

    const newProj: Project = {
      id: 'p_' + Date.now(),
      name: newProjName,
      isActive: newProjActive,
      isDefault: newProjDefault
    };

    if (newProjDefault) {
      setProjects(projects.map(p => ({ ...p, isDefault: false })).concat(newProj));
    } else {
      setProjects([...projects, newProj]);
    }

    setSelectedProjectId(newProj.id);
    setNewProjName('');
    setNewProjActive(true);
    setNewProjDefault(false);
    setIsProjectModalOpen(false);
  };

  // Quick Create Contact
  const handleQuickCreateContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickContactName.trim()) return;

    const newContact: Contact = {
      id: 'c_' + Date.now(),
      code: String(contacts.length + 1).padStart(5, '0'),
      name: quickContactName,
      category: quickContactType === 'shareholder' ? 'سهامداران' : quickContactType === 'employee' ? 'کارمندان' : 'مشتری',
      type: quickContactType === 'customer' ? 'customer' : quickContactType === 'supplier' ? 'supplier' : quickContactType === 'employee' ? 'employee' : 'shareholder',
      phone: quickContactPhone,
      balance: 0,
      email: '',
      address: '',
      nationalId: ''
    };

    setContacts([...contacts, newContact]);
    setQuickContactName('');
    setQuickContactPhone('');
    setIsQuickContactOpen(false);
  };

  // Create Frequent Description
  const handleAddFreqDesc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFreqDesc.trim()) return;
    if (!frequentDescriptions.includes(newFreqDesc.trim())) {
      setFrequentDescriptions([...frequentDescriptions, newFreqDesc.trim()]);
    }
    setNewFreqDesc('');
  };

  // Delete Frequent Description
  const handleDeleteFreqDesc = (desc: string) => {
    setFrequentDescriptions(frequentDescriptions.filter(d => d !== desc));
  };

  // Form item operations
  const addFormItem = () => {
    const nextId = 'item_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4);
    setFormItems([...formItems, { id: nextId, contactId: '', contactName: '', amount: 0, description: globalDesc }]);
  };

  const removeFormItem = (id: string) => {
    if (formItems.length === 1) {
      alert('حداقل یک آیتم برای سند پرداخت الزامی است.');
      return;
    }
    setFormItems(formItems.filter(item => item.id !== id));
  };

  const updateFormItem = (id: string, field: keyof PaymentItem, value: any) => {
    setFormItems(formItems.map(item => {
      if (item.id === id) {
        if (field === 'contactId') {
          const contact = contacts.find(c => c.id === value);
          return { ...item, contactId: value, contactName: contact ? contact.name : '' };
        }
        return { ...item, [field]: value };
      }
      return item;
    }));
  };

  // Submit main payment form
  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();

    if (formItems.some(item => !item.contactId)) {
      alert('لطفاً شخص مربوط به تمامی ردیف‌ها را انتخاب کنید.');
      return;
    }

    if (formItems.some(item => item.amount <= 0)) {
      alert('مبلغ تمامی ردیف‌ها باید بیشتر از صفر باشد.');
      return;
    }

    const finalNum = isAutoNum ? getNextPaymentNum() : (paymentNum || '۲۰' + Date.now().toString().substr(-2));
    const finalDoc = accountingDoc || getNextDocNum();
    const projectObj = projects.find(p => p.id === selectedProjectId);

    const total = formItems.reduce((acc, curr) => acc + curr.amount, 0);

    const newPayment: Payment = {
      id: paymentId || 'pay_' + Date.now(),
      number: finalNum,
      accountingDocNo: finalDoc,
      date: paymentDate,
      project: projectObj ? projectObj.name : '',
      currency: selectedCurrency,
      description: globalDesc,
      items: formItems,
      totalAmount: total,
      accountName: 'حساب های پرداختنی'
    };

    // Reverse old values if editing
    if (paymentId) {
      const oldPay = payments.find(p => p.id === paymentId);
      if (oldPay) {
        // Reverse contact balances (payment increases contact balance so reversal decreases it)
        setContacts(prev => prev.map(c => {
          const matchingOldItem = oldPay.items.find(item => item.contactId === c.id);
          if (matchingOldItem) {
            return { ...c, balance: c.balance - matchingOldItem.amount };
          }
          return c;
        }));

        // Reverse bank balance (payment decreases bank so reversal increases it)
        setBanks(prev => prev.map(b => {
          if (b.id === selectedBankId) {
            return { ...b, balance: b.balance + oldPay.totalAmount };
          }
          return b;
        }));

        // Delete from transactions
        setTransactions(prev => prev.filter(tx => tx.category === `پرداخت #${oldPay.number}`));
      }
    }

    // Apply adjustments
    // 1. Update Contact Balances: Payment increases contact balance (we are paying them, reducing our liability / increasing their debt)
    setContacts(prev => prev.map(c => {
      const itemsForContact = formItems.filter(item => item.contactId === c.id);
      if (itemsForContact.length > 0) {
        const sumAllocated = itemsForContact.reduce((sum, item) => sum + item.amount, 0);
        return { ...c, balance: c.balance + sumAllocated };
      }
      return c;
    }));

    // 2. Update source bank balance (decreases)
    setBanks(prev => prev.map(b => {
      if (b.id === selectedBankId) {
        return { ...b, balance: b.balance - total };
      }
      return b;
    }));

    // 3. Register transaction
    const bankObj = banks.find(b => b.id === selectedBankId);
    const newTx: Transaction = {
      id: 't_pay_' + Date.now(),
      date: paymentDate,
      type: 'payment',
      amount: total,
      fromId: selectedBankId,
      fromName: bankObj ? bankObj.name : '',
      toId: formItems[0]?.contactId || 'external',
      toName: formItems.map(item => item.contactName).join(' و '),
      description: globalDesc + ` (پرداخت #${finalNum})`,
      refNumber: finalDoc,
      category: `پرداخت #${finalNum}`
    };

    setTransactions([newTx, ...transactions]);

    if (paymentId) {
      setPayments(payments.map(p => p.id === paymentId ? newPayment : p));
    } else {
      setPayments([newPayment, ...payments]);
    }

    setViewMode('list');
    setSelectedPaymentIds([]);
  };

  // Delete Payments
  const handleDeleteSelected = () => {
    if (selectedPaymentIds.length === 0) return;
    if (confirm(`آیا مطمئن هستید که می‌خواهید تعداد ${selectedPaymentIds.length} سند پرداخت انتخابی را حذف کنید؟ مانده‌ها و معین‌های مالی معکوس خواهند شد.`)) {
      
      let updatedContacts = [...contacts];
      let updatedBanks = [...banks];
      let updatedTxs = [...transactions];

      selectedPaymentIds.forEach(id => {
        const pay = payments.find(p => p.id === id);
        if (pay) {
          // Reverse contacts
          pay.items.forEach(item => {
            updatedContacts = updatedContacts.map(c => {
              if (c.id === item.contactId) {
                return { ...c, balance: c.balance - item.amount };
              }
              return c;
            });
          });

          // Reverse banks
          updatedBanks = updatedBanks.map(b => {
            if (b.id === selectedBankId) {
              return { ...b, balance: b.balance + pay.totalAmount };
            }
            return b;
          });

          // Filter transactions
          updatedTxs = updatedTxs.filter(tx => tx.category !== `پرداخت #${pay.number}`);
        }
      });

      setContacts(updatedContacts);
      setBanks(updatedBanks);
      setTransactions(updatedTxs);
      setPayments(payments.filter(p => !selectedPaymentIds.includes(p.id)));
      setSelectedPaymentIds([]);
    }
  };

  // Edit Payment
  const handleEditSelected = () => {
    if (selectedPaymentIds.length !== 1) return;
    const pay = payments.find(p => p.id === selectedPaymentIds[0]);
    if (pay) {
      setPaymentId(pay.id);
      setIsAutoNum(false);
      setPaymentNum(pay.number);
      setAccountingDoc(pay.accountingDocNo);
      setPaymentDate(pay.date);
      setGlobalDesc(pay.description);
      setSelectedCurrency(pay.currency);
      const proj = projects.find(p => p.name === pay.project);
      setSelectedProjectId(proj ? proj.id : '');
      setFormItems(pay.items);
      setViewMode('form');
    }
  };

  const totalFormAmount = formItems.reduce((sum, item) => sum + item.amount, 0);

  // Filter payments
  const getFilteredPayments = () => {
    return payments.filter(p => {
      const matchNum = p.number.toLowerCase().includes(filterNum.toLowerCase());
      const matchDoc = p.accountingDocNo.toLowerCase().includes(filterDoc.toLowerCase());
      const matchDate = p.date.toLowerCase().includes(filterDate.toLowerCase());
      
      const allContactNames = p.items.map(i => i.contactName).join(' ');
      const matchContact = allContactNames.toLowerCase().includes(filterContact.toLowerCase());

      const matchDesc = p.description.toLowerCase().includes(filterDesc.toLowerCase());
      const matchProj = (p.project || '').toLowerCase().includes(filterProj.toLowerCase());
      
      const matchAmount = filterAmount ? p.totalAmount.toString().includes(filterAmount) : true;

      return matchNum && matchDoc && matchDate && matchContact && matchDesc && matchProj && matchAmount;
    });
  };

  const filteredPayments = getFilteredPayments();
  
  // Flatten items for "Items" list tab
  const flattenedItems = filteredPayments.flatMap((p, pIdx) => {
    return p.items.map((item, itemIdx) => ({
      paymentId: p.id,
      number: p.number,
      accountingDocNo: p.accountingDocNo,
      date: p.date,
      project: p.project,
      currency: p.currency,
      accountName: p.accountName || 'حساب های پرداختنی',
      contactName: item.contactName,
      contactId: item.contactId,
      description: item.description,
      amount: item.amount,
      invoiceNo: p.invoiceNo || (2000 + pIdx).toString()
    }));
  });

  // Pagination bounds
  const currentTotalItems = listTab === 'all' ? filteredPayments.length : flattenedItems.length;
  const totalPages = Math.ceil(currentTotalItems / itemsPerPage) || 1;
  const paginatedPayments = filteredPayments.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
  const paginatedItems = flattenedItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  // Toggle selection
  const handleToggleSelectAll = () => {
    if (selectedPaymentIds.length === filteredPayments.length) {
      setSelectedPaymentIds([]);
    } else {
      setSelectedPaymentIds(filteredPayments.map(p => p.id));
    }
  };

  const handleToggleSelectOne = (id: string) => {
    if (selectedPaymentIds.includes(id)) {
      setSelectedPaymentIds(selectedPaymentIds.filter(x => x !== id));
    } else {
      setSelectedPaymentIds([...selectedPaymentIds, id]);
    }
  };

  return (
    <div className="space-y-6" id="payments-module">
      
      {/* HEADER SECTION WITH NAVIGATION */}
      <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-100 shadow-xs print:hidden">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-rose-50 text-rose-600 rounded-xl">
            <CreditCard size={20} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="text-sm font-bold text-slate-800">
                {viewMode === 'form' ? 'ثبت پرداخت جدید (صندوق و بانک)' : 'دفتر خزانه‌داری - لیست پرداخت‌های مالی'}
              </h3>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">ثبت حواله نقدی، چک‌های صادره، فیش کارت به کارت و اسناد پرداختنی</p>
          </div>
        </div>

        {/* Action Toggle */}
        <div className="flex items-center gap-2">
          {viewMode === 'form' ? (
            <button 
              type="button"
              onClick={() => setViewMode('list')}
              className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 px-3.5 py-2 rounded-xl transition-all font-bold"
            >
              <ArrowRight size={14} />
              <span>بازگشت به لیست پرداخت‌ها</span>
            </button>
          ) : (
            <button 
              type="button"
              onClick={() => {
                setPaymentId(null);
                setIsAutoNum(true);
                setPaymentNum('');
                setAccountingDoc('');
                setGlobalDesc('حواله پرداخت');
                setSelectedProjectId('');
                setSelectedCurrency('IRR - ریال ایران');
                setFormItems([{ id: 'item_1', contactId: '', contactName: '', amount: 0, description: 'حواله پرداخت' }]);
                setViewMode('form');
              }}
              className="flex items-center gap-1.5 text-xs text-white bg-rose-600 hover:bg-rose-700 px-4 py-2 rounded-xl shadow-sm transition-all font-bold"
            >
              <Plus size={15} />
              <span>ثبت پرداخت جدید</span>
            </button>
          )}
        </div>
      </div>

      {/* ==================== FORM VIEW (ADD / EDIT) ==================== */}
      {viewMode === 'form' && (
        <form onSubmit={handleSubmitPayment} className="space-y-6">
          
          {/* Main Controls Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 text-xs font-bold text-slate-600">
              
              {/* Number (شماره) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-[11px]">شماره سند پرداخت</label>
                  <div className="flex items-center gap-1">
                    <input 
                      type="checkbox" 
                      id="auto-num-chk"
                      checked={isAutoNum} 
                      onChange={(e) => setIsAutoNum(e.target.checked)} 
                      className="rounded border-slate-300 text-rose-600 focus:ring-rose-500/20 w-3.5 h-3.5"
                    />
                    <label htmlFor="auto-num-chk" className="text-[10px] text-rose-600 cursor-pointer select-none">اتوماتیک</label>
                  </div>
                </div>
                <input 
                  type="text" 
                  disabled={isAutoNum}
                  value={isAutoNum ? getNextPaymentNum() : paymentNum}
                  onChange={(e) => setPaymentNum(e.target.value)}
                  className={`w-full px-3 py-2 border rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20 transition-all text-center font-mono ${
                    isAutoNum ? 'bg-slate-50 border-slate-100 text-slate-400' : 'bg-white border-slate-200 text-slate-700'
                  }`}
                  placeholder="مثال: ۲۰۰۱"
                />
              </div>

              {/* Date (تاریخ) */}
              <div>
                <label className="block mb-1.5 text-[11px]">تاریخ پرداخت</label>
                <div className="relative">
                  <input 
                    type="text" 
                    required
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                    className="w-full pl-3 pr-9 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20 transition-all text-center font-mono text-slate-700"
                    placeholder="۱۴۰۵/۰۴/۱۷"
                  />
                  <Calendar size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                </div>
              </div>

              {/* Project (پروژه) */}
              <div>
                <label className="block mb-1.5 text-[11px]">پروژه مربوطه</label>
                <div className="flex gap-1.5">
                  <select 
                    value={selectedProjectId}
                    onChange={(e) => setSelectedProjectId(e.target.value)}
                    className="flex-1 px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20 transition-all text-slate-700 font-medium"
                  >
                    <option value="">-- بدون انتخاب پروژه --</option>
                    {projects.map(p => (
                      <option key={p.id} value={p.id}>{p.name} {p.isDefault ? '(پیش‌فرض)' : ''}</option>
                    ))}
                  </select>
                  <button 
                    type="button"
                    onClick={() => setIsProjectModalOpen(true)}
                    className="p-2 text-emerald-600 hover:text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-xl transition-colors border border-emerald-100"
                    title="تعریف پروژه جدید"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>

              {/* Currency (واحد پول) */}
              <div>
                <label className="block mb-1.5 text-[11px]">واحد پول سند</label>
                <select 
                  value={selectedCurrency}
                  onChange={(e) => setSelectedCurrency(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20 transition-all text-slate-700 font-medium"
                >
                  {currencies.map(curr => (
                    <option key={curr} value={curr}>{curr}</option>
                  ))}
                </select>
              </div>

              {/* Global Description (شرح کلی) */}
              <div>
                <label className="block mb-1.5 text-[11px]">شرح کلی تراکنش</label>
                <div className="flex gap-1.5">
                  <input 
                    type="text" 
                    value={globalDesc}
                    onChange={(e) => {
                      setGlobalDesc(e.target.value);
                      setFormItems(formItems.map(item => ({ ...item, description: e.target.value })));
                    }}
                    className="flex-1 px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20 transition-all text-slate-700 font-medium"
                    placeholder="مثال: حواله پرداخت"
                  />
                  <button 
                    type="button"
                    onClick={() => setIsFreqDescOpen(true)}
                    className="p-2 text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-xl transition-colors border border-rose-100"
                    title="شرح های پرتکرار"
                  >
                    <List size={16} />
                  </button>
                </div>
              </div>

            </div>

            {/* Source Bank Selection */}
            <div className="pt-2 border-t border-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-2 text-slate-500">
                <Info size={14} className="text-rose-500 shrink-0" />
                <span>حساب مبدا خزانه‌داری را مشخص کنید تا وجوه بلافاصله پس از تایید از موجودی آن کسر گردد.</span>
              </div>
              <div className="flex items-center gap-2 font-bold text-slate-600 shrink-0">
                <span>برداشت از حساب خزانه:</span>
                <select 
                  value={selectedBankId}
                  onChange={(e) => setSelectedBankId(e.target.value)}
                  className="px-3 py-1.5 border border-slate-200 bg-slate-50 rounded-lg focus:outline-none"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>{b.name} ({b.type === 'bank' ? 'بانک' : 'صندوق'})</option>
                  ))}
                </select>
              </div>
            </div>

          </div>

          {/* Payment Items (شخص / مبلغ / شرح ردیف) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-700 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                <span>اقلام تفکیکی سند پرداخت</span>
              </h4>
              <button 
                type="button" 
                onClick={addFormItem}
                className="text-xs font-bold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1"
              >
                <Plus size={14} />
                <span>افزودن آیتم جدید</span>
              </button>
            </div>

            {/* Loop Form Items */}
            <div className="space-y-4">
              {formItems.map((item, index) => {
                const selectedContact = contacts.find(c => c.id === item.contactId);
                return (
                  <div 
                    key={item.id} 
                    className="relative bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-slate-300 transition-all space-y-4"
                  >
                    {/* Badge Index and Remove */}
                    <div className="flex items-center justify-between pb-3 border-b border-slate-100/60 text-xs">
                      <span className="bg-slate-100 text-slate-500 font-black px-2 py-0.5 rounded-md">آیتم {index + 1}</span>
                      <button 
                        type="button"
                        onClick={() => removeFormItem(item.id)}
                        className="text-rose-500 hover:text-rose-700 hover:bg-rose-50 p-1 rounded-lg transition-all"
                        title="حذف آیتم"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end text-xs font-bold text-slate-600">
                      
                      {/* Left side: Avatar and Contact Selector (5 cols) */}
                      <div className="md:col-span-5 flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full overflow-hidden bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0">
                          {selectedContact?.image ? (
                            <img src={selectedContact.image} alt={selectedContact.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            <User size={20} className="text-slate-400" />
                          )}
                        </div>

                        <div className="flex-1">
                          <label className="block mb-1.5 text-[11px]">انتخاب شخص / طرف حساب *</label>
                          <div className="flex gap-1.5">
                            <select 
                              required
                              value={item.contactId}
                              onChange={(e) => updateFormItem(item.id, 'contactId', e.target.value)}
                              className="flex-1 px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20 text-slate-700 font-bold"
                            >
                              <option value="">-- انتخاب شخص --</option>
                              {contacts.map(c => (
                                <option key={c.id} value={c.id}>{c.name} ({c.category})</option>
                              ))}
                            </select>
                            <button 
                              type="button"
                              onClick={() => {
                                setQuickContactType('supplier');
                                setIsQuickContactOpen(true);
                              }}
                              className="p-2 text-emerald-600 hover:text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-xl transition-colors border border-emerald-100"
                              title="شخص جدید"
                            >
                              <Plus size={16} />
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Middle: Amount (3 cols) */}
                      <div className="md:col-span-3">
                        <label className="block mb-1.5 text-[11px]">مبلغ پرداختی ({selectedCurrency.split(' - ')[1] || 'ریال'}) *</label>
                        <div className="relative">
                          <input 
                            type="number" 
                            required
                            min="100"
                            value={item.amount || ''}
                            onChange={(e) => updateFormItem(item.id, 'amount', Number(e.target.value))}
                            className="w-full pl-10 pr-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20 transition-all font-mono text-left text-slate-700"
                            placeholder="۰"
                            dir="ltr"
                          />
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[9px] text-slate-400 font-black">
                            {selectedCurrency.split(' - ')[0] || 'ریال'}
                          </span>
                        </div>
                        {item.amount > 0 && (
                          <div className="text-[10px] text-slate-400 mt-1 font-medium text-left">
                            {formatMoney(item.amount)} {selectedCurrency.split(' - ')[1] || 'ریال'}
                          </div>
                        )}
                      </div>

                      {/* Right: Item Description (4 cols) */}
                      <div className="md:col-span-4">
                        <label className="block mb-1.5 text-[11px]">بابت / شرح معین</label>
                        <div className="flex gap-1.5">
                          <input 
                            type="text" 
                            value={item.description}
                            onChange={(e) => updateFormItem(item.id, 'description', e.target.value)}
                            className="flex-1 px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500/20 transition-all text-slate-700 font-medium"
                            placeholder="بابت تسویه فاکتور خرید"
                          />
                          <button 
                            type="button"
                            onClick={() => {
                              setIsFreqDescOpen(true);
                            }}
                            className="p-2 text-slate-400 hover:text-slate-600 bg-slate-50 hover:bg-slate-100 rounded-xl transition-colors border border-slate-100"
                            title="انتخاب شرح پرتکرار"
                          >
                            <List size={15} />
                          </button>
                        </div>
                      </div>

                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Totals & Submission Block */}
          <div className="bg-rose-50/20 border border-rose-500/30 rounded-2xl p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            
            <div className="flex flex-wrap items-center gap-6 text-xs font-bold text-slate-700">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                <span>مجموع پرداختی:</span>
                <span className="text-base font-black text-rose-700 font-mono">
                  {formatMoney(totalFormAmount)} {selectedCurrency.split(' - ')[1] || 'ریال'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                <span>باقیمانده تراز:</span>
                <span className="text-slate-500 font-mono">۰ ریال</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 justify-end">
              <button 
                type="button"
                onClick={() => setViewMode('list')}
                className="text-xs text-slate-500 hover:text-slate-800 bg-slate-100 px-4 py-2.5 rounded-xl font-bold transition-all"
              >
                انصراف
              </button>
              <button 
                type="submit"
                className="text-xs text-white bg-rose-600 hover:bg-rose-700 px-6 py-2.5 rounded-xl font-black shadow-md shadow-rose-100 transition-all flex items-center gap-1.5"
              >
                <CheckCircle size={15} />
                <span>{paymentId ? 'ویرایش و بروزرسانی سند' : 'افزودن پرداخت'}</span>
              </button>
            </div>

          </div>

        </form>
      )}

      {/* ==================== LIST VIEW (PAYMENT LIST) ==================== */}
      {viewMode === 'list' && (
        <div className="space-y-4">
          
          {/* Main Action Bar and Filters */}
          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4 print:hidden">
            
            {/* View Mode Tabs (همه / آیتم ها) */}
            <div className="flex rounded-xl bg-slate-100 p-1 border border-slate-200 shrink-0 max-w-xs">
              <button 
                type="button"
                onClick={() => { setListTab('all'); setCurrentPage(1); }}
                className={`text-xs px-4 py-2 rounded-lg transition-all duration-200 font-black ${listTab === 'all' ? 'bg-white text-rose-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
              >
                همه رسیدها
              </button>
              <button 
                type="button"
                onClick={() => { setListTab('items'); setCurrentPage(1); }}
                className={`text-xs px-4 py-2 rounded-lg transition-all duration-200 font-black ${listTab === 'items' ? 'bg-white text-rose-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
              >
                آیتم‌های پرداختی
              </button>
            </div>

            {/* Quick action buttons on Left of list header */}
            <div className="flex flex-wrap items-center gap-2">
              
              <button 
                type="button"
                disabled={selectedPaymentIds.length === 0}
                onClick={handleDeleteSelected}
                className={`p-2 rounded-xl transition-all border ${
                  selectedPaymentIds.length > 0 
                    ? 'text-rose-600 bg-rose-50 border-rose-100 hover:bg-rose-100' 
                    : 'text-slate-300 bg-slate-50 border-slate-100 cursor-not-allowed'
                }`}
                title="حذف اسناد انتخابی"
              >
                <Trash2 size={16} />
              </button>

              <button 
                type="button"
                disabled={selectedPaymentIds.length !== 1}
                onClick={handleEditSelected}
                className={`p-2 rounded-xl transition-all border ${
                  selectedPaymentIds.length === 1 
                    ? 'text-amber-600 bg-amber-50 border-amber-100 hover:bg-amber-100' 
                    : 'text-slate-300 bg-slate-50 border-slate-100 cursor-not-allowed'
                }`}
                title="ویرایش سند انتخابی"
              >
                <Edit3 size={16} />
              </button>

              <button 
                type="button"
                disabled={selectedPaymentIds.length !== 1}
                onClick={() => {
                  const pay = payments.find(p => p.id === selectedPaymentIds[0]);
                  if (pay) setViewDetailPayment(pay);
                }}
                className={`p-2 rounded-xl transition-all border ${
                  selectedPaymentIds.length === 1 
                    ? 'text-rose-600 bg-rose-50 border-rose-100 hover:bg-rose-100' 
                    : 'text-slate-300 bg-slate-50 border-slate-100 cursor-not-allowed'
                }`}
                title="مشاهده جزئیات سند"
              >
                <Eye size={16} />
              </button>

              <div className="h-6 w-[1px] bg-slate-200/80 mx-1"></div>

              <button 
                type="button"
                onClick={() => {
                  setFilterNum('');
                  setFilterDoc('');
                  setFilterDate('');
                  setFilterContact('');
                  setFilterDesc('');
                  setFilterProj('');
                  setFilterAmount('');
                }}
                className="text-xs font-bold text-slate-500 hover:text-slate-800 px-3 py-2 rounded-xl bg-slate-100"
                title="پاکسازی فیلترها"
              >
                حذف فیلترها
              </button>

            </div>

          </div>

          {/* Grid Table for Payments */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse">
                <thead>
                  {/* Primary Headers */}
                  <tr className="bg-slate-50/80 border-b border-slate-100 text-slate-500 text-xs font-black">
                    <th className="p-4 w-10 text-center">
                      <input 
                        type="checkbox" 
                        checked={filteredPayments.length > 0 && selectedPaymentIds.length === filteredPayments.length}
                        onChange={handleToggleSelectAll}
                        className="rounded border-slate-300 text-rose-600 focus:ring-rose-500/20"
                      />
                    </th>
                    <th className="p-4 w-12 text-center">#</th>
                    <th className="p-4 w-20 text-center">شماره</th>
                    <th className="p-4 w-28 text-center">سند حسابداری</th>
                    <th className="p-4 w-28 text-center">تاریخ</th>
                    
                    {listTab === 'all' ? (
                      <>
                        <th className="p-4">حساب معین</th>
                        <th className="p-4">شخص طرف حساب</th>
                        <th className="p-4">شرح سند</th>
                        <th className="p-4 text-left w-36">مبلغ کل</th>
                        <th className="p-4 text-center">پروژه</th>
                      </>
                    ) : (
                      <>
                        <th className="p-4">حساب معین</th>
                        <th className="p-4">شخص</th>
                        <th className="p-4">بابت / شرح ردیف</th>
                        <th className="p-4 text-left w-36">مبلغ ردیف</th>
                        <th className="p-4 text-center">پروژه</th>
                        <th className="p-4 text-center">فاکتور</th>
                      </>
                    )}
                  </tr>

                  {/* Excel-like filter inputs row */}
                  <tr className="bg-slate-50/30 border-b border-slate-100 text-xs print:hidden">
                    <td className="p-2"></td>
                    <td className="p-2"></td>
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterNum}
                          onChange={(e) => { setFilterNum(e.target.value); setCurrentPage(1); }}
                          placeholder="جستجو..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-rose-500 text-center font-mono"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterDoc}
                          onChange={(e) => { setFilterDoc(e.target.value); setCurrentPage(1); }}
                          placeholder="جستجو..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-rose-500 text-center font-mono"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterDate}
                          onChange={(e) => { setFilterDate(e.target.value); setCurrentPage(1); }}
                          placeholder="تاریخ..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-rose-500 text-center font-mono"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>
                    <td className="p-2"></td>
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterContact}
                          onChange={(e) => { setFilterContact(e.target.value); setCurrentPage(1); }}
                          placeholder="شخص..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-rose-500 font-medium"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterDesc}
                          onChange={(e) => { setFilterDesc(e.target.value); setCurrentPage(1); }}
                          placeholder="شرح..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-rose-500 font-medium"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterAmount}
                          onChange={(e) => { setFilterAmount(e.target.value); setCurrentPage(1); }}
                          placeholder="مبلغ..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-rose-500 text-left font-mono"
                          dir="ltr"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>
                    <td className="p-2">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filterProj}
                          onChange={(e) => { setFilterProj(e.target.value); setCurrentPage(1); }}
                          placeholder="پروژه..."
                          className="w-full text-[10px] px-2 py-1 pr-6 border border-slate-200 rounded-md focus:outline-none focus:border-rose-500 font-medium"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>
                    {listTab === 'items' && <td className="p-2"></td>}
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100 text-xs font-bold text-slate-600">
                  {listTab === 'all' ? (
                    paginatedPayments.length === 0 ? (
                      <tr>
                        <td colSpan={10} className="p-8 text-center text-slate-400 font-medium">سند پرداختی یافت نشد.</td>
                      </tr>
                    ) : (
                      paginatedPayments.map((p, idx) => {
                        const isSelected = selectedPaymentIds.includes(p.id);
                        return (
                          <tr key={p.id} className={`hover:bg-slate-50/50 transition-colors ${isSelected ? 'bg-blue-50/10' : ''}`}>
                            <td className="p-4 text-center">
                              <input 
                                type="checkbox" 
                                checked={isSelected}
                                onChange={() => handleToggleSelectOne(p.id)}
                                className="rounded border-slate-300 text-rose-600 focus:ring-rose-500/20"
                              />
                            </td>
                            <td className="p-4 text-center text-slate-400 font-mono">{(currentPage - 1) * itemsPerPage + idx + 1}</td>
                            <td className="p-4 text-center font-mono text-slate-900">{p.number}</td>
                            <td className="p-4 text-center font-mono text-slate-500">{p.accountingDocNo}</td>
                            <td className="p-4 text-center font-mono text-slate-500">{p.date}</td>
                            <td className="p-4 text-slate-500">{p.accountName || 'حساب های پرداختنی'}</td>
                            <td className="p-4 font-black text-slate-800">
                              {p.items.map(item => item.contactName).join(' ، ')}
                            </td>
                            <td className="p-4 text-slate-500 font-medium">{p.description}</td>
                            <td className="p-4 text-left font-black text-rose-700 font-mono">
                              {formatMoney(p.totalAmount)} <span className="text-[10px] text-slate-400 font-medium">{p.currency.split(' - ')[1]}</span>
                            </td>
                            <td className="p-4 text-center">
                              <span className="bg-slate-100 text-slate-600 text-[10px] px-2 py-0.5 rounded-md">
                                {p.project || '--'}
                              </span>
                            </td>
                          </tr>
                        );
                      })
                    )
                  ) : (
                    paginatedItems.length === 0 ? (
                      <tr>
                        <td colSpan={11} className="p-8 text-center text-slate-400 font-medium">آیتم پرداختی یافت نشد.</td>
                      </tr>
                    ) : (
                      paginatedItems.map((item, idx) => {
                        const isSelected = selectedPaymentIds.includes(item.paymentId);
                        return (
                          <tr key={`${item.paymentId}_${idx}`} className={`hover:bg-slate-50/50 transition-colors ${isSelected ? 'bg-blue-50/10' : ''}`}>
                            <td className="p-4 text-center">
                              <input 
                                type="checkbox" 
                                checked={isSelected}
                                onChange={() => handleToggleSelectOne(item.paymentId)}
                                className="rounded border-slate-300 text-rose-600 focus:ring-rose-500/20"
                              />
                            </td>
                            <td className="p-4 text-center text-slate-400 font-mono">{(currentPage - 1) * itemsPerPage + idx + 1}</td>
                            <td className="p-4 text-center font-mono text-slate-900">{item.number}</td>
                            <td className="p-4 text-center font-mono text-slate-500">{item.accountingDocNo}</td>
                            <td className="p-4 text-center font-mono text-slate-500">{item.date}</td>
                            <td className="p-4 text-slate-500">{item.accountName}</td>
                            <td className="p-4 font-black text-slate-800">{item.contactName}</td>
                            <td className="p-4 text-slate-500 font-medium">{item.description}</td>
                            <td className="p-4 text-left font-black text-rose-700 font-mono">
                              {formatMoney(item.amount)} <span className="text-[10px] text-slate-400 font-medium">{item.currency.split(' - ')[1]}</span>
                            </td>
                            <td className="p-4 text-center">
                              <span className="bg-slate-100 text-slate-600 text-[10px] px-2 py-0.5 rounded-md">
                                {item.project || '--'}
                              </span>
                            </td>
                            <td className="p-4 text-center">
                              <span className="text-[10px] text-blue-600 hover:underline cursor-pointer font-mono">
                                #{item.invoiceNo}
                              </span>
                            </td>
                          </tr>
                        );
                      })
                    )
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls */}
            <div className="bg-slate-50/60 p-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs font-bold text-slate-500 print:hidden">
              <div className="flex items-center gap-2">
                <span>نمایش صفحه</span>
                <span className="text-slate-800 font-mono">{currentPage}</span>
                <span>از</span>
                <span className="text-slate-800 font-mono">{totalPages}</span>
                <span className="text-slate-400 font-medium">({currentTotalItems} ردیف پیدا شد)</span>
              </div>

              <div className="flex items-center gap-2">
                <button 
                  type="button"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <ChevronRight size={15} />
                </button>
                
                <div className="flex items-center gap-1 font-mono">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                    <button 
                      type="button"
                      key={page}
                      onClick={() => setCurrentPage(page)}
                      className={`w-7 h-7 rounded-lg text-center transition-all ${
                        currentPage === page 
                          ? 'bg-rose-600 text-white shadow-xs' 
                          : 'bg-white border border-slate-200 hover:bg-slate-50 text-slate-600'
                      }`}
                    >
                      {page}
                    </button>
                  ))}
                </div>

                <button 
                  type="button"
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <ChevronLeft size={15} />
                </button>
              </div>

              <div className="flex items-center gap-1.5">
                <span>اندازه صفحه:</span>
                <select 
                  value={itemsPerPage} 
                  onChange={(e) => { setItemsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                  className="border border-slate-200 bg-white rounded-lg py-1 px-2 focus:outline-none"
                >
                  <option value={5}>۵ ردیف</option>
                  <option value={10}>۱۰ ردیف</option>
                  <option value={20}>۲۰ ردیف</option>
                  <option value={50}>۵۰ ردیف</option>
                </select>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* ==================== CREATE QUICK PROJECT MODAL ==================== */}
      {isProjectModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-100 p-5 space-y-4 animate-in zoom-in-95 duration-150">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-xs font-black text-slate-800">تعریف مرکز هزینه / پروژه جدید</h3>
              <button type="button" onClick={() => setIsProjectModalOpen(false)} className="text-slate-400 text-lg hover:text-slate-600">×</button>
            </div>

            <form onSubmit={handleCreateProject} className="space-y-4 text-xs font-bold text-slate-600">
              
              <div>
                <label className="block mb-1.5">عنوان کامل پروژه / قرارداد *</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: قرارداد بازسازی ونک"
                  value={newProjName}
                  onChange={(e) => setNewProjName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-between gap-4 p-2 bg-slate-50 rounded-xl border border-slate-100/60">
                <div className="flex items-center gap-2">
                  <input 
                    type="checkbox" 
                    id="proj-active-chk"
                    checked={newProjActive}
                    onChange={(e) => setNewProjActive(e.target.checked)}
                    className="rounded border-slate-300 text-rose-600 focus:ring-rose-500/20"
                  />
                  <label htmlFor="proj-active-chk" className="cursor-pointer select-none">وضعیت فعال باشد</label>
                </div>

                <div className="flex items-center gap-2">
                  <input 
                    type="checkbox" 
                    id="proj-default-chk"
                    checked={newProjDefault}
                    onChange={(e) => setNewProjDefault(e.target.checked)}
                    className="rounded border-slate-300 text-rose-600 focus:ring-rose-500/20"
                  />
                  <label htmlFor="proj-default-chk" className="cursor-pointer select-none">پروژه پیش‌فرض خزانه‌داری</label>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button type="button" onClick={() => setIsProjectModalOpen(false)} className="text-slate-500 px-3 py-1.5 font-bold">انصراف</button>
                <button type="submit" className="bg-rose-600 hover:bg-rose-700 text-white px-4 py-1.5 rounded-lg font-bold">ذخیره پروژه</button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* ==================== FREQUENT DESCRIPTION MODAL ==================== */}
      {isFreqDescOpen && (
        <div className="fixed inset-0 bg-slate-900/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-100 p-5 space-y-4 animate-in zoom-in-95 duration-150">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-xs font-black text-slate-800">بانک شرح‌های پرتکرار خزانه‌داری</h3>
              <button type="button" onClick={() => setIsFreqDescOpen(false)} className="text-slate-400 text-lg hover:text-slate-600">×</button>
            </div>

            {/* List current descriptions */}
            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {frequentDescriptions.map(desc => (
                <div key={desc} className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100 text-[11px] font-bold text-slate-700">
                  <button 
                    type="button" 
                    onClick={() => {
                      setGlobalDesc(desc);
                      setFormItems(formItems.map(item => ({ ...item, description: desc })));
                      setIsFreqDescOpen(false);
                    }}
                    className="flex-1 text-right hover:text-rose-600 transition-colors"
                  >
                    {desc}
                  </button>
                  <button 
                    type="button"
                    onClick={() => handleDeleteFreqDesc(desc)}
                    className="text-rose-500 hover:text-rose-700 p-1 rounded hover:bg-rose-50"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
            </div>

            {/* Quick add field */}
            <form onSubmit={handleAddFreqDesc} className="flex gap-2 pt-3 border-t border-slate-100">
              <input 
                type="text" 
                required
                placeholder="افزودن شرح پرتکرار جدید..."
                value={newFreqDesc}
                onChange={(e) => setNewFreqDesc(e.target.value)}
                className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold focus:outline-none"
              />
              <button type="submit" className="bg-rose-600 hover:bg-rose-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold">ثبت</button>
            </form>

            <div className="flex justify-end pt-2">
              <button type="button" onClick={() => setIsFreqDescOpen(false)} className="bg-slate-100 text-slate-600 text-xs px-4 py-1.5 rounded-xl font-bold">بستن</button>
            </div>

          </div>
        </div>
      )}

      {/* ==================== QUICK CREATE CONTACT MODAL ==================== */}
      {isQuickContactOpen && (
        <div className="fixed inset-0 bg-slate-900/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-100 p-5 space-y-4 animate-in zoom-in-95 duration-150">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-xs font-black text-slate-800">تعریف شخص جدید</h3>
              <button type="button" onClick={() => setIsQuickContactOpen(false)} className="text-slate-400 text-lg hover:text-slate-600">×</button>
            </div>

            <form onSubmit={handleQuickCreateContact} className="space-y-4 text-xs font-bold text-slate-600">
              
              <div>
                <label className="block mb-1.5">نام و نام خانوادگی / نام شرکت *</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: شرکت پترو مانی"
                  value={quickContactName}
                  onChange={(e) => setQuickContactName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
              </div>

              <div>
                <label className="block mb-1.5">شماره همراه</label>
                <input 
                  type="text" 
                  placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                  value={quickContactPhone}
                  onChange={(e) => setQuickContactPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none text-left font-mono"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block mb-1.5">دسته‌بندی اولیه</label>
                <select 
                  value={quickContactType}
                  onChange={(e) => setQuickContactType(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-200 bg-white rounded-xl focus:outline-none text-slate-700"
                >
                  <option value="supplier">تامین کننده</option>
                  <option value="customer">مشتری</option>
                  <option value="shareholder">سهامداران</option>
                  <option value="employee">کارمندان</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button type="button" onClick={() => setIsQuickContactOpen(false)} className="text-slate-500 px-3 py-1.5 font-bold">انصراف</button>
                <button type="submit" className="bg-rose-600 hover:bg-rose-700 text-white px-4 py-1.5 rounded-lg font-bold">ایجاد طرف حساب</button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* ==================== DETAILED PAYMENT DIALOG ==================== */}
      {viewDetailPayment && (
        <div className="fixed inset-0 bg-slate-900/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl border border-slate-100 p-6 space-y-6 animate-in zoom-in-95 duration-150">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                <CreditCard size={16} className="text-rose-600" />
                <span>نمایش اطلاعات سند پرداخت شماره {viewDetailPayment.number}</span>
              </h3>
              <button type="button" onClick={() => setViewDetailPayment(null)} className="text-slate-400 text-lg hover:text-slate-600">×</button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-bold text-slate-600">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="text-[10px] text-slate-400 mb-1">شماره سند</div>
                <div className="font-mono text-slate-800 text-sm">{viewDetailPayment.number}</div>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="text-[10px] text-slate-400 mb-1">سند حسابداری</div>
                <div className="font-mono text-slate-800 text-sm">{viewDetailPayment.accountingDocNo}</div>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="text-[10px] text-slate-400 mb-1">تاریخ ثبت</div>
                <div className="font-mono text-slate-800 text-sm">{viewDetailPayment.date}</div>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="text-[10px] text-slate-400 mb-1">واحد پول</div>
                <div className="text-slate-800 text-sm">{viewDetailPayment.currency}</div>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-800">اقلام تفکیکی سند پرداخت</h4>
              <div className="border border-slate-100 rounded-xl overflow-hidden text-xs">
                <table className="w-full text-right border-collapse">
                  <thead>
                    <tr className="bg-slate-50 text-slate-500 font-bold text-[11px] border-b border-slate-100">
                      <th className="p-3">#</th>
                      <th className="p-3">شخص طرف حساب</th>
                      <th className="p-3">بابت / شرح</th>
                      <th className="p-3 text-left">مبلغ پرداختی</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 font-medium">
                    {viewDetailPayment.items.map((item, idx) => (
                      <tr key={item.id}>
                        <td className="p-3 font-mono text-slate-400">{idx + 1}</td>
                        <td className="p-3 font-black text-slate-800">{item.contactName}</td>
                        <td className="p-3 text-slate-600">{item.description}</td>
                        <td className="p-3 text-left font-black text-rose-700 font-mono">
                          {formatMoney(item.amount)} {viewDetailPayment.currency.split(' - ')[1] || 'ریال'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold">
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400">پروژه:</span>
                <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md text-[10px]">
                  {viewDetailPayment.project || 'بدون پروژه'}
                </span>
              </div>
              <div className="text-sm font-black text-slate-800">
                <span>جمع کل سند:</span>
                <span className="text-base text-rose-700 font-mono mr-2">
                  {formatMoney(viewDetailPayment.totalAmount)} {viewDetailPayment.currency.split(' - ')[1] || 'ریال'}
                </span>
              </div>
            </div>

            <div className="flex justify-end">
              <button 
                type="button"
                onClick={() => setViewDetailPayment(null)} 
                className="bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold px-4 py-2 rounded-xl transition-all"
              >
                بستن پنجره
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
