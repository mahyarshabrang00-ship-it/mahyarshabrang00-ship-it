/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Contact, Invoice, BankAccount, Transaction, ItemService } from '../types';
import { FileBarChart2, FileText, Scale, Landmark, BarChart, ArrowDownRight, ArrowUpRight } from 'lucide-react';

interface ReportsProps {
  contacts: Contact[];
  invoices: Invoice[];
  banks: BankAccount[];
  transactions: Transaction[];
  items: ItemService[];
}

export default function Reports({
  contacts,
  invoices,
  banks,
  transactions,
  items
}: ReportsProps) {
  const [activeReport, setActiveReport] = useState<'pnl' | 'balance' | 'ledger'>('pnl');

  const formatMoney = (value: number) => {
    return Math.abs(value).toLocaleString('fa-IR') + ' تومان';
  };

  const formatNumber = (value: number) => {
    return value.toLocaleString('fa-IR');
  };

  // --- 1. Dynamic Profit & Loss Calculations ---
  const revenueSales = invoices
    .filter(inv => inv.type === 'sales' && inv.status !== 'draft')
    .reduce((sum, inv) => sum + inv.total, 0);

  // Cost of goods sold: let's estimate based on purchases
  const costOfPurchases = invoices
    .filter(inv => inv.type === 'purchase' && inv.status !== 'draft')
    .reduce((sum, inv) => sum + inv.total, 0);

  // Group expenses from cash register
  const generalExpenses = transactions
    .filter(t => t.type === 'payment' && t.toId === 'external' && t.category === 'هزینه‌های عمومی و اداری')
    .reduce((sum, t) => sum + t.amount, 0);

  const salariesExpense = transactions
    .filter(t => t.type === 'payment' && t.category === 'حقوق و دستمزد پرسنل')
    .reduce((sum, t) => sum + t.amount, 0);

  const rentExpense = transactions
    .filter(t => t.type === 'payment' && t.category === 'هزینه اجاره دفتر')
    .reduce((sum, t) => sum + t.amount, 0);

  const otherExpenses = transactions
    .filter(t => t.type === 'payment' && t.toId === 'external' && 
                 t.category !== 'هزینه‌های عمومی و اداری' && 
                 t.category !== 'حقوق و دستمزد پرسنل' && 
                 t.category !== 'هزینه اجاره دفتر' &&
                 t.category !== 'پرداخت به تامین‌کننده')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalOperatingExpenses = generalExpenses + salariesExpense + rentExpense + otherExpenses;
  const grossProfit = revenueSales - costOfPurchases;
  const netProfit = grossProfit - totalOperatingExpenses;


  // --- 2. Dynamic Balance Sheet Calculations ---
  // Assets
  const bankAndCashAsset = banks.reduce((sum, b) => sum + b.balance, 0);
  const accountsReceivableAsset = contacts.filter(c => c.balance > 0).reduce((sum, c) => sum + c.balance, 0);
  // Stock asset = sum of (stock qty * purchase price)
  const inventoryAsset = items.reduce((sum, item) => sum + (item.stock * item.purchasePrice), 0);
  const totalAssets = bankAndCashAsset + accountsReceivableAsset + inventoryAsset;

  // Liabilities
  const accountsPayableLiability = contacts.filter(c => c.balance < 0).reduce((sum, c) => sum + Math.abs(c.balance), 0);
  // Equity = Assets - Liabilities
  const shareholdersEquity = totalAssets - accountsPayableLiability;


  return (
    <div className="space-y-6">
      
      {/* Report selector tabs */}
      <div className="flex rounded-2xl bg-white p-1.5 border border-slate-100 shadow-xs max-w-md mx-auto">
        <button 
          onClick={() => setActiveReport('pnl')}
          className={`flex-1 flex items-center justify-center gap-2 text-xs py-3 rounded-xl font-bold transition-all duration-200 ${activeReport === 'pnl' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
        >
          <BarChart size={16} />
          <span>صورت سود و زیان</span>
        </button>
        <button 
          onClick={() => setActiveReport('balance')}
          className={`flex-1 flex items-center justify-center gap-2 text-xs py-3 rounded-xl font-bold transition-all duration-200 ${activeReport === 'balance' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
        >
          <Scale size={16} />
          <span>ترازنامه مالی</span>
        </button>
        <button 
          onClick={() => setActiveReport('ledger')}
          className={`flex-1 flex items-center justify-center gap-2 text-xs py-3 rounded-xl font-bold transition-all duration-200 ${activeReport === 'ledger' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
        >
          <FileText size={16} />
          <span>دفتر روزنامه کـل</span>
        </button>
      </div>

      {/* --- 1. PROFIT & LOSS REPORT VIEW --- */}
      {activeReport === 'pnl' && (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-xs p-6 max-w-3xl mx-auto space-y-6">
          
          <div className="text-center pb-4 border-b border-slate-100">
            <h3 className="text-base font-black text-slate-800">گزارش صورت سود و زیان</h3>
            <p className="text-[10px] text-slate-400 mt-1">از ابتدای سال مالی تا امروز • مقادیر بر حسب تومان</p>
          </div>

          <div className="space-y-4">
            
            {/* Revenues */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-900 bg-slate-50 p-2.5 rounded-lg">درآمدهای عملیاتی</h4>
              <div className="flex justify-between text-xs px-3 text-slate-600 font-medium">
                <span>فروش ناخالص کالا و خدمات</span>
                <span className="font-mono">{formatMoney(revenueSales)}</span>
              </div>
              <div className="border-t border-dashed border-slate-200 my-1"></div>
              <div className="flex justify-between text-xs font-bold px-3 text-slate-800">
                <span>جمع درآمدهای عملیاتی</span>
                <span className="font-mono text-emerald-600">{formatMoney(revenueSales)}</span>
              </div>
            </div>

            {/* Cost of sales */}
            <div className="space-y-2 pt-2">
              <h4 className="text-xs font-bold text-slate-900 bg-slate-50 p-2.5 rounded-lg">بهای تمام شده درآمدهای عملیاتی</h4>
              <div className="flex justify-between text-xs px-3 text-slate-600 font-medium">
                <span>خرید کالا و ملزومات مصرفی</span>
                <span className="font-mono">{formatMoney(costOfPurchases)}</span>
              </div>
              <div className="border-t border-dashed border-slate-200 my-1"></div>
              <div className="flex justify-between text-xs font-bold px-3 text-slate-800">
                <span>جمع بهای تمام شده</span>
                <span className="font-mono text-rose-600">- {formatMoney(costOfPurchases)}</span>
              </div>
            </div>

            {/* Gross Profit Block */}
            <div className="p-3 bg-slate-100/70 rounded-xl flex justify-between text-xs font-bold text-slate-800">
              <span>سود ناخالص عملیاتی (Gross Profit)</span>
              <span className={`font-mono ${grossProfit >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                {formatMoney(grossProfit)}
              </span>
            </div>

            {/* Operating Expenses */}
            <div className="space-y-2 pt-2">
              <h4 className="text-xs font-bold text-slate-900 bg-slate-50 p-2.5 rounded-lg">هزینه‌های عمومی، اداری و تشکیلاتی</h4>
              <div className="flex justify-between text-xs px-3 text-slate-600 font-medium">
                <span>هزینه‌های ملزومات آبدارخانه و اداری</span>
                <span className="font-mono">{formatMoney(generalExpenses)}</span>
              </div>
              <div className="flex justify-between text-xs px-3 text-slate-600 font-medium">
                <span>حقوق و دستمزد ناخالص پرسنل</span>
                <span className="font-mono">{formatMoney(salariesExpense)}</span>
              </div>
              <div className="flex justify-between text-xs px-3 text-slate-600 font-medium">
                <span>هزینه اجاره‌بهای دفتر شرکت</span>
                <span className="font-mono">{formatMoney(rentExpense)}</span>
              </div>
              <div className="flex justify-between text-xs px-3 text-slate-600 font-medium">
                <span>سایر هزینه‌های متفرقه عملیاتی</span>
                <span className="font-mono">{formatMoney(otherExpenses)}</span>
              </div>
              <div className="border-t border-dashed border-slate-200 my-1"></div>
              <div className="flex justify-between text-xs font-bold px-3 text-slate-800">
                <span>جمع هزینه‌های اداری و تشکیلاتی</span>
                <span className="font-mono text-rose-600">- {formatMoney(totalOperatingExpenses)}</span>
              </div>
            </div>

            {/* Net Profit Block */}
            <div className={`p-4 rounded-xl flex justify-between text-sm font-black border ${netProfit >= 0 ? 'bg-emerald-50 border-emerald-100 text-emerald-800' : 'bg-rose-50 border-rose-100 text-rose-800'}`}>
              <span>سود (زیان) خالص کل فعالیت (Net Profit)</span>
              <span className="font-mono">
                {netProfit < 0 ? 'زیان: ' : ''}{formatMoney(netProfit)}
              </span>
            </div>

          </div>

        </div>
      )}

      {/* --- 2. BALANCE SHEET REPORT VIEW --- */}
      {activeReport === 'balance' && (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-xs p-6 max-w-4xl mx-auto space-y-6">
          
          <div className="text-center pb-4 border-b border-slate-100">
            <h3 className="text-base font-black text-slate-800">ترازنامه مالی شرکت (بیلان کاری)</h3>
            <p className="text-[10px] text-slate-400 mt-1">تراز لحظه‌ای حقوق صاحبان سهام و تعهدات • مقادیر بر حسب تومان</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 divide-y md:divide-y-0 md:divide-x md:divide-x-reverse divide-slate-200 text-xs">
            
            {/* Assets (Right Column) */}
            <div className="space-y-4 pb-4 md:pb-0">
              <h4 className="font-bold text-slate-800 text-center bg-blue-50/50 p-2 rounded-xl border border-blue-100">دارایی‌ها (Assets)</h4>
              
              <div className="space-y-3 px-2">
                <div className="flex justify-between text-slate-600 font-medium">
                  <span>موجودی نقد و بانک‌ها</span>
                  <span className="font-mono font-bold">{formatMoney(bankAndCashAsset)}</span>
                </div>
                <div className="flex justify-between text-slate-600 font-medium">
                  <span>حساب‌های دریافتنی (بدهکاران تجاری)</span>
                  <span className="font-mono font-bold">{formatMoney(accountsReceivableAsset)}</span>
                </div>
                <div className="flex justify-between text-slate-600 font-medium">
                  <span>موجودی کالای انبار (بهای خرید)</span>
                  <span className="font-mono font-bold">{formatMoney(inventoryAsset)}</span>
                </div>

                <div className="border-t border-slate-200 pt-4 mt-6 flex justify-between font-black text-slate-900 bg-slate-50 p-2.5 rounded-lg text-[13px]">
                  <span>جمع کل دارایی‌ها:</span>
                  <span className="font-mono text-blue-700">{formatMoney(totalAssets)}</span>
                </div>
              </div>
            </div>

            {/* Liabilities & Equity (Left Column) */}
            <div className="space-y-4 pt-4 md:pt-0">
              <h4 className="font-bold text-slate-800 text-center bg-violet-50/50 p-2 rounded-xl border border-violet-100">بدهی‌ها و سرمایه (Liabilities & Equity)</h4>
              
              <div className="space-y-3 px-2">
                <div className="flex justify-between text-slate-600 font-medium">
                  <span>حساب‌های پرداختنی (بستانکاران تجاری)</span>
                  <span className="font-mono font-bold">{formatMoney(accountsPayableLiability)}</span>
                </div>
                <div className="flex justify-between text-slate-600 font-medium">
                  <span>سرمایه اولیه ثبت شده شرکت</span>
                  <span className="font-mono font-bold">{formatMoney(shareholdersEquity - netProfit)}</span>
                </div>
                <div className="flex justify-between text-slate-600 font-medium">
                  <span>سود انباشته (از صورت سود و زیان)</span>
                  <span className={`font-mono font-bold ${netProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {formatMoney(netProfit)}
                  </span>
                </div>

                <div className="border-t border-slate-200 pt-4 mt-6 flex justify-between font-black text-slate-900 bg-slate-50 p-2.5 rounded-lg text-[13px]">
                  <span>جمع کل بدهی‌ها و سرمایه:</span>
                  <span className="font-mono text-violet-700">{formatMoney(totalAssets)}</span>
                </div>
              </div>
            </div>

          </div>

          <div className="p-3 bg-amber-50 rounded-xl border border-amber-100 text-[10px] text-amber-800 text-center font-semibold">
            تراز ترازنامه: فرمول طلایی حسابداری برقرار است (دارایی = بدهی + سرمایه) و ترازنامه کاملاً متعادل می‌باشد.
          </div>

        </div>
      )}

      {/* --- 3. GENERAL LEDGER VIEW --- */}
      {activeReport === 'ledger' && (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-xs p-6 max-w-4xl mx-auto space-y-4">
          
          <div className="text-center pb-4 border-b border-slate-100">
            <h3 className="text-base font-black text-slate-800">دفتر روزنامه کلی شرکت</h3>
            <p className="text-[10px] text-slate-400 mt-1">فهرست کامل اسناد حسابداری ثبت شده به صورت روزشمار</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 text-slate-500 font-bold">
                  <th className="p-3 w-28">تاریخ ثبت</th>
                  <th className="p-3">شرح بابت آرتیکل مالی</th>
                  <th className="p-3 w-40 text-left">بدهکار (تومان)</th>
                  <th className="p-3 w-40 text-left">بستانکار (تومان)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {transactions.map(t => (
                  <React.Fragment key={t.id}>
                    {/* Debit Line */}
                    <tr className="hover:bg-slate-50/20">
                      <td className="p-3 font-mono text-slate-400">{t.date}</td>
                      <td className="p-3 font-bold text-slate-800">
                        {t.toName} <span className="text-[9px] text-slate-400 font-normal">(بدهکار)</span>
                        <div className="text-[10px] text-slate-400 font-normal mt-0.5">{t.description}</div>
                      </td>
                      <td className="p-3 text-left font-mono font-bold text-emerald-600">{formatNumber(t.amount)}</td>
                      <td className="p-3 text-left font-mono text-slate-300">---</td>
                    </tr>
                    {/* Credit Line */}
                    <tr className="hover:bg-slate-50/20">
                      <td className="p-3 font-mono text-slate-400"></td>
                      <td className="p-3 text-slate-600 pl-8">
                        حساب معین: {t.fromName} <span className="text-[9px] text-slate-400 font-normal">(بستانکار)</span>
                      </td>
                      <td className="p-3 text-left font-mono text-slate-300">---</td>
                      <td className="p-3 text-left font-mono font-bold text-rose-600">{formatNumber(t.amount)}</td>
                    </tr>
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      )}

    </div>
  );
}
