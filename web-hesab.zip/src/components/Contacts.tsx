/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Contact } from '../types';
import { 
  Search, Plus, Phone, Mail, MapPin, User, Trash2, Edit2, ShieldAlert,
  ArrowRight, Check, FileText, X, ChevronDown, ChevronRight, ChevronLeft, Calendar,
  CreditCard, Home, MessageSquare, MoreHorizontal, Printer, ArrowLeft,
  UserCheck, UserX, UserMinus, PlusCircle, CheckSquare, Square, RefreshCw, Copy
} from 'lucide-react';

interface ContactsProps {
  contacts: Contact[];
  setContacts: React.Dispatch<React.SetStateAction<Contact[]>>;
  subTabAction?: any;
  setSubTabAction?: any;
}

export default function Contacts({ contacts, setContacts, subTabAction, setSubTabAction }: ContactsProps) {
  // Navigation & View Mode
  const [viewMode, setViewMode] = useState<'list' | 'form'>('list');
  const [filterType, setFilterType] = useState<'all' | 'customer' | 'supplier' | 'employee' | 'notransaction'>('all');
  
  // Selection
  const [selectedContactIds, setSelectedContactIds] = useState<string[]>([]);
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  
  // Spreadsheet-style Column Filters
  const [filters, setFilters] = useState({
    code: '',
    category: '',
    name: '',
    firstName: '',
    lastName: '',
    company: '',
    country: '',
    province: '',
    city: '',
    mobile: '',
    phone: '',
    email: '',
    nationalId: '',
    economicCode: '',
    registrationNumber: '',
    isActive: 'all' // 'all', 'active', 'inactive'
  });

  // Editing state
  const [editingContact, setEditingContact] = useState<Contact | null>(null);

  // Form Fields
  const [code, setCode] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [company, setCompany] = useState('');
  const [title, setTitle] = useState('آقا');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [category, setCategory] = useState('مشتری');
  const [isCustomer, setIsCustomer] = useState(true);
  const [isSupplier, setIsSupplier] = useState(false);
  const [isShareholder, setIsShareholder] = useState(false);
  const [isEmployee, setIsEmployee] = useState(false);
  const [image, setImage] = useState('');
  
  // Form Active Tab
  const [activeFormTab, setActiveFormTab] = useState<'general' | 'address' | 'contact' | 'bank' | 'other'>('general');

  // Form Tab Fields
  const [financialCredit, setFinancialCredit] = useState(0);
  const [priceList, setPriceList] = useState('لیست قیمت اصلی');
  const [taxType, setTaxType] = useState('۵- مودی مشمول ثبت نام در نظام مالیاتی');
  const [nationalId, setNationalId] = useState('');
  const [economicCode, setEconomicCode] = useState('');
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [branchCode, setBranchCode] = useState('');
  const [description, setDescription] = useState('');

  const [address, setAddress] = useState('');
  const [country, setCountry] = useState('ایران');
  const [province, setProvince] = useState('');
  const [city, setCity] = useState('');
  const [postalCode, setPostalCode] = useState('');

  const [phoneVal, setPhoneVal] = useState('');
  const [mobileVal, setMobileVal] = useState('');
  const [faxVal, setFaxVal] = useState('');
  const [phone1, setPhone1] = useState('');
  const [phone2, setPhone2] = useState('');
  const [phone3, setPhone3] = useState('');
  const [emailVal, setEmailVal] = useState('');
  const [website, setWebsite] = useState('');

  const [bankAccounts, setBankAccounts] = useState<any[]>([
    { bank: '', accountNumber: '', cardNumber: '', sheba: '' }
  ]);

  const [birthDate, setBirthDate] = useState('');
  const [marriageDate, setMarriageDate] = useState('');
  const [membershipDate, setMembershipDate] = useState('۱۴۰۵/۰۴/۱۷');

  // Sync subTabAction from Sidebar
  useEffect(() => {
    if (subTabAction && subTabAction.tab === 'contacts') {
      if (subTabAction.action === 'add-contact') {
        openAddForm();
      } else if (subTabAction.action === 'list-all') {
        setViewMode('list');
        setFilterType('all');
      } else if (subTabAction.action === 'list-suppliers') {
        setViewMode('list');
        setFilterType('supplier');
      } else if (subTabAction.action === 'list-shareholders') {
        setViewMode('list');
        // Let's set tab to 'all' but we'll show shareholders through column filter or we can show all
        setViewMode('list');
        setFilterType('all');
        setFilters(prev => ({ ...prev, category: 'سهامداران' }));
      }
      if (setSubTabAction) {
        setSubTabAction(null);
      }
    }
  }, [subTabAction]);

  // Handle display name computation
  useEffect(() => {
    if (!editingContact) {
      let computed = '';
      if (company.trim()) {
        computed = company.trim();
        if (lastName.trim()) {
          computed += ` - ${title} ${firstName.trim()} ${lastName.trim()}`.trim();
        }
      } else if (lastName.trim()) {
        computed = `${title} ${firstName.trim()} ${lastName.trim()}`.trim();
      }
      setDisplayName(computed);
    }
  }, [company, title, firstName, lastName]);

  // Clear Form Helper
  const openAddForm = () => {
    setEditingContact(null);
    setCode(generateNextCode());
    setIsActive(true);
    setCompany('');
    setTitle('آقا');
    setFirstName('');
    setLastName('');
    setDisplayName('');
    setCategory('مشتری');
    setIsCustomer(true);
    setIsSupplier(false);
    setIsShareholder(false);
    setIsEmployee(false);
    setImage('');
    
    // Tab reset
    setActiveFormTab('general');
    setFinancialCredit(0);
    setPriceList('لیست قیمت اصلی');
    setTaxType('۵- مودی مشمول ثبت نام در نظام مالیاتی');
    setNationalId('');
    setEconomicCode('');
    setRegistrationNumber('');
    setBranchCode('');
    setDescription('');
    
    setAddress('');
    setCountry('ایران');
    setProvince('');
    setCity('');
    setPostalCode('');
    
    setPhoneVal('');
    setMobileVal('');
    setFaxVal('');
    setPhone1('');
    setPhone2('');
    setPhone3('');
    setEmailVal('');
    setWebsite('');
    
    setBankAccounts([{ bank: '', accountNumber: '', cardNumber: '', sheba: '' }]);
    setBirthDate('');
    setMarriageDate('');
    setMembershipDate('۱۴۰۵/۰۴/۱۷');

    setViewMode('form');
  };

  // Handle image upload from device
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Helper to get next code
  const generateNextCode = () => {
    if (contacts.length === 0) return '۰۰۰۰۰۱';
    const codes = contacts.map(c => {
      // Replace Persian digits with English
      const eng = (c.code || '').replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
      const parsed = parseInt(eng, 10);
      return isNaN(parsed) ? 0 : parsed;
    });
    const maxVal = Math.max(...codes, 0);
    const nextVal = maxVal + 1;
    // format as 6-digit Persian number
    const padded = String(nextVal).padStart(6, '0');
    return padded.replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
  };

  // Edit existing contact
  const openEditForm = (contact: Contact) => {
    setEditingContact(contact);
    setCode(contact.code || '');
    setIsActive(contact.isActive !== false);
    setCompany(contact.company || '');
    setTitle(contact.title || 'آقا');
    setFirstName(contact.firstName || '');
    setLastName(contact.lastName || '');
    setDisplayName(contact.name || '');
    setCategory(contact.category || 'مشتری');
    
    setIsCustomer(contact.type === 'customer' || contact.type === 'both');
    setIsSupplier(contact.type === 'supplier' || contact.type === 'both');
    setIsShareholder(contact.type === 'shareholder');
    setIsEmployee(contact.type === 'employee');
    setImage(contact.image || '');

    setActiveFormTab('general');
    setFinancialCredit(contact.financialCredit || 0);
    setPriceList(contact.priceList || 'لیست قیمت اصلی');
    setTaxType(contact.taxType || '۵- مودی مشمول ثبت نام در نظام مالیاتی');
    setNationalId(contact.nationalId || '');
    setEconomicCode(contact.economicCode || '');
    setRegistrationNumber(contact.registrationNumber || '');
    setBranchCode(contact.branchCode || '');
    setDescription(contact.description || '');

    setAddress(contact.address || '');
    setCountry(contact.country || 'ایران');
    setProvince(contact.province || '');
    setCity(contact.city || '');
    setPostalCode(contact.postalCode || '');

    setPhoneVal(contact.phone || '');
    setMobileVal(contact.mobile || '');
    setFaxVal(contact.fax || '');
    setPhone1(contact.phone1 || '');
    setPhone2(contact.phone2 || '');
    setPhone3(contact.phone3 || '');
    setEmailVal(contact.email || '');
    setWebsite(contact.website || '');

    setBankAccounts(contact.bankAccounts && contact.bankAccounts.length > 0 
      ? contact.bankAccounts 
      : [{ bank: '', accountNumber: '', cardNumber: '', sheba: '' }]
    );

    setBirthDate(contact.birthDate || '');
    setMarriageDate(contact.marriageDate || '');
    setMembershipDate(contact.membershipDate || '۱۴۰۵/۰۴/۱۷');

    setViewMode('form');
  };

  // Duplicate Contact Action
  const handleDuplicate = () => {
    if (selectedContactIds.length !== 1) return;
    const toCopy = contacts.find(c => c.id === selectedContactIds[0]);
    if (!toCopy) return;

    const copyObj: Contact = {
      ...toCopy,
      id: 'c_' + Date.now(),
      code: generateNextCode(),
      name: toCopy.name + ' (کپی)',
      balance: 0
    };

    setContacts([...contacts, copyObj]);
    setSelectedContactIds([]);
    alert('شخص با موفقیت تکثیر شد.');
  };

  // Form Submit Action
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim()) {
      alert('لطفاً نام مستعار (نمایش) را وارد کنید.');
      return;
    }

    if (!isCustomer && !isSupplier && !isShareholder && !isEmployee) {
      alert('لطفاً حتماً نوع شخص (مشتری، تامین کننده، سهامدار یا کارمند) را انتخاب کنید.');
      return;
    }

    // Determine type role
    let finalType: 'customer' | 'supplier' | 'both' | 'shareholder' | 'employee' = 'customer';
    if (isCustomer && isSupplier) finalType = 'both';
    else if (isSupplier) finalType = 'supplier';
    else if (isCustomer) finalType = 'customer';
    else if (isShareholder) finalType = 'shareholder';
    else if (isEmployee) finalType = 'employee';

    const contactData: Contact = {
      id: editingContact ? editingContact.id : 'c_' + Date.now(),
      code: code || generateNextCode(),
      isActive,
      company,
      title,
      firstName,
      lastName,
      name: displayName,
      category,
      type: finalType,
      balance: editingContact ? editingContact.balance : 0,
      image,

      financialCredit,
      priceList,
      taxType,
      nationalId,
      economicCode,
      registrationNumber,
      branchCode,
      description,

      address,
      country,
      province,
      city,
      postalCode,

      phone: phoneVal,
      mobile: mobileVal,
      fax: faxVal,
      phone1,
      phone2,
      phone3,
      email: emailVal,
      website,

      bankAccounts: bankAccounts.filter(b => b.bank.trim() || b.accountNumber.trim()),
      birthDate,
      marriageDate,
      membershipDate
    };

    if (editingContact) {
      setContacts(contacts.map(c => c.id === editingContact.id ? contactData : c));
    } else {
      setContacts([...contacts, contactData]);
    }

    setViewMode('list');
    setEditingContact(null);
  };

  // Delete Selection Action
  const handleDeleteSelected = () => {
    if (selectedContactIds.length === 0) return;
    if (confirm(`آیا از حذف ${selectedContactIds.length} شخص انتخاب شده مطمئن هستید؟`)) {
      setContacts(contacts.filter(c => !selectedContactIds.includes(c.id)));
      setSelectedContactIds([]);
    }
  };

  // Edit Selection Action
  const handleEditSelected = () => {
    if (selectedContactIds.length !== 1) return;
    const contact = contacts.find(c => c.id === selectedContactIds[0]);
    if (contact) {
      openEditForm(contact);
    }
  };

  // Multi-checkbox helper
  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>, visibleContacts: Contact[]) => {
    if (e.target.checked) {
      setSelectedContactIds(visibleContacts.map(c => c.id));
    } else {
      setSelectedContactIds([]);
    }
  };

  const handleSelectRow = (contactId: string) => {
    if (selectedContactIds.includes(contactId)) {
      setSelectedContactIds(selectedContactIds.filter(id => id !== contactId));
    } else {
      setSelectedContactIds([...selectedContactIds, contactId]);
    }
  };

  // Filter Logic
  const filtered = contacts.filter(c => {
    // type/role filter based on active top tab
    const matchesTab = 
      filterType === 'all' ? true :
      filterType === 'customer' ? (c.type === 'customer' || c.type === 'both') :
      filterType === 'supplier' ? (c.type === 'supplier' || c.type === 'both') :
      filterType === 'employee' ? (c.type === 'employee') :
      filterType === 'notransaction' ? (c.balance === 0) : true;
      
    if (!matchesTab) return false;

    // field filters (case-insensitive, Persian/Arabic digits mapping or simple includes)
    const matchesCode = !filters.code || (c.code || '').includes(filters.code);
    const matchesCategory = !filters.category || (c.category || '').includes(filters.category);
    const matchesName = !filters.name || (c.name || '').toLowerCase().includes(filters.name.toLowerCase());
    const matchesFirstName = !filters.firstName || (c.firstName || '').toLowerCase().includes(filters.firstName.toLowerCase());
    const matchesLastName = !filters.lastName || (c.lastName || '').toLowerCase().includes(filters.lastName.toLowerCase());
    const matchesCompany = !filters.company || (c.company || '').toLowerCase().includes(filters.company.toLowerCase());
    const matchesCountry = !filters.country || (c.country || '').includes(filters.country);
    const matchesProvince = !filters.province || (c.province || '').includes(filters.province);
    const matchesCity = !filters.city || (c.city || '').includes(filters.city);
    const matchesMobile = !filters.mobile || (c.mobile || '').includes(filters.mobile);
    const matchesPhone = !filters.phone || (c.phone || '').includes(filters.phone);
    const matchesEmail = !filters.email || (c.email || '').toLowerCase().includes(filters.email.toLowerCase());
    const matchesNationalId = !filters.nationalId || (c.nationalId || '').includes(filters.nationalId);
    const matchesEconomicCode = !filters.economicCode || (c.economicCode || '').includes(filters.economicCode);
    const matchesRegistrationNumber = !filters.registrationNumber || (c.registrationNumber || '').includes(filters.registrationNumber);
    const matchesActive = filters.isActive === 'all' ? true :
                         filters.isActive === 'active' ? (c.isActive !== false) :
                         filters.isActive === 'inactive' ? (c.isActive === false) : true;

    return matchesCode && matchesCategory && matchesName && matchesFirstName && matchesLastName &&
           matchesCompany && matchesCountry && matchesProvince && matchesCity && matchesMobile &&
           matchesPhone && matchesEmail && matchesNationalId && matchesEconomicCode && matchesRegistrationNumber && matchesActive;
  });

  // Calculate pagination
  const totalItems = filtered.length;
  const totalPages = Math.ceil(totalItems / pageSize) || 1;
  const paginatedContacts = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  // Bank accounts array handlers
  const updateBankAccount = (index: number, key: string, val: string) => {
    const list = [...bankAccounts];
    list[index][key] = val;
    setBankAccounts(list);
  };

  const addBankAccountRow = () => {
    setBankAccounts([...bankAccounts, { bank: '', accountNumber: '', cardNumber: '', sheba: '' }]);
  };

  const removeBankAccountRow = (index: number) => {
    const list = [...bankAccounts];
    if (list.length > 1) {
      list.splice(index, 1);
      setBankAccounts(list);
    } else {
      setBankAccounts([{ bank: '', accountNumber: '', cardNumber: '', sheba: '' }]);
    }
  };

  // Convert numbers to Persian for formatting
  const toPersianNum = (n: number | string) => {
    return String(n).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
  };

  const formatBalance = (bal: number) => {
    if (bal === 0) return '۰';
    const absVal = Math.abs(bal).toLocaleString('fa-IR');
    return bal > 0 ? `${absVal} بدهکار` : `${absVal} بستانکار`;
  };

  return (
    <div className="font-sans text-slate-800" dir="rtl">
      
      {viewMode === 'list' ? (
        // ==========================================
        // 1. LIST VIEW (اشخاص)
        // ==========================================
        <div className="space-y-4">
          
          {/* Main Action Header */}
          <div className="flex items-center justify-between bg-white border border-slate-200/80 p-3.5 rounded-2xl shadow-xs">
            <div className="flex items-center gap-3">
              <h2 className="text-base font-extrabold text-slate-900 tracking-tight" id="contacts-title">اشخاص</h2>
              <span className="text-xs bg-slate-100 text-slate-500 font-bold px-2 py-1 rounded-lg">
                {toPersianNum(filtered.length)} مورد
              </span>
            </div>

            {/* Icons on top left */}
            <div className="flex items-center gap-1.5">
              
              {/* Delete Button */}
              <button 
                onClick={handleDeleteSelected}
                disabled={selectedContactIds.length === 0}
                className={`p-2 rounded-xl transition-all duration-150 ${
                  selectedContactIds.length > 0 
                    ? 'text-rose-600 bg-rose-50 hover:bg-rose-100 border border-rose-200/50 cursor-pointer' 
                    : 'text-slate-300 border border-transparent cursor-not-allowed'
                }`}
                title="حذف انتخاب شده ها"
              >
                <Trash2 size={16} />
              </button>

              {/* Edit Button */}
              <button 
                onClick={handleEditSelected}
                disabled={selectedContactIds.length !== 1}
                className={`p-2 rounded-xl transition-all duration-150 ${
                  selectedContactIds.length === 1 
                    ? 'text-blue-600 bg-blue-50 hover:bg-blue-100 border border-blue-200/50 cursor-pointer' 
                    : 'text-slate-300 border border-transparent cursor-not-allowed'
                }`}
                title="ویرایش شخص منتخب"
              >
                <Edit2 size={16} />
              </button>

              {/* Duplicate/Copy Button */}
              <button 
                onClick={handleDuplicate}
                disabled={selectedContactIds.length !== 1}
                className={`p-2 rounded-xl transition-all duration-150 ${
                  selectedContactIds.length === 1 
                    ? 'text-amber-600 bg-amber-50 hover:bg-amber-100 border border-amber-200/50 cursor-pointer' 
                    : 'text-slate-300 border border-transparent cursor-not-allowed'
                }`}
                title="کپی و تکثیر"
              >
                <Copy size={16} />
              </button>

              <div className="w-[1px] h-6 bg-slate-200 mx-1"></div>

              {/* Add New Contact Button */}
              <button 
                onClick={openAddForm}
                className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-2 shadow-sm transition-all duration-150"
              >
                <Plus size={15} />
                <span>شخص جدید</span>
              </button>

              {/* Three dots dropdown mock */}
              <button className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-50 border border-transparent">
                <MoreHorizontal size={16} />
              </button>
            </div>
          </div>

          {/* Filter tabs */}
          <div className="flex border-b border-slate-200" id="contacts-tabs">
            <button 
              onClick={() => { setFilterType('all'); setCurrentPage(1); }}
              className={`px-5 py-2.5 text-xs font-bold border-b-2 transition-all duration-150 ${
                filterType === 'all' 
                  ? 'border-blue-600 text-blue-600' 
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              همه
            </button>
            <button 
              onClick={() => { setFilterType('customer'); setCurrentPage(1); }}
              className={`px-5 py-2.5 text-xs font-bold border-b-2 transition-all duration-150 ${
                filterType === 'customer' 
                  ? 'border-blue-600 text-blue-600' 
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              مشتریان
            </button>
            <button 
              onClick={() => { setFilterType('supplier'); setCurrentPage(1); }}
              className={`px-5 py-2.5 text-xs font-bold border-b-2 transition-all duration-150 ${
                filterType === 'supplier' 
                  ? 'border-blue-600 text-blue-600' 
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              تامین کنندگان
            </button>
            <button 
              onClick={() => { setFilterType('employee'); setCurrentPage(1); }}
              className={`px-5 py-2.5 text-xs font-bold border-b-2 transition-all duration-150 ${
                filterType === 'employee' 
                  ? 'border-blue-600 text-blue-600' 
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              کارمندان
            </button>
            <button 
              onClick={() => { setFilterType('notransaction'); setCurrentPage(1); }}
              className={`px-5 py-2.5 text-xs font-bold border-b-2 transition-all duration-150 ${
                filterType === 'notransaction' 
                  ? 'border-blue-600 text-blue-600' 
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              بدون تراکنش
            </button>
          </div>

          {/* DENSE SPREADSHEET TABLE CARD */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto max-w-full">
              <table className="w-full text-right text-[11px] border-collapse" style={{ minWidth: '1500px' }}>
                
                {/* Column Headers */}
                <thead className="bg-slate-50/70 border-b border-slate-200">
                  <tr className="divide-x divide-x-reverse divide-slate-200">
                    <th className="p-2 text-center w-8 text-slate-400 font-normal">#</th>
                    <th className="p-2 text-center w-10">
                      <input 
                        type="checkbox" 
                        onChange={(e) => handleSelectAll(e, paginatedContacts)}
                        checked={paginatedContacts.length > 0 && paginatedContacts.every(c => selectedContactIds.includes(c.id))}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5" 
                      />
                    </th>
                    <th className="p-2 font-bold text-slate-700 w-24">کد</th>
                    <th className="p-2 font-bold text-slate-700 w-36">دسته بندی</th>
                    <th className="p-2 font-bold text-slate-700 w-56">نام مستعار</th>
                    <th className="p-2 font-bold text-slate-700 w-32">نام</th>
                    <th className="p-2 font-bold text-slate-700 w-36">نام خانوادگی</th>
                    <th className="p-2 font-bold text-slate-700 w-44">شرکت</th>
                    <th className="p-2 font-bold text-slate-700 w-24">کشور</th>
                    <th className="p-2 font-bold text-slate-700 w-28">استان</th>
                    <th className="p-2 font-bold text-slate-700 w-28">شهر</th>
                    <th className="p-2 font-bold text-slate-700 w-32">موبایل</th>
                    <th className="p-2 font-bold text-slate-700 w-32">تلفن</th>
                    <th className="p-2 font-bold text-slate-700 w-44">ایمیل</th>
                    <th className="p-2 font-bold text-slate-700 w-32">شناسه ملی</th>
                    <th className="p-2 font-bold text-slate-700 w-32">کد اقتصادی</th>
                    <th className="p-2 font-bold text-slate-700 w-32">شماره ثبت</th>
                    <th className="p-2 font-bold text-slate-700 text-center w-20">فعال</th>
                    <th className="p-2 font-bold text-slate-700 w-28 text-center">تاریخ تولد</th>
                    <th className="p-2 font-bold text-slate-700 w-28 text-center">تاریخ عضویت</th>
                  </tr>

                  {/* Filter Row with Search Inputs */}
                  <tr className="bg-white divide-x divide-x-reverse divide-slate-100 border-b border-slate-200">
                    <td className="p-1 text-center bg-slate-50/40"></td>
                    <td className="p-1 text-center bg-slate-50/40"></td>
                    
                    {/* Code filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.code}
                          onChange={(e) => { setFilters({...filters, code: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Category filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.category}
                          onChange={(e) => { setFilters({...filters, category: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Nickname/DisplayName filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.name}
                          onChange={(e) => { setFilters({...filters, name: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Firstname filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.firstName}
                          onChange={(e) => { setFilters({...filters, firstName: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Lastname filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.lastName}
                          onChange={(e) => { setFilters({...filters, lastName: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Company filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.company}
                          onChange={(e) => { setFilters({...filters, company: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Country filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.country}
                          onChange={(e) => { setFilters({...filters, country: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Province filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.province}
                          onChange={(e) => { setFilters({...filters, province: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* City filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.city}
                          onChange={(e) => { setFilters({...filters, city: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Mobile filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.mobile}
                          onChange={(e) => { setFilters({...filters, mobile: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Phone filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.phone}
                          onChange={(e) => { setFilters({...filters, phone: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Email filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.email}
                          onChange={(e) => { setFilters({...filters, email: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500 text-left"
                          dir="ltr"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* NationalId filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.nationalId}
                          onChange={(e) => { setFilters({...filters, nationalId: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* EconomicCode filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.economicCode}
                          onChange={(e) => { setFilters({...filters, economicCode: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* RegistrationNumber filter */}
                    <td className="p-1">
                      <div className="relative">
                        <input 
                          type="text" 
                          value={filters.registrationNumber}
                          onChange={(e) => { setFilters({...filters, registrationNumber: e.target.value}); setCurrentPage(1); }}
                          className="w-full pr-6 pl-2 py-1 text-[10px] bg-slate-50 border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                        />
                        <Search size={10} className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      </div>
                    </td>

                    {/* Active dropdown filter */}
                    <td className="p-1 text-center bg-slate-50/10">
                      <select 
                        value={filters.isActive}
                        onChange={(e) => { setFilters({...filters, isActive: e.target.value}); setCurrentPage(1); }}
                        className="text-[9px] w-full px-1 py-0.5 bg-slate-50 border border-slate-200 rounded"
                      >
                        <option value="all">(همه)</option>
                        <option value="active">فعال</option>
                        <option value="inactive">غیرفعال</option>
                      </select>
                    </td>

                    <td className="p-1 bg-slate-50/40"></td>
                    <td className="p-1 bg-slate-50/40"></td>
                  </tr>
                </thead>

                {/* Table Body */}
                <tbody className="divide-y divide-slate-200">
                  {paginatedContacts.length === 0 ? (
                    <tr>
                      <td colSpan={20} className="p-12 text-center text-slate-400 text-xs">
                        <User size={36} className="mx-auto mb-2 text-slate-300" />
                        <div className="font-bold">هیچ مخاطبی با مشخصات فیلتر شده یافت نشد.</div>
                      </td>
                    </tr>
                  ) : (
                    paginatedContacts.map((contact, index) => {
                      const absoluteIndex = (currentPage - 1) * pageSize + index + 1;
                      const isSelected = selectedContactIds.includes(contact.id);
                      return (
                        <tr 
                          key={contact.id}
                          className={`divide-x divide-x-reverse divide-slate-100 hover:bg-slate-50/50 transition-colors duration-150 ${
                            isSelected ? 'bg-blue-50/30' : ''
                          }`}
                        >
                          <td className="p-2 text-center bg-slate-50/30 text-slate-400 font-medium">
                            {toPersianNum(absoluteIndex)}
                          </td>
                          <td className="p-2 text-center">
                            <input 
                              type="checkbox" 
                              checked={isSelected}
                              onChange={() => handleSelectRow(contact.id)}
                              className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5"
                            />
                          </td>
                          <td className="p-2 text-slate-600 font-medium">{contact.code}</td>
                          <td className="p-2 text-slate-500">{contact.category || 'اشخاص'}</td>
                          <td className="p-2">
                            {/* Blue Clickable display name to edit */}
                            <button 
                              onClick={() => openEditForm(contact)}
                              className="text-blue-600 hover:text-blue-800 font-semibold hover:underline text-right"
                            >
                              {contact.name}
                            </button>
                          </td>
                          <td className="p-2 text-slate-500">{contact.firstName || '---'}</td>
                          <td className="p-2 text-slate-500">{contact.lastName || '---'}</td>
                          <td className="p-2 text-slate-500">{contact.company || '---'}</td>
                          <td className="p-2 text-slate-500">{contact.country || '---'}</td>
                          <td className="p-2 text-slate-500">{contact.province || '---'}</td>
                          <td className="p-2 text-slate-500">{contact.city || '---'}</td>
                          <td className="p-2 text-slate-500">{contact.mobile || '---'}</td>
                          <td className="p-2 text-slate-500">{contact.phone || '---'}</td>
                          <td className="p-2 text-slate-500 font-mono text-[10px] text-left" dir="ltr">{contact.email || '---'}</td>
                          <td className="p-2 text-slate-500">{contact.nationalId || '---'}</td>
                          <td className="p-2 text-slate-500">{contact.economicCode || '---'}</td>
                          <td className="p-2 text-slate-500">{contact.registrationNumber || '---'}</td>
                          <td className="p-2 text-center">
                            <input 
                              type="checkbox" 
                              checked={contact.isActive !== false} 
                              disabled 
                              className="rounded border-slate-300 text-slate-500 w-3 h-3 cursor-not-allowed opacity-80"
                            />
                          </td>
                          <td className="p-2 text-center text-slate-500">{contact.birthDate || '---'}</td>
                          <td className="p-2 text-center text-slate-500">{contact.membershipDate || '---'}</td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* SPREADSHEET FOOTER (PAGINATION) - RTL Layout */}
            <div className="bg-slate-50 border-t border-slate-200 p-2.5 flex flex-col md:flex-row items-center justify-between text-xs gap-3">
              
              {/* Pagination controls (Left in RTL is page indices) */}
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="p-1 rounded hover:bg-slate-200 border border-slate-300 disabled:opacity-40 disabled:hover:bg-transparent"
                >
                  <ChevronRight size={14} />
                </button>
                
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => {
                  // Show pages with truncation or just simple page buttons
                  return (
                    <button
                      key={p}
                      onClick={() => setCurrentPage(p)}
                      className={`px-2.5 py-1 rounded text-[11px] font-bold border transition-all duration-100 ${
                        p === currentPage 
                          ? 'bg-white border-blue-500 text-blue-600 shadow-xs' 
                          : 'border-transparent text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {toPersianNum(p)}
                    </button>
                  );
                })}

                <button 
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className="p-1 rounded hover:bg-slate-200 border border-slate-300 disabled:opacity-40 disabled:hover:bg-transparent"
                >
                  <ChevronLeft size={14} />
                </button>
              </div>

              {/* Status information (Middle) */}
              <div className="font-semibold text-slate-500 text-[11px]">
                صفحه {toPersianNum(currentPage)} از {toPersianNum(totalPages)} ({toPersianNum(totalItems)} آیتم)
              </div>

              {/* Page size selectors (Right) */}
              <div className="flex items-center gap-2">
                <span className="text-slate-400 text-[10px]">اندازه صفحه:</span>
                <div className="flex bg-slate-200 p-0.5 rounded-lg border border-slate-300/40">
                  {[5, 10, 15, 20, 30, 50, 100].map(size => (
                    <button
                      key={size}
                      onClick={() => { setPageSize(size); setCurrentPage(1); }}
                      className={`px-1.5 py-0.5 text-[9px] font-bold rounded-md transition-all duration-100 ${
                        size === pageSize 
                          ? 'bg-slate-600 text-white' 
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {toPersianNum(size)}
                    </button>
                  ))}
                </div>
              </div>

            </div>
          </div>

        </div>
      ) : (
        // ==========================================
        // 2. FORM VIEW (مشخصات شخص / شخص جدید)
        // ==========================================
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5 space-y-6">
          
          {/* Form Header */}
          <div className="flex items-center justify-between border-b border-slate-200 pb-4">
            <div className="flex items-center gap-3">
              {/* Back to list arrow */}
              <button 
                type="button"
                onClick={() => { setViewMode('list'); setEditingContact(null); }}
                className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 transition-colors"
                title="بازگشت"
              >
                <ArrowRight size={18} />
              </button>
              <h2 className="text-base font-extrabold text-slate-900">مشخصات شخص</h2>
            </div>
            
            {/* Action buttons (Print, Save, etc.) */}
            <div className="flex items-center gap-2">
              <button 
                type="button" 
                onClick={() => window.print()}
                className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg border border-slate-200"
                title="چاپ"
              >
                <Printer size={15} />
              </button>
              <button 
                onClick={handleSubmit}
                className="bg-green-600 hover:bg-green-700 text-white text-xs font-bold px-4 py-1.5 rounded-xl flex items-center gap-1.5 shadow-sm shadow-green-100 transition-all duration-150"
              >
                <Check size={14} />
                <span>ذخیره شخص</span>
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Top Row: Basic Info & Portrait Avatar */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Left Form: Basic inputs (8 cols) */}
              <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Account Code & Active */}
                <div className="sm:col-span-2 flex flex-col sm:flex-row sm:items-center sm:justify-between bg-slate-50/50 border border-slate-200/50 p-3 rounded-xl gap-3">
                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <label className="text-[11px] font-bold text-slate-600 shrink-0">کد حسابداری</label>
                    <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg overflow-hidden p-0.5 shadow-xs w-full sm:w-48">
                      <input 
                        type="text" 
                        required
                        value={code}
                        onChange={(e) => setCode(e.target.value)}
                        className="w-full text-xs px-2 py-1 focus:outline-none"
                      />
                      <button 
                        type="button"
                        onClick={() => setCode(generateNextCode())}
                        className="bg-blue-50 text-blue-600 hover:bg-blue-100 text-[10px] px-2 py-1 rounded font-bold transition-colors shrink-0"
                      >
                        اتوماتیک
                      </button>
                    </div>
                  </div>
                  
                  <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={isActive}
                      onChange={(e) => setIsActive(e.target.checked)}
                      className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4" 
                    />
                    <span>فعال</span>
                  </label>
                </div>

                {/* Company Name */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-600 mb-1">شرکت</label>
                  <input 
                    type="text" 
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="نام سازمان، شرکت یا اداره..."
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200 shadow-xs"
                  />
                </div>

                {/* Title */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">عنوان</label>
                  <select 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200 shadow-xs"
                  >
                    <option value="آقا">آقا</option>
                    <option value="خانم">خانم</option>
                    <option value="شرکت">شرکت</option>
                    <option value="جناب">جناب</option>
                    <option value="سرکار">سرکار</option>
                  </select>
                </div>

                {/* First Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">نام</label>
                  <input 
                    type="text" 
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200 shadow-xs"
                  />
                </div>

                {/* Last Name */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-600 mb-1">نام خانوادگی</label>
                  <input 
                    type="text" 
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200 shadow-xs"
                  />
                </div>

                {/* Display Name / Nickname */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    نام مستعار <span className="text-rose-500">*</span>
                  </label>
                  <input 
                    type="text" 
                    required
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="مثال: شرکت راه سازان - مهندس علی راهدار"
                    className="w-full text-xs px-3 py-2 border-2 border-blue-100 bg-blue-50/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200 font-semibold"
                  />
                </div>

                {/* Category Dropdown */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-600 mb-1">دسته بندی</label>
                  <div className="relative">
                    <select 
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full text-xs pr-3 pl-10 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 appearance-none bg-white shadow-xs"
                    >
                      <option value="سهامداران">سهامداران</option>
                      <option value="بازاریاب ها">بازاریاب ها</option>
                      <option value="کارمندان">کارمندان</option>
                      <option value="همکار">همکار</option>
                      <option value="مشتری">مشتری</option>
                      <option value="تامین کننده">تامین کننده</option>
                    </select>
                    <X 
                      size={14} 
                      onClick={() => setCategory('مشتری')}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer" 
                    />
                  </div>
                </div>

                {/* Roles Checkboxes (نوع) */}
                <div className="sm:col-span-2 bg-slate-50/50 border border-slate-200/50 p-4 rounded-xl">
                  <span className="block text-xs font-bold text-slate-600 mb-2.5">نوع</span>
                  <div className="flex flex-wrap items-center gap-6">
                    
                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={isCustomer}
                        onChange={(e) => setIsCustomer(e.target.checked)}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4" 
                      />
                      <span>مشتری</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={isSupplier}
                        onChange={(e) => setIsSupplier(e.target.checked)}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4" 
                      />
                      <span>تامین کننده</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={isShareholder}
                        onChange={(e) => setIsShareholder(e.target.checked)}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4" 
                      />
                      <span>سهامدار</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={isEmployee}
                        onChange={(e) => setIsEmployee(e.target.checked)}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4" 
                      />
                      <span>کارمند</span>
                    </label>

                  </div>
                </div>

              </div>

              {/* Right Col: Portrait/Avatar Picker (4 cols) */}
              <div className="lg:col-span-4 flex flex-col items-center justify-center border border-slate-100 bg-slate-50/20 rounded-2xl p-6 shadow-xs">
                
                {/* Hidden input for image upload */}
                <input 
                  type="file" 
                  id="portrait-upload" 
                  accept="image/*" 
                  onChange={handleImageUpload} 
                  className="hidden" 
                />

                {/* Portrait/Avatar Image or Default illustration */}
                <div className="w-36 h-36 rounded-full overflow-hidden bg-slate-100 border-4 border-white shadow-md flex items-center justify-center relative mb-4">
                  {image ? (
                    <img src={image} alt="Portrait" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <svg viewBox="0 0 100 100" className="w-28 h-28 text-slate-400">
                      {/* Circle Background */}
                      <circle cx="50" cy="50" r="48" fill="#14b8a6" className="opacity-90" />
                      {/* Businessman illustration inside circle */}
                      <circle cx="50" cy="38" r="16" fill="#fbc02d" />
                      <path d="M50 16c-9 0-16 7-16 16 0 1 0 1 0 2h32c0-1 0-1 0-2 0-9-7-16-16-16z" fill="#1e293b" />
                      <path d="M26 80c0-12 10-22 22-22h4c12 0 22 10 22 22v6H26v-6z" fill="#0f172a" />
                      <path d="M50 58l-5 8h10z" fill="#f8fafc" />
                      <path d="M49 66h2v12h-2z" fill="#e11d48" />
                    </svg>
                  )}
                </div>

                <div className="flex items-center gap-4 text-xs font-bold">
                  <button 
                    type="button" 
                    onClick={() => document.getElementById('portrait-upload')?.click()}
                    className="text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 px-4 py-1.5 rounded-lg transition-all duration-150"
                  >
                    انتخاب تصویر
                  </button>
                  <button 
                    type="button"
                    onClick={() => {
                      setImage('');
                      const el = document.getElementById('portrait-upload') as HTMLInputElement;
                      if (el) el.value = '';
                    }}
                    className="text-rose-600 hover:text-rose-800 bg-rose-50 hover:bg-rose-100 px-4 py-1.5 rounded-lg transition-all duration-150"
                  >
                    حذف
                  </button>
                </div>

              </div>

            </div>

            {/* LOWER FORM WORKSPACE: TABS CONTROL */}
            <div className="border-t border-slate-200 pt-6">
              
              {/* Horizontal Tabs bar */}
              <div className="flex border border-slate-200 bg-slate-50 p-1 rounded-xl mb-6 shadow-inner">
                
                {/* 1. General tab */}
                <button 
                  type="button"
                  onClick={() => setActiveFormTab('general')}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-bold rounded-lg transition-all duration-150 ${
                    activeFormTab === 'general' 
                      ? 'bg-white border border-slate-300 text-slate-900 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <MessageSquare size={14} />
                  <span>عمومی</span>
                </button>

                {/* 2. Address Info tab */}
                <button 
                  type="button"
                  onClick={() => setActiveFormTab('address')}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-bold rounded-lg transition-all duration-150 ${
                    activeFormTab === 'address' 
                      ? 'bg-white border border-slate-300 text-slate-900 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Home size={14} />
                  <span>اطلاعات آدرس</span>
                </button>

                {/* 3. Contact tab */}
                <button 
                  type="button"
                  onClick={() => setActiveFormTab('contact')}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-bold rounded-lg transition-all duration-150 ${
                    activeFormTab === 'contact' 
                      ? 'bg-white border border-slate-300 text-slate-900 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Phone size={14} />
                  <span>تماس</span>
                </button>

                {/* 4. Bank Account tab */}
                <button 
                  type="button"
                  onClick={() => setActiveFormTab('bank')}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-bold rounded-lg transition-all duration-150 ${
                    activeFormTab === 'bank' 
                      ? 'bg-white border border-slate-300 text-slate-900 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <CreditCard size={14} />
                  <span>حساب بانکی</span>
                </button>

                {/* 5. Other tab */}
                <button 
                  type="button"
                  onClick={() => setActiveFormTab('other')}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-bold rounded-lg transition-all duration-150 ${
                    activeFormTab === 'other' 
                      ? 'bg-white border border-slate-300 text-slate-900 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <ShieldAlert size={14} />
                  <span>سایر</span>
                </button>

              </div>

              {/* Tab Content Rendering */}
              <div className="bg-white border border-slate-200/80 p-5 rounded-2xl min-h-64 shadow-xs">
                
                {activeFormTab === 'general' && (
                  // ==========================================
                  // T1: GENERAL (عمومی)
                  // ==========================================
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    
                    {/* Financial Credit */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">اعتبار مالی</label>
                      <div className="relative">
                        <input 
                          type="number" 
                          value={financialCredit}
                          onChange={(e) => setFinancialCredit(Number(e.target.value))}
                          className="w-full text-xs pr-3 pl-12 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                        />
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-bold">ریال</span>
                      </div>
                    </div>

                    {/* Price List */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">لیست قیمت</label>
                      <select 
                        value={priceList}
                        onChange={(e) => setPriceList(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      >
                        <option value="لیست قیمت اصلی">لیست قیمت اصلی</option>
                        <option value="لیست قیمت همکار">لیست قیمت همکار</option>
                        <option value="لیست قیمت مصرف‌کننده">لیست قیمت مصرف‌کننده</option>
                      </select>
                    </div>

                    {/* Tax Type */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">نوع مالیات</label>
                      <select 
                        value={taxType}
                        onChange={(e) => setTaxType(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      >
                        <option value="۵- مودی مشمول ثبت نام در نظام مالیاتی">۵- مودی مشمول ثبت نام در نظام مالیاتی</option>
                        <option value="۱- مودی مشمول قانون مالیات بر ارزش افزوده">۱- مودی مشمول قانون مالیات بر ارزش افزوده</option>
                        <option value="۲- غیرمشمول">۲- غیرمشمول</option>
                      </select>
                    </div>

                    {/* National ID */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">شناسه ملی / کد ملی</label>
                      <input 
                        type="text" 
                        value={nationalId}
                        onChange={(e) => setNationalId(e.target.value)}
                        placeholder="۱۰ رقم یا ۱۱ رقم شناسه ملی"
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Economic Code */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">کد اقتصادی</label>
                      <input 
                        type="text" 
                        value={economicCode}
                        onChange={(e) => setEconomicCode(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Registration Number */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">شماره ثبت</label>
                      <input 
                        type="text" 
                        value={registrationNumber}
                        onChange={(e) => setRegistrationNumber(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Branch Code */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">کد شعبه</label>
                      <input 
                        type="text" 
                        value={branchCode}
                        onChange={(e) => setBranchCode(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Description */}
                    <div className="md:col-span-3">
                      <label className="block text-xs font-bold text-slate-600 mb-1">توضیحات</label>
                      <textarea 
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        rows={3}
                        placeholder="توضیحات تکمیلی پیرامون روابط مالی، تخفیف‌های ویژه یا مشخصات مودی..."
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      ></textarea>
                    </div>

                  </div>
                )}

                {activeFormTab === 'address' && (
                  // ==========================================
                  // T2: ADDRESS INFO (اطلاعات آدرس)
                  // ==========================================
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    {/* Address Full */}
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-600 mb-1">آدرس</label>
                      <input 
                        type="text" 
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="خیابان، کوچه، پلاک، واحد..."
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Country */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">کشور</label>
                      <input 
                        type="text" 
                        value={country}
                        onChange={(e) => setCountry(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Province */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">استان</label>
                      <input 
                        type="text" 
                        value={province}
                        onChange={(e) => setProvince(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* City */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">شهر</label>
                      <input 
                        type="text" 
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Postal Code */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">کدپستی</label>
                      <input 
                        type="text" 
                        value={postalCode}
                        onChange={(e) => setPostalCode(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                  </div>
                )}

                {activeFormTab === 'contact' && (
                  // ==========================================
                  // T3: CONTACT (تماس)
                  // ==========================================
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    
                    {/* Phone */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">تلفن</label>
                      <input 
                        type="text" 
                        value={phoneVal}
                        onChange={(e) => setPhoneVal(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Mobile */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">موبایل</label>
                      <input 
                        type="text" 
                        value={mobileVal}
                        onChange={(e) => setMobileVal(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Fax */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">فکس</label>
                      <input 
                        type="text" 
                        value={faxVal}
                        onChange={(e) => setFaxVal(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Phone 1 */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">تلفن ۱</label>
                      <input 
                        type="text" 
                        value={phone1}
                        onChange={(e) => setPhone1(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Phone 2 */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">تلفن ۲</label>
                      <input 
                        type="text" 
                        value={phone2}
                        onChange={(e) => setPhone2(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Phone 3 */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">تلفن ۳</label>
                      <input 
                        type="text" 
                        value={phone3}
                        onChange={(e) => setPhone3(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>

                    {/* Email */}
                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold text-slate-600 mb-1">ایمیل</label>
                      <input 
                        type="email" 
                        value={emailVal}
                        onChange={(e) => setEmailVal(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-left font-mono text-[11px]"
                        dir="ltr"
                      />
                    </div>

                    {/* Website */}
                    <div>
                      <label className="block text-xs font-bold text-slate-600 mb-1">وب سایت</label>
                      <input 
                        type="text" 
                        value={website}
                        onChange={(e) => setWebsite(e.target.value)}
                        className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-left font-mono text-[11px]"
                        dir="ltr"
                      />
                    </div>

                  </div>
                )}

                {activeFormTab === 'bank' && (
                  // ==========================================
                  // T4: BANK ACCOUNTS (حساب بانکی)
                  // ==========================================
                  <div className="space-y-4">
                    
                    {bankAccounts.map((acct, index) => (
                      <div key={index} className="flex flex-col sm:flex-row items-end gap-3 p-3.5 bg-slate-50/50 border border-slate-200/50 rounded-2xl relative">
                        
                        {/* Remove Row Button */}
                        <button 
                          type="button" 
                          onClick={() => removeBankAccountRow(index)}
                          className="absolute left-3 top-3 sm:relative sm:top-auto sm:left-auto p-2 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-xl transition-all duration-150 border border-rose-200/30"
                          title="حذف حساب"
                        >
                          <Trash2 size={13} />
                        </button>

                        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 flex-1 w-full text-right">
                          
                          {/* Bank Name */}
                          <div>
                            <label className="block text-[10px] font-bold text-slate-500 mb-1">
                              بانک <span className="text-rose-500">*</span>
                            </label>
                            <input 
                              type="text" 
                              required={index === 0 && acct.accountNumber.trim() !== ''}
                              value={acct.bank}
                              onChange={(e) => updateBankAccount(index, 'bank', e.target.value)}
                              placeholder="مثال: ملی، ملت، صادرات..."
                              className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none bg-white"
                            />
                          </div>

                          {/* Account Number */}
                          <div>
                            <label className="block text-[10px] font-bold text-slate-500 mb-1">شماره حساب</label>
                            <input 
                              type="text" 
                              value={acct.accountNumber}
                              onChange={(e) => updateBankAccount(index, 'accountNumber', e.target.value)}
                              className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none bg-white"
                            />
                          </div>

                          {/* Card Number */}
                          <div>
                            <label className="block text-[10px] font-bold text-slate-500 mb-1">شماره کارت</label>
                            <input 
                              type="text" 
                              value={acct.cardNumber}
                              onChange={(e) => updateBankAccount(index, 'cardNumber', e.target.value)}
                              placeholder="۱۶ رقمی"
                              className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none bg-white"
                            />
                          </div>

                          {/* Sheba (IBAN) */}
                          <div>
                            <label className="block text-[10px] font-bold text-slate-500 mb-1">شبا</label>
                            <input 
                              type="text" 
                              value={acct.sheba}
                              onChange={(e) => updateBankAccount(index, 'sheba', e.target.value)}
                              placeholder="IR"
                              className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none bg-white text-left font-mono"
                              dir="ltr"
                            />
                          </div>

                        </div>

                      </div>
                    ))}

                    {/* Add Bank Account Button */}
                    <div className="flex justify-center border-t border-dashed border-slate-200 pt-4">
                      <button 
                        type="button" 
                        onClick={addBankAccountRow}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-5 py-2 rounded-xl flex items-center gap-1.5 shadow-sm shadow-emerald-50 transition-all duration-150"
                      >
                        <PlusCircle size={14} />
                        <span>اضافه</span>
                      </button>
                    </div>

                  </div>
                )}

                {activeFormTab === 'other' && (
                  // ==========================================
                  // T5: OTHER (سایر)
                  // ==========================================
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    
                    {/* Birth Date */}
                    <div className="bg-slate-50 border border-slate-200/50 rounded-2xl p-4 relative text-right">
                      <button 
                        type="button" 
                        onClick={() => setBirthDate('')}
                        className="absolute left-3 top-3 text-rose-500 hover:text-rose-700 p-1 bg-white hover:bg-rose-50 rounded-lg border border-slate-100 shadow-2xs transition-all duration-150"
                        title="پاک کردن"
                      >
                        <X size={12} />
                      </button>
                      <span className="block text-xs font-bold text-slate-600 mb-3">تاریخ تولد</span>
                      <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2 shadow-inner">
                        <Calendar size={15} className="text-slate-400" />
                        <input 
                          type="text" 
                          value={birthDate}
                          onChange={(e) => setBirthDate(e.target.value)}
                          placeholder="مثال: ۱۳۶۴/۰۷/۱۷"
                          className="w-full text-xs text-slate-700 font-bold focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Marriage Date */}
                    <div className="bg-slate-50 border border-slate-200/50 rounded-2xl p-4 relative text-right">
                      <button 
                        type="button" 
                        onClick={() => setMarriageDate('')}
                        className="absolute left-3 top-3 text-rose-500 hover:text-rose-700 p-1 bg-white hover:bg-rose-50 rounded-lg border border-slate-100 shadow-2xs transition-all duration-150"
                        title="پاک کردن"
                      >
                        <X size={12} />
                      </button>
                      <span className="block text-xs font-bold text-slate-600 mb-3">تاریخ ازدواج</span>
                      <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2 shadow-inner">
                        <Calendar size={15} className="text-slate-400" />
                        <input 
                          type="text" 
                          value={marriageDate}
                          onChange={(e) => setMarriageDate(e.target.value)}
                          placeholder="مثال: ۱۳۹۰/۱۲/۰۵"
                          className="w-full text-xs text-slate-700 font-bold focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Membership Date */}
                    <div className="bg-slate-50 border border-slate-200/50 rounded-2xl p-4 relative text-right">
                      <button 
                        type="button" 
                        onClick={() => setMembershipDate('')}
                        className="absolute left-3 top-3 text-rose-500 hover:text-rose-700 p-1 bg-white hover:bg-rose-50 rounded-lg border border-slate-100 shadow-2xs transition-all duration-150"
                        title="پاک کردن"
                      >
                        <X size={12} />
                      </button>
                      <span className="block text-xs font-bold text-slate-600 mb-3">تاریخ عضویت</span>
                      <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2 shadow-inner">
                        <Calendar size={15} className="text-slate-400" />
                        <input 
                          type="text" 
                          value={membershipDate}
                          onChange={(e) => setMembershipDate(e.target.value)}
                          placeholder="مثال: ۱۴۰۵/۰۴/۱۷"
                          className="w-full text-xs text-slate-700 font-bold focus:outline-none"
                        />
                      </div>
                    </div>

                  </div>
                )}

              </div>

            </div>

            {/* General Disclaimer Alert Banner */}
            <div className="p-4 bg-blue-50/60 rounded-2xl border border-blue-100/50 flex gap-3 text-xs text-slate-600 leading-relaxed text-right">
              <ShieldAlert size={18} className="text-blue-500 shrink-0 mt-0.5" />
              <span>
                مخاطبین ذخیره شده در تمامی زیرسیستم‌های خزانه‌داری، خرید و فروش، حسابداری معین، فاکتورهای رسمی و انبارداری به صورت هماهنگ استفاده خواهند شد. اطمینان حاصل کنید که کدهای اقتصادی و شناسه ملی برای گزارش‌های فصلی دارایی دقیق وارد شده‌اند.
              </span>
            </div>

            {/* Bottom Actions Row */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
              <button 
                type="button"
                onClick={() => { setViewMode('list'); setEditingContact(null); }}
                className="text-xs font-bold text-slate-500 hover:text-slate-800 px-5 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 transition-all"
              >
                انصراف
              </button>
              <button 
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-6 py-2.5 rounded-xl shadow-xs transition-all duration-150"
              >
                {editingContact ? 'ویرایش و ذخیره تغییرات' : 'ثبت و بازگشت'}
              </button>
            </div>

          </form>

        </div>
      )}

    </div>
  );
}
