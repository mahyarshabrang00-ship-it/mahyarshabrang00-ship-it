/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Invoice, Contact, ItemService, InvoiceItem } from '../types';
import { 
  FileText, 
  Plus, 
  Search, 
  Trash2, 
  Printer, 
  CheckCircle, 
  Clock, 
  ChevronRight, 
  Eye, 
  PlusCircle, 
  MinusCircle, 
  Percent, 
  ArrowUpRight, 
  ArrowDownLeft 
} from 'lucide-react';

interface InvoicesProps {
  invoices: Invoice[];
  setInvoices: React.Dispatch<React.SetStateAction<Invoice[]>>;
  contacts: Contact[];
  setContacts: React.Dispatch<React.SetStateAction<Contact[]>>;
  items: ItemService[];
  setItems: React.Dispatch<React.SetStateAction<ItemService[]>>;
  selectedInvoiceId: string | null;
  setSelectedInvoiceId: (id: string | null) => void;
  companyInfo: any;
  subTabAction?: any;
  setSubTabAction?: any;
}

export default function Invoices({
  invoices,
  setInvoices,
  contacts,
  setContacts,
  items,
  setItems,
  selectedInvoiceId,
  setSelectedInvoiceId,
  companyInfo,
  subTabAction,
  setSubTabAction
}: InvoicesProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'sales' | 'purchase'>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Form Mode
  const [isCreating, setIsCreating] = useState(false);

  // Invoice Form State
  const [invoiceType, setInvoiceType] = useState<'sales' | 'purchase'>('sales');
  const [contactId, setContactId] = useState('');
  const [date, setDate] = useState('۱۴۰۵/۰۴/' + String(new Date().getDate()).padStart(2, '0'));
  const [dueDate, setDueDate] = useState('۱۴۰۵/۰۵/' + String(new Date().getDate()).padStart(2, '0'));
  const [description, setDescription] = useState('');
  const [taxRate, setTaxRate] = useState(10); // 10% value-added tax standard

  // Selected Items for current new invoice
  const [formItems, setFormItems] = useState<{
    itemId: string;
    qty: number;
    unitPrice: number;
    discount: number;
  }[]>([
    { itemId: '', qty: 1, unitPrice: 0, discount: 0 }
  ]);

  React.useEffect(() => {
    if (subTabAction && subTabAction.tab === 'invoices') {
      setSelectedInvoiceId(null);
      if (subTabAction.action === 'add-sales') {
        setInvoiceType('sales');
        setContactId('');
        setDescription('');
        setFormItems([{ itemId: '', qty: 1, unitPrice: 0, discount: 0 }]);
        setIsCreating(true);
      } else if (subTabAction.action === 'add-purchase') {
        setInvoiceType('purchase');
        setContactId('');
        setDescription('');
        setFormItems([{ itemId: '', qty: 1, unitPrice: 0, discount: 0 }]);
        setIsCreating(true);
      } else if (subTabAction.action === 'list-sales') {
        setFilterType('sales');
        setIsCreating(false);
      } else if (subTabAction.action === 'list-purchase') {
        setFilterType('purchase');
        setIsCreating(false);
      }
      if (setSubTabAction) {
        setSubTabAction(null);
      }
    }
  }, [subTabAction]);

  const formatMoney = (value: number) => {
    return value.toLocaleString('fa-IR') + ' تومان';
  };

  const formatNumber = (value: number) => {
    return value.toLocaleString('fa-IR');
  };

  // Calculations for current form items
  const calcSubtotal = () => {
    return formItems.reduce((sum, item) => {
      const p = item.unitPrice || 0;
      return sum + (p * item.qty);
    }, 0);
  };

  const calcDiscount = () => {
    return formItems.reduce((sum, item) => {
      return sum + (item.discount || 0);
    }, 0);
  };

  const calcTaxableAmount = () => {
    return calcSubtotal() - calcDiscount();
  };

  const calcTaxSum = (taxable: number) => {
    return Math.round(taxable * (taxRate / 100));
  };

  const calcTotal = () => {
    const taxable = calcTaxableAmount();
    return taxable + calcTaxSum(taxable);
  };

  // Add Item Row
  const addFormItemRow = () => {
    setFormItems([...formItems, { itemId: '', qty: 1, unitPrice: 0, discount: 0 }]);
  };

  // Remove Item Row
  const removeFormItemRow = (index: number) => {
    if (formItems.length === 1) return;
    setFormItems(formItems.filter((_, idx) => idx !== index));
  };

  // Update Item Row
  const updateFormItemRow = (index: number, key: string, value: any) => {
    setFormItems(formItems.map((item, idx) => {
      if (idx !== index) return item;
      const updated = { ...item, [key]: value };

      // If choosing a new item, autofill unit price
      if (key === 'itemId') {
        const found = items.find(i => i.id === value);
        if (found) {
          updated.unitPrice = invoiceType === 'sales' ? found.salePrice : found.purchasePrice;
        }
      }
      return updated;
    }));
  };

  // Save new invoice
  const handleSaveInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactId) {
      alert('لطفاً یک طرف حساب را انتخاب کنید.');
      return;
    }

    const selectedContact = contacts.find(c => c.id === contactId);
    if (!selectedContact) return;

    // Validate and format items
    const invoiceItems: InvoiceItem[] = [];
    for (const formItem of formItems) {
      if (!formItem.itemId) {
        alert('لطفاً کالا یا خدمات را برای تمامی ردیف‌ها انتخاب کنید.');
        return;
      }
      const foundItem = items.find(i => i.id === formItem.itemId);
      if (!foundItem) continue;

      const sub = formItem.qty * formItem.unitPrice;
      const tAmount = sub - formItem.discount;
      const taxAmount = Math.round(tAmount * (taxRate / 100));
      const totalAmount = tAmount + taxAmount;

      invoiceItems.push({
        id: 'ii_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
        itemId: formItem.itemId,
        itemName: foundItem.name,
        qty: formItem.qty,
        unitPrice: formItem.unitPrice,
        discount: formItem.discount,
        tax: taxAmount,
        total: totalAmount
      });
    }

    const subTotal = invoiceItems.reduce((sum, item) => sum + (item.qty * item.unitPrice), 0);
    const discTotal = invoiceItems.reduce((sum, item) => sum + item.discount, 0);
    const taxTotal = invoiceItems.reduce((sum, item) => sum + item.tax, 0);
    const finalTotal = subTotal - discTotal + taxTotal;

    const newInvoice: Invoice = {
      id: 'inv_' + Date.now(),
      number: (invoiceType === 'sales' ? 'F-' : 'B-') + (invoices.length + 1004),
      date,
      dueDate,
      type: invoiceType,
      contactId,
      contactName: selectedContact.name,
      items: invoiceItems,
      discount: discTotal,
      tax: taxTotal,
      total: finalTotal,
      paidAmount: 0, // initially unpaid
      status: 'unpaid',
      description
    };

    // Update stocks (if sales, subtract; if purchase, add)
    const updatedItems = items.map(i => {
      const matchInInvoice = invoiceItems.find(ii => ii.itemId === i.id);
      if (!matchInInvoice || i.isService) return i;
      const stockDiff = invoiceType === 'sales' ? -matchInInvoice.qty : matchInInvoice.qty;
      return { ...i, stock: Math.max(0, i.stock + stockDiff) };
    });

    // Update customer balance (if sales, increase debtor; if purchase, decrease debtor/increase creditor)
    const balanceDiff = invoiceType === 'sales' ? finalTotal : -finalTotal;
    const updatedContacts = contacts.map(c => {
      if (c.id !== contactId) return c;
      return { ...c, balance: c.balance + balanceDiff };
    });

    setItems(updatedItems);
    setContacts(updatedContacts);
    setInvoices([newInvoice, ...invoices]);
    setIsCreating(false);
    setSelectedInvoiceId(newInvoice.id); // Open print preview right after creation!
  };

  const handleDeleteInvoice = (id: string) => {
    const inv = invoices.find(i => i.id === id);
    if (!inv) return;

    if (confirm('آیا مطمئن هستید که می‌خواهید فاکتور شماره ' + inv.number + ' را حذف کنید؟ مانده حساب مشتری و موجودی انبار به حالت قبلی بازگردانده خواهند شد.')) {
      // Reverse stock and balance effects
      const updatedItems = items.map(i => {
        const matchInInvoice = inv.items.find(ii => ii.itemId === i.id);
        if (!matchInInvoice || i.isService) return i;
        const stockDiff = inv.type === 'sales' ? matchInInvoice.qty : -matchInInvoice.qty;
        return { ...i, stock: Math.max(0, i.stock + stockDiff) };
      });

      const balanceDiff = inv.type === 'sales' ? -inv.total : inv.total;
      const updatedContacts = contacts.map(c => {
        if (c.id !== inv.contactId) return c;
        return { ...c, balance: c.balance + balanceDiff };
      });

      setItems(updatedItems);
      setContacts(updatedContacts);
      setInvoices(invoices.filter(i => i.id !== id));
      if (selectedInvoiceId === id) setSelectedInvoiceId(null);
    }
  };

  // Filter invoices for display
  const filteredInvoices = invoices.filter(inv => {
    const matchesSearch = inv.number.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          inv.contactName.toLowerCase().includes(searchTerm.toLowerCase());
    if (!matchesSearch) return false;

    if (filterType !== 'all' && inv.type !== filterType) return false;

    if (filterStatus !== 'all') {
      if (inv.status !== filterStatus) return false;
    }

    return true;
  });

  const selectedInvoice = invoices.find(i => i.id === selectedInvoiceId);

  return (
    <div className="space-y-6">
      
      {/* List / Form Toggle View */}
      {!isCreating && !selectedInvoice && (
        <div className="space-y-6">
          
          {/* Filters Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
            
            {/* Search */}
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder="جستجوی شماره فاکتور یا طرف حساب..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full text-xs pr-10 pl-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200"
              />
            </div>

            {/* Quick selectors */}
            <div className="flex flex-wrap items-center gap-2">
              
              <div className="flex rounded-xl bg-slate-50 p-1 border border-slate-200">
                <button 
                  onClick={() => setFilterType('all')}
                  className={`text-xs px-3 py-1.5 rounded-lg transition-all duration-200 font-medium ${filterType === 'all' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  همه فاکتورها
                </button>
                <button 
                  onClick={() => setFilterType('sales')}
                  className={`text-xs px-3 py-1.5 rounded-lg transition-all duration-200 font-medium ${filterType === 'sales' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  فاکتورهای فروش
                </button>
                <button 
                  onClick={() => setFilterType('purchase')}
                  className={`text-xs px-3 py-1.5 rounded-lg transition-all duration-200 font-medium ${filterType === 'purchase' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  فاکتورهای خرید
                </button>
              </div>

              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">همه وضعیت‌ها</option>
                <option value="paid">تسویه کامل</option>
                <option value="unpaid">پرداخت نشده</option>
                <option value="partial">نیمه پرداخت</option>
                <option value="draft">پیش‌نویس</option>
              </select>

              <button 
                onClick={() => {
                  setFormItems([{ itemId: '', qty: 1, unitPrice: 0, discount: 0 }]);
                  setContactId('');
                  setDescription('');
                  setIsCreating(true);
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-sm shadow-blue-100 transition-all duration-200"
              >
                <Plus size={16} />
                <span>ثبت فاکتور جدید</span>
              </button>

            </div>

          </div>

          {/* Invoices Table */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100 text-slate-500 text-xs font-bold">
                    <th className="p-4">شماره فاکتور</th>
                    <th className="p-4">طرف حساب (مشتری/همکار)</th>
                    <th className="p-4">تاریخ صدور</th>
                    <th className="p-4">تاریخ سررسید</th>
                    <th className="p-4">مبلغ کل فاکتور</th>
                    <th className="p-4">مبلغ دریافتی/پرداختی</th>
                    <th className="p-4">وضعیت فاکتور</th>
                    <th className="p-4 text-left">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                  {filteredInvoices.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-12 text-center text-slate-400 font-medium">
                        <FileText size={40} className="mx-auto mb-3 text-slate-300" />
                        هیچ فاکتوری در سیستم یافت نشد.
                      </td>
                    </tr>
                  ) : (
                    filteredInvoices.map((inv) => (
                      <tr key={inv.id} className="hover:bg-slate-50/50 transition-colors duration-150">
                        <td className="p-4 font-bold text-slate-900 flex items-center gap-2">
                          <span className={`p-1.5 rounded-lg ${inv.type === 'sales' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                            {inv.type === 'sales' ? <ArrowDownLeft size={14} /> : <ArrowUpRight size={14} />}
                          </span>
                          <span>{inv.number}</span>
                        </td>
                        <td className="p-4 font-semibold text-slate-800">{inv.contactName}</td>
                        <td className="p-4 font-mono">{inv.date}</td>
                        <td className="p-4 font-mono">{inv.dueDate}</td>
                        <td className="p-4 font-bold text-slate-800">{formatMoney(inv.total)}</td>
                        <td className="p-4 text-slate-500">{formatMoney(inv.paidAmount)}</td>
                        <td className="p-4">
                          <span className={`inline-block text-[10px] px-2.5 py-1 rounded-full font-bold ${
                            inv.status === 'paid' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' :
                            inv.status === 'partial' ? 'bg-amber-50 text-amber-700 border border-amber-100' :
                            inv.status === 'overdue' ? 'bg-rose-50 text-rose-700 border border-rose-100' :
                            'bg-slate-100 text-slate-600 border border-slate-200'
                          }`}>
                            {inv.status === 'paid' && 'تسویه کامل'}
                            {inv.status === 'partial' && 'نیمه پرداخت'}
                            {inv.status === 'unpaid' && 'پرداخت نشده'}
                            {inv.status === 'overdue' && 'سررسید گذشته'}
                            {inv.status === 'draft' && 'پیش‌نویس'}
                          </span>
                        </td>
                        <td className="p-4 flex items-center justify-end gap-1.5">
                          <button 
                            onClick={() => setSelectedInvoiceId(inv.id)}
                            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors flex items-center gap-1 font-semibold"
                            title="مشاهده فاکتور و چاپ"
                          >
                            <Printer size={13} />
                            <span>چاپ / نمایش</span>
                          </button>
                          <button 
                            onClick={() => handleDeleteInvoice(inv.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="حذف فاکتور"
                          >
                            <Trash2 size={13} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* Invoice Wizard Form */}
      {isCreating && (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-md p-6 max-w-5xl mx-auto">
          
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <FileText size={18} className="text-blue-600" />
              <span>ایجاد فاکتور جدید در سیستم مالی</span>
            </h3>
            <button 
              onClick={() => setIsCreating(false)}
              className="text-xs font-semibold text-slate-500 hover:text-slate-700 bg-slate-50 hover:bg-slate-100 px-3 py-1.5 rounded-lg transition-colors"
            >
              بازگشت به لیست
            </button>
          </div>

          <form onSubmit={handleSaveInvoice} className="space-y-6">
            
            {/* Meta Data */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">نوع فاکتور *</label>
                <div className="flex gap-1 p-1 bg-slate-100 rounded-xl">
                  <button 
                    type="button"
                    onClick={() => {
                      setInvoiceType('sales');
                      // Reset prices based on type
                      setFormItems(formItems.map(f => ({ ...f, unitPrice: 0 })));
                    }}
                    className={`flex-1 text-xs py-2 rounded-lg font-bold transition-all duration-200 ${invoiceType === 'sales' ? 'bg-white text-emerald-600 shadow-xs' : 'text-slate-500'}`}
                  >
                    فاکتور فروش کالا
                  </button>
                  <button 
                    type="button"
                    onClick={() => {
                      setInvoiceType('purchase');
                      setFormItems(formItems.map(f => ({ ...f, unitPrice: 0 })));
                    }}
                    className={`flex-1 text-xs py-2 rounded-lg font-bold transition-all duration-200 ${invoiceType === 'purchase' ? 'bg-white text-rose-600 shadow-xs' : 'text-slate-500'}`}
                  >
                    فاکتور خرید کالا
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">طرف حساب (مشتری/همکار) *</label>
                <select
                  required
                  value={contactId}
                  onChange={(e) => setContactId(e.target.value)}
                  className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200"
                >
                  <option value="">-- انتخاب شخص --</option>
                  {contacts
                    .filter(c => invoiceType === 'sales' ? (c.type === 'customer' || c.type === 'both') : (c.type === 'supplier' || c.type === 'both'))
                    .map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.balance !== 0 ? `(مانده: ${c.balance.toLocaleString('fa-IR')} تومان)` : ''}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">تاریخ فاکتور *</label>
                <input 
                  type="text" 
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  placeholder="۱۴۰۵/۰۴/۱۷"
                  className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 text-center font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">تاریخ سررسید پرداخت *</label>
                <input 
                  type="text" 
                  required
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  placeholder="۱۴۰۵/۰۵/۱۷"
                  className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200 text-center font-mono"
                />
              </div>

            </div>

            {/* Items Matrix */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-bold text-slate-700">اقلام فاکتور (کالاها و خدمات)</h4>
                <button 
                  type="button"
                  onClick={addFormItemRow}
                  className="text-xs text-blue-600 font-bold hover:underline flex items-center gap-1"
                >
                  <PlusCircle size={14} />
                  <span>افزودن ردیف جدید</span>
                </button>
              </div>

              <div className="border border-slate-100 rounded-xl overflow-hidden shadow-xs">
                <table className="w-full text-right border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-100 text-slate-500 text-xs font-bold">
                      <th className="p-3 w-12 text-center">#</th>
                      <th className="p-3">انتخاب کالا یا خدمت *</th>
                      <th className="p-3 w-24">تعداد/مقدار</th>
                      <th className="p-3 w-40">فی (تومان) *</th>
                      <th className="p-3 w-32">تخفیف (تومان)</th>
                      <th className="p-3 w-40 text-left">جمع ردیف (تومان)</th>
                      <th className="p-3 w-12 text-center">حذف</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {formItems.map((formItem, index) => {
                      const selectedItemDetails = items.find(i => i.id === formItem.itemId);
                      const rowTotal = (formItem.unitPrice * formItem.qty) - formItem.discount;

                      return (
                        <tr key={index} className="hover:bg-slate-50/30">
                          <td className="p-3 text-center text-slate-400 font-bold">{index + 1}</td>
                          <td className="p-3">
                            <select
                              required
                              value={formItem.itemId}
                              onChange={(e) => updateFormItemRow(index, 'itemId', e.target.value)}
                              className="w-full text-xs px-2 py-1.5 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500"
                            >
                              <option value="">-- کالا/خدمت را انتخاب کنید --</option>
                              {items.map(item => (
                                <option key={item.id} value={item.id}>
                                  {item.name} {!item.isService ? `(موجودی انبار: ${formatNumber(item.stock)} ${item.unit})` : '(خدمت)'}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="p-3">
                            <input 
                              type="number" 
                              required
                              min={1}
                              value={formItem.qty}
                              onChange={(e) => updateFormItemRow(index, 'qty', Number(e.target.value))}
                              className="w-full text-xs px-2 py-1 border border-slate-200 rounded-lg text-center"
                            />
                          </td>
                          <td className="p-3">
                            <input 
                              type="number" 
                              required
                              value={formItem.unitPrice}
                              onChange={(e) => updateFormItemRow(index, 'unitPrice', Number(e.target.value))}
                              className="w-full text-xs px-2 py-1 border border-slate-200 rounded-lg text-left font-mono"
                              dir="ltr"
                            />
                          </td>
                          <td className="p-3">
                            <input 
                              type="number" 
                              value={formItem.discount}
                              onChange={(e) => updateFormItemRow(index, 'discount', Number(e.target.value))}
                              className="w-full text-xs px-2 py-1 border border-slate-200 rounded-lg text-left font-mono"
                              dir="ltr"
                            />
                          </td>
                          <td className="p-3 text-left font-bold text-slate-700 font-mono">
                            {rowTotal >= 0 ? rowTotal.toLocaleString('fa-IR') : '۰'}
                          </td>
                          <td className="p-3 text-center">
                            <button 
                              type="button"
                              onClick={() => removeFormItemRow(index)}
                              className="text-slate-400 hover:text-rose-500 p-1"
                              disabled={formItems.length === 1}
                            >
                              ×
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Calculations Grid & Tax settings */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100">
              
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">شرح و توضیحات پایانی فاکتور</label>
                <textarea 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="این متن در پایین فاکتور چاپی نمایش داده خواهد شد..."
                  rows={3}
                  className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                ></textarea>

                <div className="mt-4 flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                  <span className="font-semibold text-slate-600">محاسبه مالیات بر ارزش افزوده (۱۰٪):</span>
                  <div className="flex rounded-lg bg-slate-200 p-0.5">
                    <button 
                      type="button"
                      onClick={() => setTaxRate(10)}
                      className={`px-3 py-1 text-[11px] rounded-md font-bold transition-all ${taxRate === 10 ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500'}`}
                    >
                      بله (۱۰٪)
                    </button>
                    <button 
                      type="button"
                      onClick={() => setTaxRate(0)}
                      className={`px-3 py-1 text-[11px] rounded-md font-bold transition-all ${taxRate === 0 ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500'}`}
                    >
                      بدون مالیات
                    </button>
                  </div>
                </div>
              </div>

              {/* totals */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100 space-y-3.5">
                <div className="flex justify-between text-xs font-medium text-slate-600">
                  <span>جمع کل اقلام (ناخالص):</span>
                  <span className="font-mono">{formatMoney(calcSubtotal())}</span>
                </div>
                <div className="flex justify-between text-xs font-medium text-amber-700">
                  <span>جمع تخفیفات اعطایی:</span>
                  <span className="font-mono">- {formatMoney(calcDiscount())}</span>
                </div>
                <div className="flex justify-between text-xs font-medium text-slate-600">
                  <span>مبلغ مشمول مالیات:</span>
                  <span className="font-mono">{formatMoney(calcTaxableAmount())}</span>
                </div>
                <div className="flex justify-between text-xs font-medium text-violet-700">
                  <span>مالیات بر ارزش افزوده ({formatNumber(taxRate)}٪):</span>
                  <span className="font-mono">+ {formatMoney(calcTaxSum(calcTaxableAmount()))}</span>
                </div>
                
                <div className="border-t border-slate-200 pt-3.5 flex justify-between text-sm font-bold text-slate-800">
                  <span>مبلغ کل نهایی فاکتور:</span>
                  <span className="text-blue-700 text-base font-mono">{formatMoney(calcTotal())}</span>
                </div>
              </div>

            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-2 pt-6 border-t border-slate-100">
              <button 
                type="button"
                onClick={() => setIsCreating(false)}
                className="text-xs font-bold text-slate-500 hover:text-slate-700 px-5 py-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors"
              >
                انصراف و لغو
              </button>
              <button 
                type="submit"
                className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-6 py-2.5 rounded-xl shadow-sm transition-colors"
              >
                تایید و صدور نهایی فاکتور
              </button>
            </div>

          </form>

        </div>
      )}

      {/* Invoice Details & Print View Screen */}
      {selectedInvoice && (
        <div className="space-y-6">
          
          {/* Action Toolbar for print */}
          <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-100 shadow-xs print:hidden">
            <button 
              onClick={() => setSelectedInvoiceId(null)}
              className="text-xs font-bold text-slate-600 hover:text-slate-800 bg-slate-50 hover:bg-slate-100 px-3 py-2 rounded-xl transition-colors flex items-center gap-1.5"
            >
              <ChevronRight size={16} />
              <span>بازگشت به لیست فاکتورها</span>
            </button>

            <div className="flex items-center gap-2">
              <button 
                onClick={() => window.print()}
                className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-2 transition-colors shadow-sm"
              >
                <Printer size={15} />
                <span>چاپ فاکتور رسمی</span>
              </button>
            </div>
          </div>

          {/* High Fidelity Formal Iranian Invoice Paper layout */}
          <div className="bg-white border border-slate-300 p-8 rounded-2xl shadow-md max-w-4xl mx-auto font-vazir print:border-0 print:shadow-none print:p-0">
            
            {/* Header section */}
            <div className="border-b-2 border-slate-800 pb-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-xl flex items-center justify-center font-bold text-lg">
                  ح
                </div>
                <div>
                  <h2 className="text-base font-bold text-slate-900">{companyInfo.name || 'حسابفا'}</h2>
                  <p className="text-[10px] text-slate-400 mt-0.5">صورتحساب رسمی فروش کالا و خدمات</p>
                </div>
              </div>

              <div className="text-center bg-slate-100/60 p-3 rounded-xl border border-slate-200">
                <h1 className="text-sm font-black text-slate-800 tracking-wide">صورتحساب رسمی</h1>
              </div>

              <div className="text-left text-[11px] text-slate-600 space-y-1">
                <div><span className="font-semibold">شماره فاکتور:</span> <span className="font-bold text-slate-900 font-mono">{selectedInvoice.number}</span></div>
                <div><span className="font-semibold">تاریخ صدور:</span> <span className="font-mono">{selectedInvoice.date}</span></div>
                <div><span className="font-semibold">تاریخ سررسید:</span> <span className="font-mono">{selectedInvoice.dueDate}</span></div>
              </div>
            </div>

            {/* Seller and Buyer information panels */}
            <div className="grid grid-cols-1 md:grid-cols-2 border border-slate-300 rounded-xl overflow-hidden mt-6 text-[11px] leading-relaxed">
              
              {/* Seller details */}
              <div className="p-4 border-b md:border-b-0 md:border-l border-slate-300">
                <h3 className="font-black text-slate-800 mb-2 border-b border-slate-200 pb-1 text-xs">مشخصات فروشنده</h3>
                <div className="space-y-1 text-slate-700">
                  <div><span className="font-bold">نام شخص حقوقی:</span> {companyInfo.name}</div>
                  <div><span className="font-bold">شماره اقتصادی:</span> {companyInfo.taxNumber || '۱۰۳۲۰۰۴۴۸۸۱'}</div>
                  <div><span className="font-bold">تلفن:</span> {companyInfo.phone}</div>
                  <div><span className="font-bold">نشانی:</span> {companyInfo.address}</div>
                </div>
              </div>

              {/* Buyer details */}
              <div className="p-4">
                <h3 className="font-black text-slate-800 mb-2 border-b border-slate-200 pb-1 text-xs">مشخصات خریدار</h3>
                <div className="space-y-1 text-slate-700">
                  <div><span className="font-bold">نام شخص حقیقی/حقوقی:</span> {selectedInvoice.contactName}</div>
                  <div><span className="font-bold">شناسه اقتصادی / کد ملی:</span> {
                    contacts.find(c => c.id === selectedInvoice.contactId)?.nationalId || 'ثبت نشده'
                  }</div>
                  <div><span className="font-bold">تلفن تماس:</span> {
                    contacts.find(c => c.id === selectedInvoice.contactId)?.phone || 'ثبت نشده'
                  }</div>
                  <div><span className="font-bold">نشانی کامل:</span> {
                    contacts.find(c => c.id === selectedInvoice.contactId)?.address || 'نشانی ثبت نشده است'
                  }</div>
                </div>
              </div>

            </div>

            {/* Items table */}
            <div className="border border-slate-300 rounded-xl overflow-hidden mt-6 text-[11px]">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-300 text-slate-800 font-bold">
                    <th className="p-2 border-l border-slate-300 text-center w-10">ردیف</th>
                    <th className="p-2 border-l border-slate-300">شرح کالا یا خدمات</th>
                    <th className="p-2 border-l border-slate-300 text-center w-12">تعداد</th>
                    <th className="p-2 border-l border-slate-300 text-left w-28">مبلغ واحد (ریال/تومان)</th>
                    <th className="p-2 border-l border-slate-300 text-left w-24">مبلغ تخفیف</th>
                    <th className="p-2 border-l border-slate-300 text-left w-24">مالیات ارزش افزوده</th>
                    <th className="p-2 text-left w-32">جمع کل ردیف (تومان)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-300 text-slate-700">
                  {selectedInvoice.items.map((item, idx) => (
                    <tr key={item.id}>
                      <td className="p-2 border-l border-slate-300 text-center font-bold">{idx + 1}</td>
                      <td className="p-2 border-l border-slate-300 font-medium">{item.itemName}</td>
                      <td className="p-2 border-l border-slate-300 text-center font-mono">{formatNumber(item.qty)}</td>
                      <td className="p-2 border-l border-slate-300 text-left font-mono">{formatNumber(item.unitPrice)}</td>
                      <td className="p-2 border-l border-slate-300 text-left font-mono text-amber-700">{formatNumber(item.discount)}</td>
                      <td className="p-2 border-l border-slate-300 text-left font-mono text-violet-700">{formatNumber(item.tax)}</td>
                      <td className="p-2 text-left font-black font-mono text-slate-800">{formatNumber(item.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Financial summary blocks */}
            <div className="grid grid-cols-1 md:grid-cols-2 border border-slate-300 rounded-xl mt-6 text-[11px] divide-y md:divide-y-0 md:divide-x md:divide-x-reverse divide-slate-300">
              
              <div className="p-4 flex flex-col justify-between">
                <div>
                  <span className="font-bold text-slate-800">توضیحات و شرایط پرداخت:</span>
                  <p className="text-slate-600 mt-1 leading-relaxed">
                    {selectedInvoice.description || 'وجه فاکتور فوق طبق تاریخ سررسید مندرج در بالای فاکتور به حساب‌های معتبر اعلامی شرکت واریز گردد. از حسن اعتماد شما سپاسگزاریم.'}
                  </p>
                </div>
                <div className="pt-4 text-slate-500 font-medium italic">
                  نرم افزار حسابداری آنلاین حسابفا • Hesabfa Demo
                </div>
              </div>

              <div className="p-4 space-y-2 text-slate-700">
                <div className="flex justify-between">
                  <span>جمع ناخالص کل فاکتور:</span>
                  <span className="font-mono font-bold">{formatMoney(selectedInvoice.total + selectedInvoice.discount - selectedInvoice.tax)}</span>
                </div>
                <div className="flex justify-between text-amber-700">
                  <span>جمع تخفیفات اعمال شده:</span>
                  <span className="font-mono font-bold">- {formatMoney(selectedInvoice.discount)}</span>
                </div>
                <div className="flex justify-between text-violet-700">
                  <span>جمع مالیات بر ارزش افزوده:</span>
                  <span className="font-mono font-bold">+ {formatMoney(selectedInvoice.tax)}</span>
                </div>
                <div className="border-t border-slate-300 pt-2 flex justify-between text-xs font-black text-slate-900 bg-slate-50 p-2 rounded-lg">
                  <span>جمع نهایی قابل پرداخت:</span>
                  <span className="font-mono text-blue-800">{formatMoney(selectedInvoice.total)}</span>
                </div>
              </div>

            </div>

            {/* Signatures section */}
            <div className="grid grid-cols-2 mt-8 text-[11px] font-bold text-slate-700 text-center gap-4 pt-12">
              <div className="border border-slate-200 p-6 rounded-xl border-dashed">
                <span>مهر و امضای فروشنده</span>
                <div className="h-16 flex items-center justify-center text-slate-300 font-light italic">شرکت پدیده پرداز البرز</div>
              </div>
              <div className="border border-slate-200 p-6 rounded-xl border-dashed">
                <span>مهر و امضای خریدار</span>
                <div className="h-16 flex items-center justify-center text-slate-300 font-light italic">گواهی دریافت و تایید کالا</div>
              </div>
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
