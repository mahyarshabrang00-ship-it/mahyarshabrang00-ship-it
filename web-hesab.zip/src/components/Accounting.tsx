/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  FileText, 
  Plus, 
  Trash2, 
  Coins, 
  ArrowRightLeft, 
  Calculator, 
  CheckCircle, 
  Lock, 
  AlertCircle 
} from 'lucide-react';

interface AccountingProps {
  subTabAction?: any;
  setSubTabAction?: any;
}

interface JournalEntry {
  id: string;
  docNum: string;
  date: string;
  description: string;
  rows: {
    accountCode: string;
    accountName: string;
    debit: number; // بدهکار
    credit: number; // بستانکار
  }[];
  isSystemGenerated: boolean;
}

interface AccountNode {
  code: string;
  name: string;
  category: 'asset' | 'liability' | 'equity' | 'revenue' | 'expense';
  balance: number;
}

export default function Accounting({ subTabAction, setSubTabAction }: AccountingProps) {
  const [activeTab, setActiveTab] = useState<'entries' | 'accounts' | 'closing' | 'opening'>('entries');

  // Chart of accounts state
  const [accounts, setAccounts] = useState<AccountNode[]>([
    // Assets
    { code: '10101', name: 'بانک ملی ایران', category: 'asset', balance: 450000000 },
    { code: '10102', name: 'صندوق مرکزی شرکت', category: 'asset', balance: 75000000 },
    { code: '10301', name: 'حساب‌های دریافتنی اشخاص', category: 'asset', balance: 120000000 },
    { code: '10501', name: 'موجودی انبار کالا', category: 'asset', balance: 350000000 },
    // Liabilities
    { code: '20101', name: 'حساب‌های پرداختنی تامین‌کنندگان', category: 'liability', balance: 90000000 },
    { code: '20401', name: 'مالیات بر ارزش افزوده پرداختی', category: 'liability', balance: 32000000 },
    // Equity
    { code: '30101', name: 'سرمایه اولیه شرکا', category: 'equity', balance: 800000000 },
    // Revenues
    { code: '40101', name: 'درآمد حاصل از فروش کالا', category: 'revenue', balance: 145000000 },
    // Expenses
    { code: '50101', name: 'بهای تمام شده کالای فروش رفته', category: 'expense', balance: 80000000 },
    { code: '50201', name: 'هزینه اجاره دفتر', category: 'expense', balance: 42000000 }
  ]);

  // Initial Journal Entries
  const [entries, setEntries] = useState<JournalEntry[]>([
    {
      id: 'je-301',
      docNum: 'ACC-101',
      date: '۱۴۰۵/۰۴/۰۱',
      description: 'ثبت افتتاحیه حساب‌ها و موازنه دارایی/بدهی اولیه',
      isSystemGenerated: false,
      rows: [
        { accountCode: '10101', accountName: 'بانک ملی ایران', debit: 450000000, credit: 0 },
        { accountCode: '10102', accountName: 'صندوق مرکزی شرکت', debit: 75000000, credit: 0 },
        { accountCode: '30101', accountName: 'سرمایه اولیه شرکا', debit: 0, credit: 525000000 }
      ]
    },
    {
      id: 'je-302',
      docNum: 'ACC-102',
      date: '۱۴۰۵/۰۴/۱۶',
      description: 'سند اتوماتیک تسویه فاکتور فروش شماره ۱۰۳',
      isSystemGenerated: true,
      rows: [
        { accountCode: '10101', accountName: 'بانک ملی ایران', debit: 12000000, credit: 0 },
        { accountCode: '10301', accountName: 'حساب‌های دریافتنی اشخاص', debit: 0, credit: 12000000 }
      ]
    }
  ]);

  // Form States for New Document
  const [isNewDocOpen, setIsNewDocOpen] = useState(false);
  const [docDesc, setDocDesc] = useState('');
  const [docRows, setDocRows] = useState<{ accountCode: string; debit: number; credit: number }[]>([
    { accountCode: '', debit: 0, credit: 0 },
    { accountCode: '', debit: 0, credit: 0 }
  ]);

  // Financial Year Closure simulation states
  const [isClosed, setIsClosed] = useState(false);
  const [closureLogs, setClosureLogs] = useState<string[]>([]);

  // Responsive sidebar commands
  React.useEffect(() => {
    if (subTabAction && subTabAction.tab === 'accounting') {
      if (subTabAction.action === 'new-entry') {
        setActiveTab('entries');
        setIsNewDocOpen(true);
      } else if (subTabAction.action === 'accounts-chart') {
        setActiveTab('accounts');
      } else if (subTabAction.action === 'closing-year') {
        setActiveTab('closing');
      } else if (subTabAction.action === 'opening-balance') {
        setActiveTab('opening');
      }
      if (setSubTabAction) {
        setSubTabAction(null);
      }
    }
  }, [subTabAction]);

  const formatMoney = (val: number) => val.toLocaleString('fa-IR') + ' تومان';
  const formatNumber = (val: number) => val.toLocaleString('fa-IR');

  const addDocRow = () => {
    setDocRows([...docRows, { accountCode: '', debit: 0, credit: 0 }]);
  };

  const removeDocRow = (index: number) => {
    setDocRows(docRows.filter((_, i) => i !== index));
  };

  const handleRowChange = (index: number, field: 'accountCode' | 'debit' | 'credit', value: any) => {
    const updated = [...docRows];
    if (field === 'accountCode') {
      updated[index].accountCode = String(value);
    } else {
      updated[index][field] = Number(value);
    }
    setDocRows(updated);
  };

  const totalDebits = docRows.reduce((sum, r) => sum + (r.debit || 0), 0);
  const totalCredits = docRows.reduce((sum, r) => sum + (r.credit || 0), 0);
  const isBalanced = totalDebits === totalCredits && totalDebits > 0;

  const handleCreateDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isBalanced) {
      alert('سند حسابداری موازنه نیست! جمع بدهکار و بستانکار باید کاملاً برابر و بزرگتر از صفر باشد.');
      return;
    }

    const compiledRows = docRows.map(row => {
      const acc = accounts.find(a => a.code === row.accountCode);
      return {
        accountCode: row.accountCode,
        accountName: acc ? acc.name : 'سرفصل نامشخص',
        debit: row.debit,
        credit: row.credit
      };
    });

    const newDoc: JournalEntry = {
      id: 'je-' + Date.now(),
      docNum: 'ACC-' + (100 + entries.length + 1),
      date: '۱۴۰۵/۰۴/' + String(new Date().getDate()).padStart(2, '0'),
      description: docDesc || 'سند دستی حسابداری',
      isSystemGenerated: false,
      rows: compiledRows
    };

    // Update balances of accounts
    const updatedAccounts = accounts.map(acc => {
      let adjustment = 0;
      compiledRows.forEach(row => {
        if (row.accountCode === acc.code) {
          adjustment += (row.debit - row.credit);
        }
      });
      // Assets and Expenses increase with debit, decrease with credit.
      // Liabilities, Equity, Revenues increase with credit, decrease with debit.
      const isDebitNature = acc.category === 'asset' || acc.category === 'expense';
      const change = isDebitNature ? adjustment : -adjustment;
      return { ...acc, balance: acc.balance + change };
    });

    setAccounts(updatedAccounts);
    setEntries([newDoc, ...entries]);
    setIsNewDocOpen(false);

    // Reset Form
    setDocDesc('');
    setDocRows([
      { accountCode: '', debit: 0, credit: 0 },
      { accountCode: '', debit: 0, credit: 0 }
    ]);
    alert('سند حسابداری با موفقیت تایید و در دفاتر ثبت معین شد!');
  };

  const handleCloseFinancialYear = () => {
    if (confirm('آیا مطمئن هستید که می‌خواهید سال مالی جاری را ببندید؟ این عملیات سود/زیان را به حساب انباشته منتقل می‌کند.')) {
      setClosureLogs([
        'در حال استخراج مانده کلیه حساب‌های موقت...',
        'محاسبه سود انباشته سال جاری...',
        'ثبت سند بستن حساب‌های درآمدی به حساب خلاصه سود و زیان (سرفصل معین ۳۰۱)',
        'بستن حساب‌های هزینه‌ای به خلاصه سود و زیان معین معکوس...',
        'انتقال مانده سود و زیان ویژه به سود انباشته...',
        'آماده‌سازی ترازنامه پایانی سال مالی ۱۴۰۵...'
      ]);
      setTimeout(() => {
        setIsClosed(true);
        alert('سال مالی با موفقیت بسته شد و اسناد انتقال موقت صادر گردیدند!');
      }, 1500);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Sub tabs header */}
      <div className="flex border-b border-slate-200/40 pb-px print:hidden">
        <button
          onClick={() => setActiveTab('entries')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'entries' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <FileText size={14} />
          دفتر روزنامه و اسناد حسابداری
        </button>
        <button
          onClick={() => setActiveTab('accounts')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'accounts' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Coins size={14} />
          جدول حساب‌ها (کدینگ معین)
        </button>
        <button
          onClick={() => setActiveTab('opening')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'opening' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <ArrowRightLeft size={14} />
          تراز افتتاحیه سند اول
        </button>
        <button
          onClick={() => setActiveTab('closing')}
          className={`px-5 py-2.5 font-bold text-xs transition-colors border-b-2 -mb-px flex items-center gap-2 cursor-pointer ${
            activeTab === 'closing' 
              ? 'border-blue-600 text-blue-600 font-black' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
          }`}
        >
          <Lock size={14} />
          بستن سال مالی شرکت
        </button>
      </div>

      {/* JOURNAL ENTRIES TAB */}
      {activeTab === 'entries' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-slate-700">اسناد حسابداری ثبت شده در معین کل</h3>
            <button
              onClick={() => setIsNewDocOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold px-3 py-2 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm shadow-blue-100"
            >
              <Plus size={14} />
              ثبت سند حسابداری جدید
            </button>
          </div>

          <div className="space-y-4">
            {entries.map(entry => (
              <div key={entry.id} className="bg-white border border-slate-100 rounded-3xl p-5 shadow-xs">
                <div className="flex flex-wrap items-center justify-between pb-3 border-b border-slate-50 gap-2 mb-3">
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-black text-xs text-slate-800 bg-slate-50 px-2.5 py-1 rounded-lg">
                      {entry.docNum}
                    </span>
                    <span className="font-black text-xs text-slate-700">{entry.description}</span>
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-slate-400">
                    <span className="font-mono">{entry.date}</span>
                    {entry.isSystemGenerated && (
                      <span className="bg-blue-50 text-blue-700 font-bold px-2 py-0.5 rounded-md">سیستمی</span>
                    )}
                  </div>
                </div>

                {/* Rows Grid */}
                <div className="overflow-x-auto">
                  <table className="w-full text-right text-xs">
                    <thead className="text-slate-400 font-semibold border-b border-slate-50 pb-2">
                      <tr>
                        <th className="py-2">کد حساب</th>
                        <th className="py-2">سرفصل حسابداری معین</th>
                        <th className="py-2 text-left">بدهکار (تومان)</th>
                        <th className="py-2 text-left">بستانکار (تومان)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50/50">
                      {entry.rows.map((row, idx) => (
                        <tr key={idx} className="text-slate-600 py-2">
                          <td className="py-2 font-mono text-[10px] text-slate-400">{row.accountCode}</td>
                          <td className="py-2 font-bold text-slate-700">{row.accountName}</td>
                          <td className="py-2 font-mono text-left font-black text-slate-800">
                            {row.debit > 0 ? formatNumber(row.debit) : '۰'}
                          </td>
                          <td className="py-2 font-mono text-left font-black text-slate-800">
                            {row.credit > 0 ? formatNumber(row.credit) : '۰'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </div>

          {/* New Journal Entry Modal */}
          {isNewDocOpen && (
            <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
              <div className="bg-white border border-slate-100 rounded-3xl w-full max-w-2xl shadow-2xl p-6 text-right max-h-[85vh] overflow-y-auto">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                  <h3 className="font-black text-slate-800 text-sm">ثبت سند دستی حسابداری (دوطرفه)</h3>
                  <button onClick={() => setIsNewDocOpen(false)} className="text-slate-400 hover:text-slate-600 text-lg cursor-pointer">×</button>
                </div>

                <form onSubmit={handleCreateDocument} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1">شرح کلی سند حسابداری</label>
                    <input
                      type="text"
                      required
                      value={docDesc}
                      onChange={(e) => setDocDesc(e.target.value)}
                      placeholder="مانند: ثبت فاکتور هزینه شارژ اینترنت دفتر"
                      className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-100 focus:outline-hidden focus:border-blue-500 font-semibold"
                    />
                  </div>

                  {/* Rows editor */}
                  <div className="space-y-2 border-t border-slate-50 pt-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-slate-500">لیست آرتیکل‌های مالی سند</span>
                      <button
                        type="button"
                        onClick={addDocRow}
                        className="text-blue-600 hover:text-blue-700 font-black text-[10px] flex items-center gap-1 cursor-pointer"
                      >
                        <Plus size={12} />
                        افزودن ردیف معین
                      </button>
                    </div>

                    {docRows.map((row, index) => (
                      <div key={index} className="flex items-center gap-2 bg-slate-50/40 p-2 rounded-xl border border-slate-50">
                        <div className="flex-1">
                          <select
                            required
                            value={row.accountCode}
                            onChange={(e) => handleRowChange(index, 'accountCode', e.target.value)}
                            className="w-full text-xs bg-white p-2 rounded-lg border border-slate-100"
                          >
                            <option value="">انتخاب سرفصل معین...</option>
                            {accounts.map(acc => (
                              <option key={acc.code} value={acc.code}>{acc.code} - {acc.name}</option>
                            ))}
                          </select>
                        </div>
                        <div className="w-28">
                          <input
                            type="number"
                            required
                            min="0"
                            value={row.debit}
                            onChange={(e) => handleRowChange(index, 'debit', e.target.value)}
                            placeholder="بدهکار (تومان)"
                            className="w-full text-xs bg-white p-2 rounded-lg border border-slate-100 text-center font-mono font-bold text-emerald-600"
                          />
                        </div>
                        <div className="w-28">
                          <input
                            type="number"
                            required
                            min="0"
                            value={row.credit}
                            onChange={(e) => handleRowChange(index, 'credit', e.target.value)}
                            placeholder="بستانکار (تومان)"
                            className="w-full text-xs bg-white p-2 rounded-lg border border-slate-100 text-center font-mono font-bold text-rose-600"
                          />
                        </div>
                        {docRows.length > 2 && (
                          <button
                            type="button"
                            onClick={() => removeDocRow(index)}
                            className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg cursor-pointer"
                          >
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Balanced status indicator */}
                  <div className="flex items-center justify-between p-3.5 rounded-xl text-xs bg-slate-50 border border-slate-100 font-bold">
                    <div>
                      <span>جمع بدهکار: {formatMoney(totalDebits)}</span>
                      <span className="mx-2 text-slate-300">|</span>
                      <span>جمع بستانکار: {formatMoney(totalCredits)}</span>
                    </div>
                    {isBalanced ? (
                      <span className="text-emerald-600 flex items-center gap-1">
                        <CheckCircle size={14} />
                        سند موازنه است
                      </span>
                    ) : (
                      <span className="text-rose-500 flex items-center gap-1">
                        <AlertCircle size={14} />
                        ناموزون
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setIsNewDocOpen(false)}
                      className="px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-50 rounded-xl cursor-pointer"
                    >
                      انصراف
                    </button>
                    <button
                      type="submit"
                      disabled={!isBalanced}
                      className={`text-xs font-black px-4 py-2 rounded-xl cursor-pointer ${
                        isBalanced 
                          ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-sm' 
                          : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      تایید و صدور سند
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* CHART OF ACCOUNTS TAB */}
      {activeTab === 'accounts' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-slate-700">کدینگ سرفصل‌های معین مالی شرکت</h3>
            <span className="bg-slate-100 text-slate-600 text-[10px] font-bold px-3 py-1 rounded-lg">کدینگ استاندارد حسابداری ایران</span>
          </div>

          <div className="bg-white border border-slate-100 rounded-3xl shadow-xs overflow-hidden">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-100 text-slate-500 font-bold">
                <tr>
                  <th className="p-4">کد معین</th>
                  <th className="p-4">نام سرفصل</th>
                  <th className="p-4">گروه حساب</th>
                  <th className="p-4 text-left">مانده زنده سرفصل</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {accounts.map(acc => (
                  <tr key={acc.code} className="hover:bg-slate-50/40">
                    <td className="p-4 font-mono font-black text-slate-400">{acc.code}</td>
                    <td className="p-4 font-bold text-slate-800">{acc.name}</td>
                    <td className="p-4">
                      <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold ${
                        acc.category === 'asset' ? 'bg-blue-50 text-blue-700' :
                        acc.category === 'liability' ? 'bg-amber-50 text-amber-700' :
                        acc.category === 'equity' ? 'bg-violet-50 text-violet-700' :
                        acc.category === 'revenue' ? 'bg-emerald-50 text-emerald-700' :
                        'bg-rose-50 text-rose-700'
                      }`}>
                        {acc.category === 'asset' && 'دارایی'}
                        {acc.category === 'liability' && 'بدهی'}
                        {acc.category === 'equity' && 'حقوق صاحبان سهام'}
                        {acc.category === 'revenue' && 'درآمد فروش'}
                        {acc.category === 'expense' && 'هزینه‌ها'}
                      </span>
                    </td>
                    <td className="p-4 font-mono text-left font-black text-slate-700">{formatMoney(acc.balance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* OPENING BALANCE TAB */}
      {activeTab === 'opening' && (
        <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-xs space-y-4">
          <h4 className="font-black text-xs text-slate-800">ترازنامه افتتاحیه اولیه</h4>
          <p className="text-[10px] text-slate-400">تنظیم ترازنامه مبنا به شما کمک می‌کند مانده کارت‌های بانکی، مطالبات قبلی از اشخاص و موجودی اولیه انبار را به صورت اتوماتیک از سال قبل به دفاتر منتقل نمایید.</p>

          <div className="bg-slate-50/50 border border-slate-100 rounded-2xl p-4 flex items-center justify-between text-xs">
            <div>
              <span className="font-bold text-slate-700 block">جمع دارایی‌های انتقال یافته اولیه</span>
              <span className="text-[10px] text-slate-400">براساس سرفصل‌های فعال بانک، صندوق و انبار</span>
            </div>
            <span className="font-black text-blue-600 text-sm">{formatMoney(525000000)}</span>
          </div>
        </div>
      )}

      {/* CLOSING YEAR TAB */}
      {activeTab === 'closing' && (
        <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-xs space-y-4">
          <h4 className="font-black text-xs text-slate-800">بستن دفاتر و اختتام سال مالی</h4>
          <p className="text-[10px] text-slate-400">پس از اتمام کلیه کارهای حسابداری، موازنه دفاتر معین و تایید بدهکار/بستانکار، سرفصل‌های موقت سود و زیان بسته و مانده آنها به سرمایه سال مالی جدید منتقل می‌گردد.</p>

          {!isClosed ? (
            <div className="space-y-4">
              <button
                onClick={handleCloseFinancialYear}
                className="bg-rose-600 hover:bg-rose-700 text-white text-xs font-black px-4 py-2.5 rounded-xl cursor-pointer shadow-sm shadow-rose-100 flex items-center gap-1.5"
              >
                <Lock size={14} />
                اجرای فرآیند بستن دفاتر سال ۱۴۰۵
              </button>

              {closureLogs.length > 0 && (
                <div className="bg-slate-900 text-slate-300 font-mono text-[10px] p-4 rounded-2xl space-y-1 w-full max-w-lg text-right">
                  {closureLogs.map((log, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className="text-slate-500 font-bold select-none">{i+1}.</span>
                      <span>{log}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-4 flex items-center gap-3">
              <CheckCircle className="text-emerald-600" size={24} />
              <div>
                <span className="font-black text-xs text-emerald-800 block">سال مالی با موفقیت بسته شد</span>
                <span className="text-[10px] text-emerald-600 mt-1 block">کلیه کدهای موقت به مانده سود تایید شده سال جدید موازنه و منتقل شد.</span>
              </div>
            </div>
          )}
        </div>
      )}

    </div>
  );
}
