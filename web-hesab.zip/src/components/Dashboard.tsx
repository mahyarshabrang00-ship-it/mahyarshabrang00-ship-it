/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Contact, 
  Invoice, 
  BankAccount, 
  Transaction, 
  Task 
} from '../types';
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  CreditCard, 
  DollarSign, 
  CheckSquare, 
  Plus, 
  Trash2, 
  ChevronLeft, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ArrowLeftRight 
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';

interface DashboardProps {
  contacts: Contact[];
  invoices: Invoice[];
  banks: BankAccount[];
  transactions: Transaction[];
  tasks: Task[];
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
  setCurrentTab: (tab: string) => void;
  setSelectedInvoiceId: (id: string | null) => void;
}

const COLORS = ['#0284c7', '#0ea5e9', '#38bdf8', '#7dd3fc', '#bae6fd'];

export default function Dashboard({
  contacts,
  invoices,
  banks,
  transactions,
  tasks,
  setTasks,
  setCurrentTab,
  setSelectedInvoiceId
}: DashboardProps) {
  const [newTaskText, setNewTaskText] = useState('');

  // Formatter for currency
  const formatMoney = (value: number) => {
    return Math.abs(value).toLocaleString('fa-IR') + ' تومان';
  };

  const formatNumber = (value: number) => {
    return value.toLocaleString('fa-IR');
  };

  // Financial Calculations
  const totalBankBalance = banks.reduce((sum, b) => sum + b.balance, 0);
  
  const totalSales = invoices
    .filter(inv => inv.type === 'sales' && inv.status !== 'draft')
    .reduce((sum, inv) => sum + inv.total, 0);

  const totalPurchases = invoices
    .filter(inv => inv.type === 'purchase' && inv.status !== 'draft')
    .reduce((sum, inv) => sum + inv.total, 0);

  const totalReceivables = contacts
    .filter(c => c.balance > 0)
    .reduce((sum, c) => sum + c.balance, 0);

  const totalPayables = contacts
    .filter(c => c.balance < 0)
    .reduce((sum, c) => sum + Math.abs(c.balance), 0);

  // Profit/Loss estimate: Sales Revenue - Cost of Purchases - Expense Transactions
  // For a basic demo: Sales - Purchases is the simplest gross profit, let's adjust it
  const expenseTransactions = transactions
    .filter(t => t.type === 'payment' && t.toId === 'external')
    .reduce((sum, t) => sum + t.amount, 0);
  const netProfit = totalSales - totalPurchases - expenseTransactions;

  // Chart 1 Data: Monthly Sales & Purchases Trend
  // We'll prepare mock monthly data based on our invoices dates
  const monthlyData = [
    { name: 'فروردین', 'فروش': 12000000, 'خرید': 8000000 },
    { name: 'اردیبهشت', 'فروش': 24000000, 'خرید': 15000000 },
    { name: 'خرداد', 'فروش': 43230000 + 40700000, 'خرید': 173800000 },
    { name: 'تیر', 'فروش': 7150000 + 15000000, 'خرید': 5000000 },
    { name: 'مرداد', 'فروش': 31000000, 'خرید': 18000000 },
    { name: 'شهریور', 'فروش': 45000000, 'خرید': 22000000 }
  ];

  // Chart 2 Data: Bank Balance Breakdown
  const bankPieData = banks.map(b => ({
    name: b.name,
    value: b.balance
  }));

  // Handle To-do notes
  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;
    const newTask: Task = {
      id: 'task_' + Date.now(),
      text: newTaskText,
      done: false,
      date: '۱۴۰۵/۰۴/' + formatNumber(new Date().getDate())
    };
    setTasks([newTask, ...tasks]);
    setNewTaskText('');
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, done: !t.done } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  // Top Receivables
  const topDebtors = [...contacts]
    .filter(c => c.balance > 0)
    .sort((a, b) => b.balance - a.balance)
    .slice(0, 3);

  // Top Payables
  const topCreditors = [...contacts]
    .filter(c => c.balance < 0)
    .sort((a, b) => a.balance - b.balance)
    .slice(0, 3);

  return (
    <div className="space-y-6" id="dashboard-tab">
      
      {/* Dynamic Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        
        {/* Card 1: Bank Balance */}
        <div id="card-bank-balance" className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs hover:shadow-md hover:border-blue-200 transition-all duration-300">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 font-medium">موجودی کل بانک‌ها</span>
            <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
              <CreditCard size={18} />
            </div>
          </div>
          <div className="text-base font-bold text-slate-800 tracking-tight">{formatMoney(totalBankBalance)}</div>
          <div className="text-[11px] text-slate-400 mt-1">بروزرسانی شده در لحظه</div>
        </div>

        {/* Card 2: Total Sales */}
        <div id="card-total-sales" className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs hover:shadow-md hover:border-emerald-200 transition-all duration-300">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 font-medium">کل فروش سال جاری</span>
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
              <TrendingUp size={18} />
            </div>
          </div>
          <div className="text-base font-bold text-slate-800 tracking-tight">{formatMoney(totalSales)}</div>
          <div className="text-[11px] text-emerald-600 mt-1 font-medium flex items-center gap-1">
            <span>ثبت فاکتورهای تایید شده</span>
          </div>
        </div>

        {/* Card 3: Total Purchases */}
        <div id="card-total-purchases" className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs hover:shadow-md hover:border-rose-200 transition-all duration-300">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 font-medium">کل خرید سال جاری</span>
            <div className="p-2 bg-rose-50 text-rose-600 rounded-xl">
              <TrendingDown size={18} />
            </div>
          </div>
          <div className="text-base font-bold text-slate-800 tracking-tight">{formatMoney(totalPurchases)}</div>
          <div className="text-[11px] text-slate-400 mt-1">تامین کالا و دارایی‌ها</div>
        </div>

        {/* Card 4: Total Receivables */}
        <div id="card-total-receivables" className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs hover:shadow-md hover:border-amber-200 transition-all duration-300">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 font-medium">کل بدهکاران (طلب ما)</span>
            <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
              <Users size={18} />
            </div>
          </div>
          <div className="text-base font-bold text-amber-700 tracking-tight">{formatMoney(totalReceivables)}</div>
          <div className="text-[11px] text-amber-600 mt-1 font-medium">نیاز به پیگیری وصول</div>
        </div>

        {/* Card 5: Total Payables */}
        <div id="card-total-payables" className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs hover:shadow-md hover:border-violet-200 transition-all duration-300">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 font-medium">کل بستانکاران (بدهی ما)</span>
            <div className="p-2 bg-violet-50 text-violet-600 rounded-xl">
              <Users size={18} />
            </div>
          </div>
          <div className="text-base font-bold text-violet-700 tracking-tight">{formatMoney(totalPayables)}</div>
          <div className="text-[11px] text-slate-400 mt-1">تعهدات مالی و چک‌ها</div>
        </div>

        {/* Card 6: Net Profit */}
        <div id="card-net-profit" className={`bg-white p-4 rounded-2xl border border-slate-100 shadow-xs hover:shadow-md transition-all duration-300 ${netProfit >= 0 ? 'hover:border-teal-200' : 'hover:border-red-200'}`}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 font-medium">سود ناخالص تقریبی</span>
            <div className={`p-2 rounded-xl ${netProfit >= 0 ? 'bg-teal-50 text-teal-600' : 'bg-red-50 text-red-600'}`}>
              <DollarSign size={18} />
            </div>
          </div>
          <div className={`text-base font-bold tracking-tight ${netProfit >= 0 ? 'text-teal-700' : 'text-red-700'}`}>
            {formatMoney(netProfit)}
          </div>
          <div className={`text-[11px] mt-1 font-medium ${netProfit >= 0 ? 'text-teal-600' : 'text-red-500'}`}>
            {netProfit >= 0 ? 'سود دهی مطلوب جاری' : 'بررسی مجدد هزینه‌ها'}
          </div>
        </div>

      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Sales & Purchases Compare Chart */}
        <div id="sales-purchases-chart-container" className="lg:col-span-2 bg-white p-5 rounded-2xl border border-slate-100 shadow-xs">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-sm font-bold text-slate-800">روند فروش و خرید سال جاری</h3>
            <span className="text-xs text-slate-400">بر حسب ماه</span>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorPurchases" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis 
                  stroke="#94a3b8" 
                  fontSize={10} 
                  tickLine={false} 
                  tickFormatter={(v) => (v / 1000000) + ' م'} 
                  orientation="right"
                />
                <Tooltip 
                  formatter={(value: any) => [formatMoney(value as number), '']}
                  contentStyle={{ direction: 'rtl', borderRadius: '12px', borderColor: '#f1f5f9', fontFamily: 'Vazirmatn, sans-serif' }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Area type="monotone" dataKey="فروش" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorSales)" />
                <Area type="monotone" dataKey="خرید" stroke="#ef4444" strokeWidth={2.5} fillOpacity={1} fill="url(#colorPurchases)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bank & Cash Balance Chart */}
        <div id="bank-distribution-chart-container" className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800 mb-1">سهم بانک‌ها و صندوق‌ها</h3>
            <p className="text-xs text-slate-400 mb-4">پراکندگی موجودی‌های نقد و بانک شرکت</p>
          </div>
          <div className="h-44 flex items-center justify-center relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={bankPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={75}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {bankPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: any) => [formatMoney(value as number), '']}
                  contentStyle={{ direction: 'rtl', borderRadius: '12px', borderColor: '#f1f5f9', fontFamily: 'Vazirmatn, sans-serif' }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute flex flex-col items-center">
              <span className="text-[10px] text-slate-400">کل موجودی نقد</span>
              <span className="text-xs font-bold text-slate-700">{formatMoney(totalBankBalance)}</span>
            </div>
          </div>
          <div className="space-y-2 mt-4">
            {banks.map((b, idx) => (
              <div key={b.id} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[idx % COLORS.length] }}></div>
                  <span className="text-slate-600 font-medium">{b.name}</span>
                </div>
                <span className="text-slate-700 font-bold">{formatMoney(b.balance)}</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Bento Grid: Tables & widgets */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">

        {/* Column 1: Recent Invoices */}
        <div id="recent-invoices-widget" className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs flex flex-col h-96">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-800">آخرین فاکتورها</h3>
            <button 
              onClick={() => setCurrentTab('invoices')}
              className="text-xs text-blue-600 font-semibold hover:underline flex items-center gap-1"
            >
              <span>مشاهده همه</span>
              <ChevronLeft size={14} />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto space-y-3 pr-1">
            {invoices.slice(0, 5).map((inv) => (
              <div 
                key={inv.id} 
                className="p-3 bg-slate-50 hover:bg-slate-100 rounded-xl flex items-center justify-between transition-colors duration-200 cursor-pointer"
                onClick={() => {
                  setSelectedInvoiceId(inv.id);
                  setCurrentTab('invoices');
                }}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-xl text-xs font-bold ${inv.type === 'sales' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                    {inv.type === 'sales' ? 'فروش' : 'خرید'}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-800">{inv.contactName}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">شماره: {inv.number} • تاریخ: {inv.date}</div>
                  </div>
                </div>
                <div className="text-left">
                  <div className="text-xs font-bold text-slate-700">{formatMoney(inv.total)}</div>
                  <span className={`inline-block text-[9px] px-2 py-0.5 rounded-full mt-1 font-bold ${
                    inv.status === 'paid' ? 'bg-emerald-100 text-emerald-700' :
                    inv.status === 'partial' ? 'bg-amber-100 text-amber-700' :
                    inv.status === 'overdue' ? 'bg-rose-100 text-rose-700' :
                    'bg-slate-200 text-slate-700'
                  }`}>
                    {inv.status === 'paid' && 'تسویه کامل'}
                    {inv.status === 'partial' && 'نیمه پرداخت'}
                    {inv.status === 'unpaid' && 'پرداخت نشده'}
                    {inv.status === 'overdue' && 'سررسید گذشته'}
                    {inv.status === 'draft' && 'پیش‌نویس'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Column 2: Recent Transactions */}
        <div id="recent-transactions-widget" className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs flex flex-col h-96">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-800">گردش خزانه اخیر</h3>
            <button 
              onClick={() => setCurrentTab('treasury')}
              className="text-xs text-blue-600 font-semibold hover:underline flex items-center gap-1"
            >
              <span>مشاهده همه</span>
              <ChevronLeft size={14} />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto space-y-3 pr-1">
            {transactions.slice(0, 5).map((t) => (
              <div key={t.id} className="p-3 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-xl ${
                    t.type === 'receive' ? 'bg-emerald-50 text-emerald-600' : 
                    t.type === 'payment' ? 'bg-rose-50 text-rose-600' : 
                    'bg-blue-50 text-blue-600'
                  }`}>
                    {t.type === 'receive' && <ArrowDownLeft size={16} />}
                    {t.type === 'payment' && <ArrowUpRight size={16} />}
                    {t.type === 'transfer' && <ArrowLeftRight size={16} />}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-800">{t.description}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{t.fromName} ← {t.toName}</div>
                  </div>
                </div>
                <div className="text-left">
                  <div className={`text-xs font-bold ${
                    t.type === 'receive' ? 'text-emerald-600' : 
                    t.type === 'payment' ? 'text-rose-600' : 
                    'text-blue-600'
                  }`}>
                    {t.type === 'receive' ? '+' : t.type === 'payment' ? '-' : ''} {formatMoney(t.amount)}
                  </div>
                  <div className="text-[9px] text-slate-400 mt-1">{t.date}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Column 3: Notes & To-Do Checklist */}
        <div id="todo-tasks-widget" className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs flex flex-col h-96">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <CheckSquare size={16} className="text-blue-500" />
              <span>یادداشت‌ها و امور امروز</span>
            </h3>
            <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full font-bold">
              {formatNumber(tasks.filter(t => !t.done).length)} مورد باقی‌مانده
            </span>
          </div>

          {/* Quick Task Add */}
          <form onSubmit={handleAddTask} className="flex gap-2 mb-4">
            <input 
              type="text" 
              placeholder="یادداشت یا وظیفه جدید..."
              value={newTaskText}
              onChange={(e) => setNewTaskText(e.target.value)}
              className="flex-1 text-xs border border-slate-200 bg-slate-50 px-3 py-2 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200"
            />
            <button 
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-xl transition-all duration-200"
            >
              <Plus size={16} />
            </button>
          </form>

          {/* Task List */}
          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {tasks.length === 0 ? (
              <div className="text-center text-slate-400 text-xs py-8">یادداشتی ثبت نشده است.</div>
            ) : (
              tasks.map((task) => (
                <div key={task.id} className="group p-2.5 rounded-xl hover:bg-slate-50 flex items-center justify-between transition-colors duration-200">
                  <div className="flex items-center gap-2.5 flex-1 min-w-0">
                    <input 
                      type="checkbox" 
                      checked={task.done} 
                      onChange={() => toggleTask(task.id)}
                      className="w-4 h-4 text-blue-600 rounded-md border-slate-300 focus:ring-blue-500 cursor-pointer"
                    />
                    <span className={`text-xs truncate text-slate-700 flex-1 ${task.done ? 'line-through text-slate-400' : ''}`}>
                      {task.text}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                    <span className="text-[9px] text-slate-400">{task.date}</span>
                    <button 
                      onClick={() => deleteTask(task.id)}
                      className="text-slate-400 hover:text-rose-500 p-0.5 rounded-md hover:bg-rose-50 transition-colors"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

      {/* Top Receivables & Payables Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Debtors List */}
        <div id="top-debtors-list" className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs">
          <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <span>برترین بدهکاران (بیشترین طلب ما)</span>
          </h3>
          <div className="space-y-4">
            {topDebtors.length === 0 ? (
              <div className="text-center text-slate-400 text-xs py-4">شخص بدهکاری ثبت نشده است.</div>
            ) : (
              topDebtors.map(debtor => {
                const percentage = Math.min(100, (debtor.balance / totalReceivables) * 100);
                return (
                  <div key={debtor.id} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-700">{debtor.name}</span>
                      <span className="font-bold text-amber-600">{formatMoney(debtor.balance)}</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-amber-500 h-full rounded-full" style={{ width: `${percentage}%` }}></div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Creditors List */}
        <div id="top-creditors-list" className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs">
          <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-violet-500"></span>
            <span>برترین بستانکاران (بیشترین بدهی ما)</span>
          </h3>
          <div className="space-y-4">
            {topCreditors.length === 0 ? (
              <div className="text-center text-slate-400 text-xs py-4">شخص بستانکاری ثبت نشده است.</div>
            ) : (
              topCreditors.map(creditor => {
                const absBalance = Math.abs(creditor.balance);
                const percentage = Math.min(100, (absBalance / totalPayables) * 100);
                return (
                  <div key={creditor.id} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-700">{creditor.name}</span>
                      <span className="font-bold text-violet-600">{formatMoney(absBalance)}</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-violet-500 h-full rounded-full" style={{ width: `${percentage}%` }}></div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
