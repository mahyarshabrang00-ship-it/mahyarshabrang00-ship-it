/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BankAccount, Transaction, Contact } from '../types';
import { 
  CreditCard, 
  Plus, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ArrowLeftRight, 
  Search, 
  Trash2, 
  Info, 
  DollarSign 
} from 'lucide-react';

interface TreasuryProps {
  banks: BankAccount[];
  setBanks: React.Dispatch<React.SetStateAction<BankAccount[]>>;
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  contacts: Contact[];
  setContacts: React.Dispatch<React.SetStateAction<Contact[]>>;
  subTabAction?: any;
  setSubTabAction?: any;
}

export default function Treasury({
  banks,
  setBanks,
  transactions,
  setTransactions,
  contacts,
  setContacts,
  subTabAction,
  setSubTabAction
}: TreasuryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'receive' | 'payment' | 'transfer'>('all');

  // Modals Control
  const [isTxModalOpen, setIsTxModalOpen] = useState(false);
  const [isBankModalOpen, setIsBankModalOpen] = useState(false);

  // New Bank Form State
  const [bankName, setBankName] = useState('');
  const [accountNo, setAccountNo] = useState('');
  const [bankType, setBankType] = useState<'bank' | 'cash' | 'petty'>('bank');
  const [initialBalance, setInitialBalance] = useState(0);

  // New Transaction Form State
  const [txType, setTxType] = useState<'receive' | 'payment' | 'transfer'>('receive');
  const [txAmount, setTxAmount] = useState(0);
  const [sourceBankId, setSourceBankId] = useState(''); // for payments, transfers, or receives
  const [destBankId, setDestBankId] = useState(''); // for transfers
  const [selectedContactId, setSelectedContactId] = useState(''); // for customer/supplier payments
  const [txDate, setTxDate] = useState('۱۴۰۵/۰۴/' + String(new Date().getDate()).padStart(2, '0'));
  const [txDesc, setTxDesc] = useState('');
  const [refNo, setRefNo] = useState('');
  const [category, setCategory] = useState('دریافت از مشتری');

  React.useEffect(() => {
    if (subTabAction && subTabAction.tab === 'treasury') {
      if (subTabAction.action === 'add-receipt') {
        setTxType('receive');
        setTxAmount(0);
        setSourceBankId('');
        setSelectedContactId('');
        setTxDesc('');
        setRefNo('');
        setCategory('دریافت از مشتری');
        setIsTxModalOpen(true);
      } else if (subTabAction.action === 'add-payment') {
        setTxType('payment');
        setTxAmount(0);
        setSourceBankId('');
        setSelectedContactId('');
        setTxDesc('');
        setRefNo('');
        setCategory('پرداخت به تامین‌کننده');
        setIsTxModalOpen(true);
      } else if (subTabAction.action === 'add-transfer') {
        setTxType('transfer');
        setTxAmount(0);
        setSourceBankId('');
        setDestBankId('');
        setTxDesc('');
        setRefNo('');
        setIsTxModalOpen(true);
      } else if (subTabAction.action === 'banks-list') {
        setFilterType('all');
        setIsBankModalOpen(true);
      } else if (subTabAction.action === 'list-receipts') {
        setFilterType('receive');
      } else if (subTabAction.action === 'list-payments') {
        setFilterType('payment');
      } else if (subTabAction.action === 'list-transfers') {
        setFilterType('transfer');
      }
      if (setSubTabAction) {
        setSubTabAction(null);
      }
    }
  }, [subTabAction]);

  const formatMoney = (value: number) => {
    return value.toLocaleString('fa-IR') + ' تومان';
  };

  const formatNumber = (value: number) => {
    return value.toLocaleString('fa-IR');
  };

  // Filter transactions
  const filteredTxs = transactions.filter(t => {
    const matchesSearch = t.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (t.refNumber && t.refNumber.includes(searchTerm));
    if (!matchesSearch) return false;

    if (filterType !== 'all' && t.type !== filterType) return false;

    return true;
  });

  // Handle Create New Bank Account
  const handleCreateBank = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bankName.trim()) return;

    const newBank: BankAccount = {
      id: 'b_' + Date.now(),
      name: bankName,
      accountNumber: accountNo || '---',
      type: bankType,
      balance: initialBalance
    };

    setBanks([...banks, newBank]);
    setIsBankModalOpen(false);
  };

  // Handle Register Transaction (Updates balances & history!)
  const handleCreateTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (txAmount <= 0) {
      alert('مبلغ باید بیشتر از صفر باشد.');
      return;
    }

    if (txType === 'transfer') {
      if (!sourceBankId || !destBankId) {
        alert('لطفاً هم بانک مبدأ و هم مقصد را انتخاب کنید.');
        return;
      }
      if (sourceBankId === destBankId) {
        alert('بانک مبدأ و مقصد نمی‌تواند یکسان باشد.');
        return;
      }
      
      const sourceB = banks.find(b => b.id === sourceBankId);
      if (sourceB && sourceB.balance < txAmount) {
        alert('موجودی حساب مبدأ کافی نیست!');
        return;
      }

      // Record transaction
      const sourceName = sourceB?.name || '';
      const destName = banks.find(b => b.id === destBankId)?.name || '';

      const newTx: Transaction = {
        id: 't_' + Date.now(),
        date: txDate,
        type: 'transfer',
        amount: txAmount,
        fromId: sourceBankId,
        fromName: sourceName,
        toId: destBankId,
        toName: destName,
        description: txDesc || `انتقال وجه از ${sourceName} به ${destName}`,
        refNumber: refNo,
        category: 'انتقال بین بانکی'
      };

      // Apply balances
      setBanks(banks.map(b => {
        if (b.id === sourceBankId) return { ...b, balance: b.balance - txAmount };
        if (b.id === destBankId) return { ...b, balance: b.balance + txAmount };
        return b;
      }));

      setTransactions([newTx, ...transactions]);

    } else if (txType === 'receive') {
      // Receive money into a bank
      if (!sourceBankId) {
        alert('لطفاً بانک/صندوق مقصد واریز را انتخاب کنید.');
        return;
      }

      let fromNameVal = 'دریافت‌های متفرقه';
      let fromIdVal = 'external';

      if (selectedContactId) {
        const contact = contacts.find(c => c.id === selectedContactId);
        if (contact) {
          fromNameVal = contact.name;
          fromIdVal = contact.id;

          // Customer balance decreases (positive balance gets closer to 0 or negative)
          setContacts(contacts.map(c => {
            if (c.id === selectedContactId) {
              return { ...c, balance: c.balance - txAmount };
            }
            return c;
          }));
        }
      }

      const bank = banks.find(b => b.id === sourceBankId);
      const newTx: Transaction = {
        id: 't_' + Date.now(),
        date: txDate,
        type: 'receive',
        amount: txAmount,
        fromId: fromIdVal,
        fromName: fromNameVal,
        toId: sourceBankId,
        toName: bank?.name || '',
        description: txDesc || `دریافت وجه به حساب ${bank?.name}`,
        refNumber: refNo,
        category: category
      };

      // Add to bank balance
      setBanks(banks.map(b => b.id === sourceBankId ? { ...b, balance: b.balance + txAmount } : b));
      setTransactions([newTx, ...transactions]);

    } else if (txType === 'payment') {
      // Pay money out of a bank
      if (!sourceBankId) {
        alert('لطفاً بانک/صندوق پرداخت‌کننده را انتخاب کنید.');
        return;
      }

      const bank = banks.find(b => b.id === sourceBankId);
      if (bank && bank.balance < txAmount) {
        alert('موجودی بانک/صندوق انتخاب شده کافی نیست!');
        return;
      }

      let toNameVal = 'هزینه‌های متفرقه';
      let toIdVal = 'external';

      if (selectedContactId) {
        const contact = contacts.find(c => c.id === selectedContactId);
        if (contact) {
          toNameVal = contact.name;
          toIdVal = contact.id;

          // Supplier balance decreases (negative balance gets closer to 0 or positive)
          setContacts(contacts.map(c => {
            if (c.id === selectedContactId) {
              return { ...c, balance: c.balance + txAmount };
            }
            return c;
          }));
        }
      }

      const newTx: Transaction = {
        id: 't_' + Date.now(),
        date: txDate,
        type: 'payment',
        amount: txAmount,
        fromId: sourceBankId,
        fromName: bank?.name || '',
        toId: toIdVal,
        toName: toNameVal,
        description: txDesc || `پرداخت وجه از حساب ${bank?.name}`,
        refNumber: refNo,
        category: category
      };

      // Subtract from bank balance
      setBanks(banks.map(b => b.id === sourceBankId ? { ...b, balance: b.balance - txAmount } : b));
      setTransactions([newTx, ...transactions]);
    }

    setIsTxModalOpen(false);
  };

  const handleDeleteTx = (id: string) => {
    const tx = transactions.find(t => t.id === id);
    if (!tx) return;

    if (confirm('آیا از حذف تراکنش مطمئن هستید؟ موجودی بانک‌ها و مانده اشخاص متأثر معکوس خواهند شد.')) {
      // Reverse balance adjustments
      if (tx.type === 'transfer') {
        setBanks(banks.map(b => {
          if (b.id === tx.fromId) return { ...b, balance: b.balance + tx.amount };
          if (b.id === tx.toId) return { ...b, balance: b.balance - tx.amount };
          return b;
        }));
      } else if (tx.type === 'receive') {
        // Reverse bank
        setBanks(banks.map(b => b.id === tx.toId ? { ...b, balance: b.balance - tx.amount } : b));
        // Reverse contact
        if (tx.fromId !== 'external') {
          setContacts(contacts.map(c => c.id === tx.fromId ? { ...c, balance: c.balance + tx.amount } : c));
        }
      } else if (tx.type === 'payment') {
        // Reverse bank
        setBanks(banks.map(b => b.id === tx.fromId ? { ...b, balance: b.balance + tx.amount } : b));
        // Reverse contact
        if (tx.toId !== 'external') {
          setContacts(contacts.map(c => c.id === tx.toId ? { ...c, balance: c.balance - tx.amount } : c));
        }
      }

      setTransactions(transactions.filter(t => t.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banks section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <CreditCard size={18} className="text-blue-600" />
            <span>بانک‌ها و صندوق‌های شرکت (حساب‌های خزانه)</span>
          </h3>
          <button 
            onClick={() => {
              setBankName('');
              setAccountNo('');
              setInitialBalance(0);
              setBankType('bank');
              setIsBankModalOpen(true);
            }}
            className="text-xs text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 font-bold px-3 py-2 rounded-xl transition-colors flex items-center gap-1"
          >
            <Plus size={15} />
            <span>تعریف حساب جدید</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {banks.map((b) => (
            <div key={b.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-800 leading-snug">{b.name}</span>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-sm font-bold ${
                    b.type === 'bank' ? 'bg-blue-50 text-blue-600' :
                    b.type === 'cash' ? 'bg-emerald-50 text-emerald-600' :
                    'bg-purple-50 text-purple-600'
                  }`}>
                    {b.type === 'bank' && 'بانک'}
                    {b.type === 'cash' && 'صندوق'}
                    {b.type === 'petty' && 'تنخواه'}
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 font-mono mt-1 mb-3">شماره حساب: {b.accountNumber}</div>
              </div>

              <div className="pt-2 border-t border-slate-50 flex items-center justify-between">
                <span className="text-[10px] text-slate-400 font-medium">موجودی فعلی:</span>
                <span className="text-sm font-black text-slate-700">{formatMoney(b.balance)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Transactions History Header & Filters */}
      <div className="space-y-4 pt-4">
        
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
          
          {/* Search */}
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="جستجوی بابت، توضیحات یا شماره سند..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs pr-10 pl-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all duration-200"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2">
            
            <div className="flex rounded-xl bg-slate-50 p-1 border border-slate-200">
              <button 
                onClick={() => setFilterType('all')}
                className={`text-xs px-3 py-1.5 rounded-lg transition-all duration-200 font-medium ${filterType === 'all' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
              >
                همه اسناد
              </button>
              <button 
                onClick={() => setFilterType('receive')}
                className={`text-xs px-3 py-1.5 rounded-lg transition-all duration-200 font-medium ${filterType === 'receive' ? 'bg-white text-emerald-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
              >
                دریافت‌ها
              </button>
              <button 
                onClick={() => setFilterType('payment')}
                className={`text-xs px-3 py-1.5 rounded-lg transition-all duration-200 font-medium ${filterType === 'payment' ? 'bg-white text-rose-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
              >
                پرداخت‌ها
              </button>
              <button 
                onClick={() => setFilterType('transfer')}
                className={`text-xs px-3 py-1.5 rounded-lg transition-all duration-200 font-medium ${filterType === 'transfer' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-700'}`}
              >
                انتقال بین‌بانکی
              </button>
            </div>

            <button 
              onClick={() => {
                setTxAmount(0);
                setTxDesc('');
                setRefNo('');
                setSourceBankId(banks[0]?.id || '');
                setDestBankId(banks[1]?.id || '');
                setSelectedContactId('');
                setIsTxModalOpen(true);
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-sm transition-all duration-200"
            >
              <Plus size={16} />
              <span>ثبت تراکنش نقدی (دریافت/پرداخت)</span>
            </button>

          </div>

        </div>

        {/* Transactions Table */}
        <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 text-slate-500 text-xs font-bold">
                  <th className="p-4">نوع سند</th>
                  <th className="p-4">شرح تراکنش</th>
                  <th className="p-4">تاریخ ثبت</th>
                  <th className="p-4">از حساب / شخص</th>
                  <th className="p-4">به حساب / شخص</th>
                  <th className="p-4">مبلغ تراکنش</th>
                  <th className="p-4">شماره پیگیری</th>
                  <th className="p-4 text-left">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredTxs.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-12 text-center text-slate-400 font-medium">
                      هیچ سند نقدی ثبت نشده است.
                    </td>
                  </tr>
                ) : (
                  filteredTxs.map((t) => (
                    <tr key={t.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="p-4 font-bold flex items-center gap-2">
                        <span className={`p-1.5 rounded-lg ${
                          t.type === 'receive' ? 'bg-emerald-50 text-emerald-600' :
                          t.type === 'payment' ? 'bg-rose-50 text-rose-600' :
                          'bg-blue-50 text-blue-600'
                        }`}>
                          {t.type === 'receive' && <ArrowDownLeft size={14} />}
                          {t.type === 'payment' && <ArrowUpRight size={14} />}
                          {t.type === 'transfer' && <ArrowLeftRight size={14} />}
                        </span>
                        <span>
                          {t.type === 'receive' && 'دریافت'}
                          {t.type === 'payment' && 'پرداخت'}
                          {t.type === 'transfer' && 'انتقال'}
                        </span>
                      </td>
                      <td className="p-4 font-semibold text-slate-800">{t.description}</td>
                      <td className="p-4 font-mono">{t.date}</td>
                      <td className="p-4 font-medium text-slate-600">{t.fromName}</td>
                      <td className="p-4 font-medium text-slate-600">{t.toName}</td>
                      <td className={`p-4 font-black ${
                        t.type === 'receive' ? 'text-emerald-700' :
                        t.type === 'payment' ? 'text-rose-700' :
                        'text-blue-700'
                      }`}>
                        {t.type === 'receive' ? '+' : t.type === 'payment' ? '-' : ''} {formatMoney(t.amount)}
                      </td>
                      <td className="p-4 font-mono text-slate-400">{t.refNumber || '---'}</td>
                      <td className="p-4 text-left">
                        <button 
                          onClick={() => handleDeleteTx(t.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          title="حذف سند"
                        >
                          <Trash2 size={13} />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>

      {/* Add New Bank Modal */}
      {isBankModalOpen && (
        <div id="bank-modal" className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl border border-slate-100 p-5 space-y-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-800">تعریف حساب بانکی یا صندوق جدید</h3>
              <button onClick={() => setIsBankModalOpen(false)} className="text-slate-400 text-lg">×</button>
            </div>

            <form onSubmit={handleCreateBank} className="space-y-4 text-xs">
              
              <div>
                <label className="block font-bold text-slate-600 mb-1.5">نوع حساب *</label>
                <div className="flex gap-1 p-1 bg-slate-100 rounded-xl">
                  <button 
                    type="button" 
                    onClick={() => setBankType('bank')}
                    className={`flex-1 py-1.5 rounded-lg font-bold transition-all ${bankType === 'bank' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500'}`}
                  >
                    حساب بانکی
                  </button>
                  <button 
                    type="button" 
                    onClick={() => setBankType('cash')}
                    className={`flex-1 py-1.5 rounded-lg font-bold transition-all ${bankType === 'cash' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500'}`}
                  >
                    صندوق نقد
                  </button>
                  <button 
                    type="button" 
                    onClick={() => setBankType('petty')}
                    className={`flex-1 py-1.5 rounded-lg font-bold transition-all ${bankType === 'petty' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500'}`}
                  >
                    تنخواه
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1.5">عنوان حساب / نام بانک *</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: بانک تجارت شعبه ونک یا صندوق مرکزی"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1.5">شماره حساب / شماره کارت</label>
                <input 
                  type="text" 
                  placeholder="مثال: ۶۲۷۳-۵۳۳۱-۸۸۸۸-۱۱۲۲"
                  value={accountNo}
                  onChange={(e) => setAccountNo(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-mono text-left"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1.5">موجودی اولیه (تومان) *</label>
                <div className="relative">
                  <input 
                    type="number" 
                    required
                    value={initialBalance}
                    onChange={(e) => setInitialBalance(Number(e.target.value))}
                    className="w-full pl-12 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-mono text-left"
                    dir="ltr"
                  />
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-bold">تومان</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button type="button" onClick={() => setIsBankModalOpen(false)} className="text-slate-500 px-3 py-1.5">انصراف</button>
                <button type="submit" className="bg-blue-600 text-white px-4 py-1.5 rounded-lg font-bold">ایجاد حساب</button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* Add Transaction Modal */}
      {isTxModalOpen && (
        <div id="tx-modal" className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl border border-slate-100 p-5 space-y-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-800">ثبت تراکنش مالی جدید در خزانه</h3>
              <button onClick={() => setIsTxModalOpen(false)} className="text-slate-400 text-lg">×</button>
            </div>

            <form onSubmit={handleCreateTransaction} className="space-y-4 text-xs">
              
              <div>
                <label className="block font-bold text-slate-600 mb-1.5">نوع تراکنش *</label>
                <div className="flex gap-1 p-1 bg-slate-100 rounded-xl">
                  <button 
                    type="button" 
                    onClick={() => {
                      setTxType('receive');
                      setCategory('دریافت از مشتری');
                    }}
                    className={`flex-1 py-1.5 rounded-lg font-bold transition-all ${txType === 'receive' ? 'bg-white text-emerald-600 shadow-xs' : 'text-slate-500'}`}
                  >
                    دریافت نقد / چک
                  </button>
                  <button 
                    type="button" 
                    onClick={() => {
                      setTxType('payment');
                      setCategory('هزینه‌های عمومی و اداری');
                    }}
                    className={`flex-1 py-1.5 rounded-lg font-bold transition-all ${txType === 'payment' ? 'bg-white text-rose-600 shadow-xs' : 'text-slate-500'}`}
                  >
                    پرداخت نقد / هزینه
                  </button>
                  <button 
                    type="button" 
                    onClick={() => setTxType('transfer')}
                    className={`flex-1 py-1.5 rounded-lg font-bold transition-all ${txType === 'transfer' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500'}`}
                  >
                    انتقال بین بانکی
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {txType === 'transfer' ? (
                  <>
                    <div>
                      <label className="block font-bold text-slate-600 mb-1.5">حساب مبدأ (کسر وجه) *</label>
                      <select
                        required
                        value={sourceBankId}
                        onChange={(e) => setSourceBankId(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                      >
                        <option value="">-- انتخاب حساب مبدأ --</option>
                        {banks.map(b => (
                          <option key={b.id} value={b.id}>{b.name} (مانده: {formatMoney(b.balance)})</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-bold text-slate-600 mb-1.5">حساب مقصد (افزایش وجه) *</label>
                      <select
                        required
                        value={destBankId}
                        onChange={(e) => setDestBankId(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                      >
                        <option value="">-- انتخاب حساب مقصد --</option>
                        {banks.map(b => (
                          <option key={b.id} value={b.id}>{b.name} (مانده: {formatMoney(b.balance)})</option>
                        ))}
                      </select>
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <label className="block font-bold text-slate-600 mb-1.5">
                        {txType === 'receive' ? 'حساب مقصد واریز *' : 'حساب مبدأ پرداخت *'}
                      </label>
                      <select
                        required
                        value={sourceBankId}
                        onChange={(e) => setSourceBankId(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                      >
                        <option value="">-- انتخاب حساب خزانه --</option>
                        {banks.map(b => (
                          <option key={b.id} value={b.id}>{b.name} (مانده: {formatMoney(b.balance)})</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-bold text-slate-600 mb-1.5">
                        {txType === 'receive' ? 'دریافت از شخص (بابت تسویه)' : 'پرداخت به شخص / بستانکار'}
                      </label>
                      <select
                        value={selectedContactId}
                        onChange={(e) => setSelectedContactId(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                      >
                        <option value="">-- واریز متفرقه بدون شخص --</option>
                        {contacts.map(c => (
                          <option key={c.id} value={c.id}>{c.name} ({c.balance > 0 ? 'بدهکار' : 'بستانکار'}: {formatMoney(c.balance)})</option>
                        ))}
                      </select>
                    </div>
                  </>
                )}

                <div>
                  <label className="block font-bold text-slate-600 mb-1.5">مبلغ تراکنش (تومان) *</label>
                  <div className="relative">
                    <input 
                      type="number" 
                      required
                      value={txAmount}
                      onChange={(e) => setTxAmount(Number(e.target.value))}
                      className="w-full pl-12 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-left"
                      dir="ltr"
                    />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-bold">تومان</span>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-600 mb-1.5">تاریخ ثبت تراکنش *</label>
                  <input 
                    type="text" 
                    required
                    value={txDate}
                    onChange={(e) => setTxDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-center"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-600 mb-1.5">شماره فیش / پیگیری</label>
                  <input 
                    type="text" 
                    placeholder="مثال: ۹۸۲۲۳۱"
                    value={refNo}
                    onChange={(e) => setRefNo(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>

                {txType !== 'transfer' && (
                  <div>
                    <label className="block font-bold text-slate-600 mb-1.5">طبقه‌بندی / سرفصل هزینه</label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    >
                      {txType === 'receive' ? (
                        <>
                          <option value="دریافت از مشتری">دریافت از مشتری (تسویه فاکتور)</option>
                          <option value="سرمایه‌گذاری اولیه">سرمایه‌گذاری یا جذب شریک</option>
                          <option value="درآمدهای متفرقه">سایر درآمدهای غیرعملیاتی</option>
                        </>
                      ) : (
                        <>
                          <option value="پرداخت به تامین‌کننده">پرداخت به تامین‌کننده (خرید کالا)</option>
                          <option value="هزینه‌های عمومی و اداری">هزینه‌های عمومی و اداری (آبدارخانه، ملزومات)</option>
                          <option value="حقوق و دستمزد پرسنل">حقوق و دستمزد پرسنل</option>
                          <option value="هزینه اجاره دفتر">هزینه اجاره یا بهره‌برداری</option>
                          <option value="هزینه اینترنت و ارتباطات">اشتراک‌ها، اینترنت و ملزومات شبکه</option>
                        </>
                      )}
                    </select>
                  </div>
                )}

              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1.5">بابت / شرح تراکنش سند</label>
                <textarea 
                  placeholder="توضیحاتی بابت فاکتور، چک، واریزی عابربانک یا علت انتقال..."
                  value={txDesc}
                  onChange={(e) => setTxDesc(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                ></textarea>
              </div>

              {/* Disclaimer */}
              <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-100 flex gap-2 text-[10px] text-slate-600 leading-relaxed">
                <Info size={16} className="text-blue-500 shrink-0" />
                <span>
                  با ثبت نهایی این سند، موجودی‌های نقد و بانک‌ها و سرفصل‌های معین بدهکاران/بستانکاران به صورت خودکار بروزرسانی شده و در تراز مالی ثبت می‌گردند.
                </span>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button type="button" onClick={() => setIsTxModalOpen(false)} className="text-slate-500 px-3 py-1.5">انصراف</button>
                <button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-1.5 rounded-lg font-bold transition-colors">ثبت سند نقدی</button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
