/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Contact {
  id: string;
  name: string;
  code: string;
  phone: string;
  email: string;
  type: 'customer' | 'supplier' | 'both' | 'shareholder' | 'employee';
  balance: number; // positive = debtor (بدهکار), negative = creditor (بستانکار)
  address: string;
  nationalId: string;
  
  // Extra fields from screenshots
  company?: string;
  title?: string;
  firstName?: string;
  lastName?: string;
  category?: string;
  isActive?: boolean;
  country?: string;
  province?: string;
  city?: string;
  postalCode?: string;
  mobile?: string;
  fax?: string;
  phone1?: string;
  phone2?: string;
  phone3?: string;
  website?: string;
  economicCode?: string;
  registrationNumber?: string;
  branchCode?: string;
  description?: string;
  birthDate?: string;
  marriageDate?: string;
  membershipDate?: string;
  financialCredit?: number;
  priceList?: string;
  taxType?: string;
  image?: string;
  bankAccounts?: {
    bank: string;
    accountNumber: string;
    cardNumber: string;
    sheba: string;
  }[];
}

export interface ItemService {
  id: string;
  name: string;
  code: string;
  unit: string; // عدد, کیلوگرم, متر, جلد, ساعت, etc.
  salePrice: number;
  purchasePrice: number;
  stock: number;
  description: string;
  isService: boolean; // service doesn't have stock tracking
  category?: string;
  productCode?: string;
  isActive?: boolean;
  itemType?: string; // ماده اولیه ، محصول نهایی ، نیمه ساخت
  image?: string; // Base64 data URL for local upload
  barcode?: string;
  salesDescription?: string;
  purchaseDescription?: string;
  controlStock?: boolean;
  reorderPoint?: number;
  minOrder?: number;
  leadTime?: number;
  taxSales?: boolean;
  taxPurchase?: boolean;
  salesTaxRate?: number;
  purchaseTaxRate?: number;
  taxType?: string;
  taxCode?: string;
  taxUnit?: string;
  accountingCode?: string;
  isAutoAccountingCode?: boolean;
}

export interface InvoiceItem {
  id: string;
  itemId: string;
  itemName: string;
  qty: number;
  unitPrice: number;
  discount: number; // percentage or fixed? Let's treat as amount
  tax: number; // amount
  total: number;
}

export interface Invoice {
  id: string;
  number: string;
  date: string; // e.g. "1405/04/17"
  dueDate: string; // e.g. "1405/05/17"
  type: 'sales' | 'purchase'; // فروش | خرید
  contactId: string;
  contactName: string;
  items: InvoiceItem[];
  discount: number; // total discount
  tax: number; // total tax (e.g. 10%)
  total: number; // final payable amount
  paidAmount: number;
  status: 'draft' | 'unpaid' | 'paid' | 'partial' | 'overdue';
  description?: string;
}

export interface BankAccount {
  id: string;
  name: string; // ملی, ملت, صندوق مرکزی, تنخواه, etc.
  accountNumber: string;
  type: 'bank' | 'cash' | 'petty'; // بانک, صندوق, تنخواه
  balance: number;
}

export interface Transaction {
  id: string;
  date: string; // e.g. "1405/04/17"
  type: 'receive' | 'payment' | 'transfer'; // دریافت, پرداخت, انتقال
  amount: number;
  fromId: string; // bank/cash or customer/supplier
  fromName: string;
  toId: string; // bank/cash or customer/supplier
  toName: string;
  description: string;
  refNumber?: string;
  category?: string; // e.g. "فروش", "هزینه اجاره", "خرید ملزومات"
}

export interface Task {
  id: string;
  text: string;
  done: boolean;
  date: string;
}

export interface CompanyInfo {
  name: string;
  logoUrl?: string;
  financialYear: string;
  phone: string;
  address: string;
  taxNumber?: string;
}

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  companyName: string;
  fullName: string;
  createdAt: string;
}

export interface UserSession {
  userId: string;
  email: string;
  companyName: string;
  fullName: string;
  token: string;
}

export interface Project {
  id: string;
  name: string;
  isActive: boolean;
  isDefault: boolean;
}

export interface ReceiptItem {
  id: string;
  contactId: string;
  contactName: string;
  amount: number;
  description: string;
}

export interface Receipt {
  id: string;
  number: string;
  accountingDocNo: string;
  date: string;
  project?: string;
  currency: string;
  description: string;
  items: ReceiptItem[];
  totalAmount: number;
  invoiceNo?: string;
  accountName?: string;
}

export interface PaymentItem {
  id: string;
  contactId: string;
  contactName: string;
  amount: number;
  description: string;
}

export interface Payment {
  id: string;
  number: string;
  accountingDocNo: string;
  date: string;
  project?: string;
  currency: string;
  description: string;
  items: PaymentItem[];
  totalAmount: number;
  invoiceNo?: string;
  accountName?: string;
}

export interface Shareholder {
  id: string;
  contactId: string;
  contactName: string;
  percentage: number;
}

export interface Seller {
  id: string;
  code: string;
  name: string;
  isActive: boolean;
  salesPercent: number;
  returnPercent: number;
  salesAmount: number;
  returnAmount: number;
  excludeProductDiscount: boolean;
  excludeInvoiceAdjustments: boolean;
  commissionInInvoice: boolean;
  expenseAccount: string;
  relatedContactId: string;
  relatedContactName: string;
  description: string;
  productCommissions?: { itemId: string; salesPercent: number; returnPercent: number; }[];
  categoryCommissions?: { categoryId: string; salesPercent: number; returnPercent: number; }[];
}



